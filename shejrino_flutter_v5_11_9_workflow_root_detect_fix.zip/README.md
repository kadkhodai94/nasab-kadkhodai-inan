# Shejrino v5.11.9 Workflow Root Detection Fix

Base:
- shejrino_flutter_v5_11_8_workflow_zip_fix.zip

Changes:
- Version bumped to 5.11.9+77
- Workflow root detection fixed
- It skips pubspec.yaml files inside plugins/
- It selects only the Flutter app root that contains lib/main.dart
- Fixes wrong detection of extracted_project/plugins/bazaar_iab
- Shejrino ZIP patterns and artifacts preserved
