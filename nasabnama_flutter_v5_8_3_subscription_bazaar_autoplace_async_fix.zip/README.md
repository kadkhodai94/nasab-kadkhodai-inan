# NasabNama v5.8.3 Bazaar AutoPlace Async Fix

Fix:
- Removed invalid await/return String from void autoPlace
- Fixes analyzer errors:
  - await_in_wrong_context
  - return_of_invalid_type
- Bazaar subscription remains active
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.3+44
