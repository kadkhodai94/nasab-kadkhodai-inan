# NasabNama v5.9.1 Safe Icons Workflow Compatibility

Fix:
- Based on v5.9.0 Package/MainActivity crash fix
- Adds safe android_launcher_icons folder back
- This prevents old GitHub workflow from failing on:
  cp: cannot stat 'android_launcher_icons/mipmap-mdpi/*.png'
- Payment and subscription are still removed
- Package/MainActivity fix remains
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore remains

Version: 5.9.1+52
