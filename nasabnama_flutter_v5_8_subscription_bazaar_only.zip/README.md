# NasabNama v5.8 Bazaar Subscription

Bazaar-only subscription version:
- Package/applicationId remains mk.kadkhodai.nasab
- Release keystore and launcher icon kept from v5.7.2
- Added cafebazaar_flutter dependency
- Added Bazaar subscription page
- Added plans:
  - nasab_monthly_100 = 100,000 Toman
  - nasab_3month_250 = 250,000 Toman
  - nasab_6month_560 = 560,000 Toman
  - nasab_yearly_1000 = 1,000,000 Toman
- Free limited mode:
  - 1 family tree
  - 25 people
- Added restore purchase button
- Added BAZAAR_PUBLIC_KEY dart-define support through GitHub secret
- Myket is not included in this version

Important:
Set GitHub secret BAZAAR_PUBLIC_KEY with the Cafe Bazaar public key from the Bazaar developer panel.

Version: 5.8.0+41
