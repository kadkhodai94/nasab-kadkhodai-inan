import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:cafebazaar_flutter/cafebazaar_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NasabNamaApp());
}

const _uuid = Uuid();

const kBazaarPublicKey = String.fromEnvironment('BAZAAR_PUBLIC_KEY', defaultValue: 'CHANGE_THIS_BAZAAR_PUBLIC_KEY');
const kSubscriptionSourceBazaar = 'cafebazaar';

class NasabSubscriptionPlan {
  final String id;
  final String title;
  final String priceText;
  final int priceToman;
  final int days;
  final String badge;
  const NasabSubscriptionPlan({required this.id, required this.title, required this.priceText, required this.priceToman, required this.days, required this.badge});
}

const kNasabSubscriptionPlans = <NasabSubscriptionPlan>[
  NasabSubscriptionPlan(id: 'nasab_monthly_100', title: 'اشتراک ماهانه', priceText: '۱۰۰ هزار تومان', priceToman: 100000, days: 30, badge: 'شروع سریع'),
  NasabSubscriptionPlan(id: 'nasab_3month_250', title: 'اشتراک ۳ ماهه', priceText: '۲۵۰ هزار تومان', priceToman: 250000, days: 90, badge: 'اقتصادی'),
  NasabSubscriptionPlan(id: 'nasab_6month_560', title: 'اشتراک ۶ ماهه', priceText: '۵۶۰ هزار تومان', priceToman: 560000, days: 180, badge: 'خانوادگی'),
  NasabSubscriptionPlan(id: 'nasab_yearly_1000', title: 'اشتراک ۱ ساله', priceText: '۱ میلیون تومان', priceToman: 1000000, days: 365, badge: 'بهترین انتخاب'),
];

NasabSubscriptionPlan? planById(String id) {
  for (final plan in kNasabSubscriptionPlans) {
    if (plan.id == id) return plan;
  }
  return null;
}


String cleanText(String value) => value
    .trim()
    .replaceAll('ي', 'ی')
    .replaceAll('ك', 'ک')
    .replaceAll('ة', 'ه')
    .replaceAll('ۀ', 'ه')
    .replaceAll(RegExp(r'[‌‏؜]'), '')
    .replaceAll(RegExp(r'\s+'), ' ')
    .toLowerCase();
String looseText(String value) {
  var v = cleanText(value)
      .replaceAll('آ', 'ا')
      .replaceAll('أ', 'ا')
      .replaceAll('إ', 'ا')
      .replaceAll('ى', 'ی')
      .replaceAll(RegExp(r'[^\u0600-\u06FFa-zA-Z0-9 ]+'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  for (final w in ['خانم', 'آقا', 'اقای', 'حاج', 'حاجی', 'مرحوم', 'مرحومه', 'جناب']) {
    v = v.replaceAll(RegExp('(^| )${RegExp.escape(w)}( |\$)'), ' ');
  }
  return v.replaceAll(RegExp(r'\s+'), ' ').trim();
}

bool looseEquals(String a, String b) {
  final x = looseText(a);
  final y = looseText(b);
  if (x.isEmpty || y.isEmpty) return false;
  if (x == y) return true;
  return x.contains(y) || y.contains(x);
}

int looseScore(String a, String b) {
  final x = looseText(a);
  final y = looseText(b);
  if (x.isEmpty || y.isEmpty) return 0;
  if (x == y) return 100;
  if (x.contains(y) || y.contains(x)) return 82;
  final tx = x.split(' ').where((e) => e.isNotEmpty).toSet();
  final ty = y.split(' ').where((e) => e.isNotEmpty).toSet();
  if (tx.isEmpty || ty.isEmpty) return 0;
  final common = tx.intersection(ty).length;
  return ((common * 100) / max(tx.length, ty.length)).round();
}

String nowIso() => DateTime.now().toIso8601String();
String shortDate(String iso) => iso.isEmpty ? '-' : iso.split('T').first;


T? firstWhereOrNull<T>(Iterable<T> items, bool Function(T) test) {
  for (final item in items) {
    if (test(item)) return item;
  }
  return null;
}

String normalizeHeader(String value) {
  return cleanText(value)
      .replaceAll(RegExp(r'[\s_\-\/\\]+'), '')
      .replaceAll('ى', 'ی')
      .replaceAll('أ', 'ا')
      .replaceAll('إ', 'ا')
      .replaceAll('آ', 'ا');
}

List<List<String>> parseCsvRows(String input) {
  final text = input.replaceFirst('\uFEFF', '').replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  final firstLine = text.split('\n').firstWhere((e) => e.trim().isNotEmpty, orElse: () => '');
  var delimiter = ',';
  if (';'.allMatches(firstLine).length > ','.allMatches(firstLine).length) delimiter = ';';
  if ('\t'.allMatches(firstLine).length > delimiter.allMatches(firstLine).length) delimiter = '\t';

  final rows = <List<String>>[];
  final row = <String>[];
  final cell = StringBuffer();
  var inQuotes = false;

  for (var i = 0; i < text.length; i++) {
    final ch = text[i];
    final next = i + 1 < text.length ? text[i + 1] : '';
    if (ch == '"') {
      if (inQuotes && next == '"') {
        cell.write('"');
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch == delimiter && !inQuotes) {
      row.add(cell.toString().trim());
      cell.clear();
    } else if (ch == '\n' && !inQuotes) {
      row.add(cell.toString().trim());
      cell.clear();
      if (row.any((e) => e.trim().isNotEmpty)) rows.add(List<String>.from(row));
      row.clear();
    } else {
      cell.write(ch);
    }
  }

  row.add(cell.toString().trim());
  if (row.any((e) => e.trim().isNotEmpty)) rows.add(List<String>.from(row));
  return rows;
}

String csvValue(Map<String, int> header, List<String> row, List<String> aliases) {
  for (final alias in aliases) {
    final index = header[normalizeHeader(alias)];
    if (index != null && index < row.length) return row[index].trim();
  }
  return '';
}

String normalizeGenderValue(String value) {
  final v = cleanText(value);
  if (v.contains('زن') || v.contains('دختر') || v == 'f' || v == 'female') return 'زن';
  if (v.contains('مرد') || v.contains('پسر') || v == 'm' || v == 'male') return 'مرد';
  return 'نامشخص';
}

class C {
  static const bg = Color(0xFFF6EFE3);
  static const cream = Color(0xFFFFF8EE);
  static const white = Color(0xFFFFFFFF);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF6C7280);
  static const blue = Color(0xFF1E6FD9);
  static const sky = Color(0xFFE7F1FF);
  static const green = Color(0xFF18A978);
  static const mint = Color(0xFFE6F7EF);
  static const gold = Color(0xFFE8B95E);
  static const red = Color(0xFFE45757);
  static const shadow = Color(0x1F18213A);
}

class Person {
  String id;
  String code;
  String name;
  String fatherName;
  String grandfatherName;
  String motherName;
  String? fatherId;
  String? motherId;
  String? spouseId;
  String spouseName;
  String phone;
  String gender;
  String branch;
  String birthDate;
  String deathDate;
  String birthPlace;
  String livingPlace;
  String notes;
  String specialTag;
  bool phonePrivate;
  String createdBy;
  String createdAt;

  Person({
    required this.id,
    required this.code,
    required this.name,
    this.fatherName = '',
    this.grandfatherName = '',
    this.motherName = '',
    this.fatherId,
    this.motherId,
    this.spouseId,
    this.spouseName = '',
    this.phone = '',
    this.gender = 'نامشخص',
    this.branch = '',
    this.birthDate = '',
    this.deathDate = '',
    this.birthPlace = '',
    this.livingPlace = '',
    this.notes = '',
    this.specialTag = '',
    this.phonePrivate = true,
    this.createdBy = 'ادمین',
    String? createdAt,
  }) : createdAt = createdAt ?? nowIso();

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'name': name,
        'fatherName': fatherName,
        'grandfatherName': grandfatherName,
        'motherName': motherName,
        'fatherId': fatherId,
        'motherId': motherId,
        'spouseId': spouseId,
        'spouseName': spouseName,
        'phone': phone,
        'gender': gender,
        'branch': branch,
        'birthDate': birthDate,
        'deathDate': deathDate,
        'birthPlace': birthPlace,
        'livingPlace': livingPlace,
        'notes': notes,
        'specialTag': specialTag,
        'phonePrivate': phonePrivate,
        'createdBy': createdBy,
        'createdAt': createdAt,
      };

  factory Person.fromJson(Map<String, dynamic> j) => Person(
        id: j['id'] ?? _uuid.v4(),
        code: j['code'] ?? 'FAM-000000',
        name: j['name'] ?? '',
        fatherName: j['fatherName'] ?? '',
        grandfatherName: j['grandfatherName'] ?? '',
        motherName: j['motherName'] ?? '',
        fatherId: j['fatherId'],
        motherId: j['motherId'],
        spouseId: j['spouseId'],
        spouseName: j['spouseName'] ?? '',
        phone: j['phone'] ?? '',
        gender: j['gender'] ?? 'نامشخص',
        branch: j['branch'] ?? '',
        birthDate: j['birthDate'] ?? '',
        deathDate: j['deathDate'] ?? '',
        birthPlace: j['birthPlace'] ?? '',
        livingPlace: j['livingPlace'] ?? '',
        notes: j['notes'] ?? '',
        specialTag: j['specialTag'] ?? '',
        phonePrivate: j['phonePrivate'] ?? true,
        createdBy: j['createdBy'] ?? 'ادمین',
        createdAt: j['createdAt'],
      );

  Person copy() => Person.fromJson(toJson());
}

class TreeMember {
  String id;
  String name;
  String phone;
  String role;
  bool approved;
  String joinedAt;

  TreeMember({required this.id, required this.name, this.phone = '', this.role = 'عضو', this.approved = true, String? joinedAt}) : joinedAt = joinedAt ?? nowIso();

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'role': role, 'approved': approved, 'joinedAt': joinedAt};
  factory TreeMember.fromJson(Map<String, dynamic> j) => TreeMember(id: j['id'] ?? _uuid.v4(), name: j['name'] ?? '', phone: j['phone'] ?? '', role: j['role'] ?? 'عضو', approved: j['approved'] ?? true, joinedAt: j['joinedAt']);
}

class AccessRequest {
  String id;
  String name;
  String phone;
  String note;
  String status;
  String createdAt;
  AccessRequest({required this.id, required this.name, this.phone = '', this.note = '', this.status = 'در انتظار', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'note': note, 'status': status, 'createdAt': createdAt};
  factory AccessRequest.fromJson(Map<String, dynamic> j) => AccessRequest(id: j['id'] ?? _uuid.v4(), name: j['name'] ?? '', phone: j['phone'] ?? '', note: j['note'] ?? '', status: j['status'] ?? 'در انتظار', createdAt: j['createdAt']);
}

class ActivityLog {
  String id;
  String text;
  String actor;
  String createdAt;
  ActivityLog({required this.id, required this.text, this.actor = 'ادمین', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'actor': actor, 'createdAt': createdAt};
  factory ActivityLog.fromJson(Map<String, dynamic> j) => ActivityLog(id: j['id'] ?? _uuid.v4(), text: j['text'] ?? '', actor: j['actor'] ?? 'ادمین', createdAt: j['createdAt']);
}

class FamilyItem {
  String id;
  String title;
  String description;
  String personId;
  String type;
  String createdAt;
  FamilyItem({required this.id, required this.title, this.description = '', this.personId = '', this.type = 'photo', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'description': description, 'personId': personId, 'type': type, 'createdAt': createdAt};
  factory FamilyItem.fromJson(Map<String, dynamic> j) => FamilyItem(id: j['id'] ?? _uuid.v4(), title: j['title'] ?? '', description: j['description'] ?? '', personId: j['personId'] ?? '', type: j['type'] ?? 'photo', createdAt: j['createdAt']);
}

class FamilyEvent {
  String id;
  String title;
  String date;
  String personId;
  String type;
  String notes;
  FamilyEvent({required this.id, required this.title, this.date = '', this.personId = '', this.type = 'رویداد', this.notes = ''});
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'date': date, 'personId': personId, 'type': type, 'notes': notes};
  factory FamilyEvent.fromJson(Map<String, dynamic> j) => FamilyEvent(id: j['id'] ?? _uuid.v4(), title: j['title'] ?? '', date: j['date'] ?? '', personId: j['personId'] ?? '', type: j['type'] ?? 'رویداد', notes: j['notes'] ?? '');
}

class ChatMessage {
  String id;
  String sender;
  String text;
  String createdAt;
  ChatMessage({required this.id, this.sender = 'ادمین', required this.text, String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'sender': sender, 'text': text, 'createdAt': createdAt};
  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(id: j['id'] ?? _uuid.v4(), sender: j['sender'] ?? 'ادمین', text: j['text'] ?? '', createdAt: j['createdAt']);
}

class Poll {
  String id;
  String question;
  List<String> options;
  Map<String, int> votes;
  bool secret;
  Poll({required this.id, required this.question, required this.options, Map<String, int>? votes, this.secret = false}) : votes = votes ?? {for (final o in options) o: 0};
  Map<String, dynamic> toJson() => {'id': id, 'question': question, 'options': options, 'votes': votes, 'secret': secret};
  factory Poll.fromJson(Map<String, dynamic> j) => Poll(id: j['id'] ?? _uuid.v4(), question: j['question'] ?? '', options: List<String>.from(j['options'] ?? []), votes: Map<String, int>.from(j['votes'] ?? {}), secret: j['secret'] ?? false);
}

class FamilyTree {
  String id;
  String code;
  String title;
  String ownerName;
  String ownerPhone;
  String branch;
  String createdAt;
  List<Person> people;
  List<TreeMember> members;
  List<AccessRequest> requests;
  List<ActivityLog> logs;
  List<FamilyItem> items;
  List<FamilyEvent> events;
  List<ChatMessage> chats;
  List<Poll> polls;

  FamilyTree({
    required this.id,
    required this.code,
    required this.title,
    required this.ownerName,
    this.ownerPhone = '',
    this.branch = '',
    String? createdAt,
    List<Person>? people,
    List<TreeMember>? members,
    List<AccessRequest>? requests,
    List<ActivityLog>? logs,
    List<FamilyItem>? items,
    List<FamilyEvent>? events,
    List<ChatMessage>? chats,
    List<Poll>? polls,
  })  : createdAt = createdAt ?? nowIso(),
        people = people ?? [],
        members = members ?? [],
        requests = requests ?? [],
        logs = logs ?? [],
        items = items ?? [],
        events = events ?? [],
        chats = chats ?? [],
        polls = polls ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'title': title,
        'ownerName': ownerName,
        'ownerPhone': ownerPhone,
        'branch': branch,
        'createdAt': createdAt,
        'people': people.map((e) => e.toJson()).toList(),
        'members': members.map((e) => e.toJson()).toList(),
        'requests': requests.map((e) => e.toJson()).toList(),
        'logs': logs.map((e) => e.toJson()).toList(),
        'items': items.map((e) => e.toJson()).toList(),
        'events': events.map((e) => e.toJson()).toList(),
        'chats': chats.map((e) => e.toJson()).toList(),
        'polls': polls.map((e) => e.toJson()).toList(),
      };

  factory FamilyTree.fromJson(Map<String, dynamic> j) => FamilyTree(
        id: j['id'] ?? _uuid.v4(),
        code: j['code'] ?? 'TREE-0000',
        title: j['title'] ?? 'شجره‌نامه',
        ownerName: j['ownerName'] ?? 'ادمین',
        ownerPhone: j['ownerPhone'] ?? '',
        branch: j['branch'] ?? '',
        createdAt: j['createdAt'],
        people: (j['people'] as List? ?? []).map((e) => Person.fromJson(Map<String, dynamic>.from(e))).toList(),
        members: (j['members'] as List? ?? []).map((e) => TreeMember.fromJson(Map<String, dynamic>.from(e))).toList(),
        requests: (j['requests'] as List? ?? []).map((e) => AccessRequest.fromJson(Map<String, dynamic>.from(e))).toList(),
        logs: (j['logs'] as List? ?? []).map((e) => ActivityLog.fromJson(Map<String, dynamic>.from(e))).toList(),
        items: (j['items'] as List? ?? []).map((e) => FamilyItem.fromJson(Map<String, dynamic>.from(e))).toList(),
        events: (j['events'] as List? ?? []).map((e) => FamilyEvent.fromJson(Map<String, dynamic>.from(e))).toList(),
        chats: (j['chats'] as List? ?? []).map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e))).toList(),
        polls: (j['polls'] as List? ?? []).map((e) => Poll.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class AppStore extends ChangeNotifier {
  static const storageKey = 'nasabnama_v3_full_local';
  List<FamilyTree> trees = [];
  String? activeTreeId;
  bool loaded = false;

  bool showHelp = true;
  bool protectPhones = true;
  bool appLockEnabled = false;
  String appPin = '';
  String adminDisplayName = 'ادمین';
  String lastBackupAt = '';
  double treeCardScale = 1.0;
  Set<String> collapsedTreeUnits = <String>{};

  String subscriptionPlanId = 'free';
  String subscriptionSource = 'free';
  String subscriptionStartedAt = '';
  String subscriptionExpiresAt = '';
  String subscriptionOrderId = '';
  String subscriptionPurchaseToken = '';

  static const freeMaxTrees = 1;
  static const freeMaxPeople = 25;

  bool get hasActiveSubscription {
    if (subscriptionPlanId == 'free' || subscriptionExpiresAt.trim().isEmpty) return false;
    final expires = DateTime.tryParse(subscriptionExpiresAt);
    if (expires == null) return false;
    return DateTime.now().isBefore(expires);
  }

  bool get isPremium => hasActiveSubscription;
  String get planTitle => isPremium ? (planById(subscriptionPlanId)?.title ?? 'اشتراک فعال') : 'رایگان محدود';
  String get planExpireText => isPremium ? shortDate(subscriptionExpiresAt) : 'فعال نیست';
  int get totalPeopleCount => trees.fold<int>(0, (sum, t) => sum + t.people.length);
  bool get canCreateFreeTree => isPremium || trees.length < freeMaxTrees;
  bool canAddPeopleCount(int count) => isPremium || (totalPeopleCount + count) <= freeMaxPeople;
  String freeLimitMessage({String feature = 'این قابلیت'}) => '$feature در نسخه رایگان محدود است. برای استفاده کامل، اشتراک را فعال کن.';


  FamilyTree? get current {
    if (trees.isEmpty) return null;
    if (activeTreeId == null) return trees.first;
    return trees.firstWhere((e) => e.id == activeTreeId, orElse: () => trees.first);
  }

  Future<void> load() async {
    final pref = await SharedPreferences.getInstance();
    final raw = pref.getString(storageKey);
    if (raw != null && raw.trim().isNotEmpty) {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      activeTreeId = data['activeTreeId'];
      trees = (data['trees'] as List? ?? []).map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
      final settings = Map<String, dynamic>.from(data['settings'] as Map? ?? {});
      showHelp = settings['showHelp'] ?? true;
      protectPhones = settings['protectPhones'] ?? true;
      appLockEnabled = settings['appLockEnabled'] ?? false;
      appPin = settings['appPin'] ?? '';
      adminDisplayName = settings['adminDisplayName'] ?? 'ادمین';
      lastBackupAt = settings['lastBackupAt'] ?? '';
      treeCardScale = (((settings['treeCardScale'] ?? 1.0) as num).toDouble().clamp(.8, 1.35) as num).toDouble();
      collapsedTreeUnits = Set<String>.from((settings['collapsedTreeUnits'] as List? ?? []).map((e) => e.toString()));
      subscriptionPlanId = settings['subscriptionPlanId'] ?? 'free';
      subscriptionSource = settings['subscriptionSource'] ?? 'free';
      subscriptionStartedAt = settings['subscriptionStartedAt'] ?? '';
      subscriptionExpiresAt = settings['subscriptionExpiresAt'] ?? '';
      subscriptionOrderId = settings['subscriptionOrderId'] ?? '';
      subscriptionPurchaseToken = settings['subscriptionPurchaseToken'] ?? '';
    }
    loaded = true;
    notifyListeners();
  }

  Map<String, dynamic> settingsJson() => {
        'showHelp': showHelp,
        'protectPhones': protectPhones,
        'appLockEnabled': appLockEnabled,
        'appPin': appPin,
        'adminDisplayName': adminDisplayName,
        'lastBackupAt': lastBackupAt,
        'treeCardScale': treeCardScale,
        'collapsedTreeUnits': collapsedTreeUnits.toList(),
        'subscriptionPlanId': subscriptionPlanId,
        'subscriptionSource': subscriptionSource,
        'subscriptionStartedAt': subscriptionStartedAt,
        'subscriptionExpiresAt': subscriptionExpiresAt,
        'subscriptionOrderId': subscriptionOrderId,
        'subscriptionPurchaseToken': subscriptionPurchaseToken,
      };

  Future<void> save() async {
    final pref = await SharedPreferences.getInstance();
    await pref.setString(storageKey, jsonEncode({'activeTreeId': activeTreeId, 'trees': trees.map((e) => e.toJson()).toList(), 'settings': settingsJson()}));
    notifyListeners();
  }

  Future<void> updateSettings({bool? help, bool? phones, bool? lock, String? pin, String? adminName, double? cardScale}) async {
    if (help != null) showHelp = help;
    if (phones != null) protectPhones = phones;
    if (lock != null) appLockEnabled = lock;
    if (pin != null) appPin = pin;
    if (adminName != null) adminDisplayName = adminName.trim().isEmpty ? 'ادمین' : adminName.trim();
    if (cardScale != null) treeCardScale = (cardScale.clamp(.8, 1.35) as num).toDouble();
    await save();
  }

  Future<void> activateSubscription(NasabSubscriptionPlan plan, {String source = kSubscriptionSourceBazaar, String orderId = '', String purchaseToken = ''}) async {
    final now = DateTime.now();
    subscriptionPlanId = plan.id;
    subscriptionSource = source;
    subscriptionStartedAt = now.toIso8601String();
    subscriptionExpiresAt = now.add(Duration(days: plan.days)).toIso8601String();
    subscriptionOrderId = orderId;
    subscriptionPurchaseToken = purchaseToken;
    await save();
  }

  Future<void> clearExpiredSubscriptionIfNeeded() async {
    if (subscriptionPlanId == 'free') return;
    final expires = DateTime.tryParse(subscriptionExpiresAt);
    if (expires != null && DateTime.now().isAfter(expires)) {
      subscriptionPlanId = 'free';
      subscriptionSource = 'free';
      subscriptionStartedAt = '';
      subscriptionExpiresAt = '';
      subscriptionOrderId = '';
      subscriptionPurchaseToken = '';
      await save();
    }
  }

  Future<String> activateSubscriptionFromBazaarProduct(String productId, {String orderId = '', String purchaseToken = ''}) async {
    final plan = planById(productId);
    if (plan == null) return 'شناسه اشتراک معتبر نیست.';
    await activateSubscription(plan, source: kSubscriptionSourceBazaar, orderId: orderId, purchaseToken: purchaseToken);
    return '${plan.title} فعال شد.';
  }

  bool isTreeUnitCollapsed(String key) => collapsedTreeUnits.contains(key);

  Future<void> toggleTreeUnit(String key) async {
    if (collapsedTreeUnits.contains(key)) {
      collapsedTreeUnits.remove(key);
    } else {
      collapsedTreeUnits.add(key);
    }
    await save();
  }

  Future<void> expandAllTreeUnits() async {
    collapsedTreeUnits.clear();
    await save();
  }

  Future<void> collapseTreeUnit(String key) async {
    collapsedTreeUnits.add(key);
    await save();
  }

  bool checkPin(String pin) => appPin.isNotEmpty && pin.trim() == appPin;

  Future<String> clearAllLocalData() async {
    await createSafetySnapshot(reason: 'before-clear-all');
    trees.clear();
    activeTreeId = null;
    await save();
    return 'اطلاعات پاک شد. آخرین بکاپ امن داخلی قبل از پاک‌سازی ثبت شد.';
  }

  String nextPersonCode(FamilyTree tree) {
    var maxNumber = 0;
    for (final person in tree.people) {
      final match = RegExp(r'FAM-(\d+)').firstMatch(person.code);
      if (match != null) {
        maxNumber = max(maxNumber, int.tryParse(match.group(1) ?? '0') ?? 0);
      }
    }
    return 'FAM-${(maxNumber + 1).toString().padLeft(6, '0')}';
  }
  String nextTreeCode() => 'TREE-${(trees.length + 1).toString().padLeft(4, '0')}';

  Future<String> createTree({required String title, required String owner, String phone = '', String branch = ''}) async {
    await clearExpiredSubscriptionIfNeeded();
    if (!canCreateFreeTree) return freeLimitMessage(feature: 'ساخت بیش از یک شجره');
    final tree = FamilyTree(id: _uuid.v4(), code: nextTreeCode(), title: title, ownerName: owner, ownerPhone: phone, branch: branch);
    tree.members.add(TreeMember(id: _uuid.v4(), name: owner, phone: phone, role: 'ادمین اصلی'));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'شجره ساخته شد', actor: owner));
    trees.add(tree);
    activeTreeId = tree.id;
    await save();
    return 'شجره ساخته شد.';
  }

  Future<void> selectTree(String id) async {
    activeTreeId = id;
    await save();
  }

  Future<String> addOrUpdatePerson(Person person, {String actor = 'ادمین'}) async {
    final tree = current;
    if (tree == null) return 'اول یک شجره بساز.';
    if (person.name.trim().isEmpty) return 'نام شخص خالی است.';
    final existingIndex = tree.people.indexWhere((e) => e.id == person.id);

    if (existingIndex == -1) {
      await clearExpiredSubscriptionIfNeeded();
      if (!canAddPeopleCount(1)) return freeLimitMessage(feature: 'ثبت بیش از ۲۵ نفر');
      autoPlace(tree, person);
      person.code = nextPersonCode(tree);
      tree.people.add(person);
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'شخص ${person.name} اضافه شد', actor: actor));
      if (person.phone.trim().isNotEmpty) {
        tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'دعوت برای ${person.name} آماده است', actor: actor));
      }
    } else {
      autoPlace(tree, person);
      tree.people[existingIndex] = person;
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'اطلاعات ${person.name} ویرایش شد', actor: actor));
    }
    await save();
    return 'ثبت شد و در شجره نمایش داده می‌شود.';
  }

  void autoPlace(FamilyTree tree, Person person) {
    final fatherName = cleanText(person.fatherName);
    final grandName = cleanText(person.grandfatherName);
    if (fatherName.isEmpty) return;

    Person? grand;
    if (grandName.isNotEmpty) {
      grand = _findByNameAndFather(tree, person.grandfatherName, '');
      grand ??= _firstByName(tree, person.grandfatherName);
      if (grand == null) {
        await clearExpiredSubscriptionIfNeeded();
        if (!canAddPeopleCount(1)) return freeLimitMessage(feature: 'ثبت بیش از ۲۵ نفر');
        grand = Person(
          id: _uuid.v4(),
          code: nextPersonCode(tree),
          name: person.grandfatherName.trim(),
          branch: person.branch,
          livingPlace: person.livingPlace,
          createdBy: 'سیستم',
        );
        tree.people.add(grand);
        tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'پدربزرگ ${grand.name} خودکار ساخته شد', actor: 'سیستم'));
      }
    }

    Person? father;
    if (person.fatherId != null) {
      father = tree.people.where((p) => p.id == person.fatherId).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);
      if (father != null && !looseEquals(father.name, person.fatherName)) father = null;
    }

    father ??= _findByNameAndFather(tree, person.fatherName, person.grandfatherName);
    father ??= tree.people.where((p) {
      if (looseScore(p.name, person.fatherName) < 70) return false;
      if (grand == null) return true;
      return p.fatherId == grand.id || looseEquals(p.fatherName, grandName);
    }).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);

    if (father == null) {
      father = Person(
        id: _uuid.v4(),
        code: nextPersonCode(tree),
        name: person.fatherName.trim(),
        fatherName: grand?.name ?? person.grandfatherName.trim(),
        fatherId: grand?.id,
        branch: person.branch,
        livingPlace: person.livingPlace,
        createdBy: 'سیستم',
      );
      tree.people.add(father);
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'پدر ${father.name} خودکار ساخته شد', actor: 'سیستم'));
    } else if (grand != null) {
      father.fatherId ??= grand.id;
      father.fatherName = grand.name;
      if (father.branch.trim().isEmpty && person.branch.trim().isNotEmpty) father.branch = person.branch;
    }

    person.fatherId = father.id;
    person.fatherName = father.name;
    if (grand != null) person.grandfatherName = grand.name;
  }



  List<String> splitFamilyNames(String raw) {
    return raw
        .replaceAll('\n', '،')
        .replaceAll(',', '،')
        .split(RegExp(r'\s*،\s*|\s+و\s*'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  List<Person> findFamilyHeadCandidates(String headName, String headFatherName, {String headGrandfatherName = ''}) {
    final tree = current;
    if (tree == null) return [];
    final n = looseText(headName);
    final f = looseText(headFatherName);
    final g = looseText(headGrandfatherName);
    if (n.isEmpty) return [];

    final scored = <MapEntry<Person, int>>[];
    for (final p in tree.people) {
      final nameScore = looseScore(p.name, n);
      if (nameScore < 70) continue;
      var score = nameScore;
      if (f.isNotEmpty) {
        final father = personById(p.fatherId);
        final fatherScore = max(looseScore(p.fatherName, f), looseScore(father?.name ?? '', f));
        if (fatherScore < 65) {
          score -= 20;
        } else {
          score += 25;
        }
      }
      if (g.isNotEmpty) {
        final father = personById(p.fatherId);
        final grand = personById(father?.fatherId);
        final grandScore = [
          looseScore(p.grandfatherName, g),
          looseScore(father?.fatherName ?? '', g),
          looseScore(grand?.name ?? '', g),
        ].reduce(max);
        if (grandScore < 65) {
          score -= 12;
        } else {
          score += 18;
        }
      }
      if (score >= 72) scored.add(MapEntry(p, score));
    }

    scored.sort((a, b) => b.value.compareTo(a.value));
    return scored.map((e) => e.key).toList();
  }

  Person? _firstByName(FamilyTree tree, String name) {
    final n = looseText(name);
    if (n.isEmpty) return null;
    Person? best;
    var bestScore = 0;
    for (final p in tree.people) {
      final score = looseScore(p.name, n);
      if (score > bestScore) {
        best = p;
        bestScore = score;
      }
    }
    return bestScore >= 82 ? best : null;
  }

  Person? _findByNameAndFather(FamilyTree tree, String name, String fatherName, {String grandfatherName = ''}) {
    final n = looseText(name);
    final f = looseText(fatherName);
    final g = looseText(grandfatherName);
    if (n.isEmpty) return null;

    Person? best;
    var bestScore = 0;

    for (final p in tree.people) {
      final nameScore = looseScore(p.name, n);
      if (nameScore < 70) continue;

      var score = nameScore;
      if (f.isNotEmpty) {
        final father = tree.people.where((x) => x.id == p.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
        final fatherScore = max(looseScore(p.fatherName, f), looseScore(father?.name ?? '', f));
        if (fatherScore < 70) {
          score -= 26;
        } else {
          score += 25;
        }

        if (g.isNotEmpty) {
          final grand = tree.people.where((x) => x.id == father?.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
          final grandScore = [
            looseScore(p.grandfatherName, g),
            looseScore(father?.fatherName ?? '', g),
            looseScore(grand?.name ?? '', g),
          ].reduce(max);
          if (grandScore >= 70) {
            score += 20;
          } else {
            score -= 10;
          }
        }
      }

      if (score > bestScore) {
        bestScore = score;
        best = p;
      }
    }

    return bestScore >= (f.isEmpty ? 82 : 72) ? best : null;
  }

  Person? _findExistingChild(FamilyTree tree, String childName, Person father) {
    final childClean = cleanText(childName);
    for (final p in tree.people) {
      final sameName = looseScore(p.name, childClean) >= 82;
      final sameFather = p.fatherId == father.id || looseEquals(p.fatherName, father.name);
      if (sameName && sameFather) return p;
    }
    return null;
  }

  Person? _findExistingSpouse(FamilyTree tree, String spouseName, Person head, String spouseFatherName) {
    final spouseClean = cleanText(spouseName);
    final spouseFatherClean = cleanText(spouseFatherName);
    for (final p in tree.people) {
      if (looseScore(p.name, spouseClean) < 82) continue;
      final alreadyLinked = p.spouseId == head.id || head.spouseId == p.id || looseEquals(p.spouseName, head.name);
      final fatherMatches = spouseFatherClean.isEmpty || looseEquals(p.fatherName, spouseFatherClean);
      if (alreadyLinked || fatherMatches) return p;
    }
    return null;
  }

  void _mergeInto(FamilyTree tree, Person keep, Person remove) {
    if (keep.id == remove.id) return;
    if (keep.phone.trim().isEmpty) keep.phone = remove.phone;
    if (keep.fatherName.trim().isEmpty) keep.fatherName = remove.fatherName;
    if (keep.grandfatherName.trim().isEmpty) keep.grandfatherName = remove.grandfatherName;
    if (keep.motherName.trim().isEmpty) keep.motherName = remove.motherName;
    if (keep.fatherId == null) keep.fatherId = remove.fatherId;
    if (keep.motherId == null) keep.motherId = remove.motherId;
    if (keep.spouseId == null) keep.spouseId = remove.spouseId;
    if (keep.spouseName.trim().isEmpty) keep.spouseName = remove.spouseName;
    if (keep.branch.trim().isEmpty) keep.branch = remove.branch;
    if (keep.livingPlace.trim().isEmpty) keep.livingPlace = remove.livingPlace;
    if (keep.notes.trim().isEmpty) keep.notes = remove.notes;
    for (final p in tree.people) {
      if (p.fatherId == remove.id) p.fatherId = keep.id;
      if (p.motherId == remove.id) p.motherId = keep.id;
      if (p.spouseId == remove.id) p.spouseId = keep.id;
      if (cleanText(p.fatherName) == cleanText(remove.name) && p.fatherId == keep.id) p.fatherName = keep.name;
      if (cleanText(p.motherName) == cleanText(remove.name) && p.motherId == keep.id) p.motherName = keep.name;
      if (cleanText(p.spouseName) == cleanText(remove.name) && p.spouseId == keep.id) p.spouseName = keep.name;
    }
    tree.people.removeWhere((p) => p.id == remove.id);
  }

  int dedupeSmart(FamilyTree tree) {
    var removed = 0;
    var changed = true;
    while (changed) {
      changed = false;
      outer:
      for (var i = 0; i < tree.people.length; i++) {
        for (var j = i + 1; j < tree.people.length; j++) {
          final a = tree.people[i];
          final b = tree.people[j];
          if (cleanText(a.name) != cleanText(b.name)) continue;
          final sameFatherId = a.fatherId != null && a.fatherId == b.fatherId;
          final sameFatherName = cleanText(a.fatherName) == cleanText(b.fatherName) && cleanText(a.grandfatherName) == cleanText(b.grandfatherName);
          final bothRootSame = (a.fatherId == null && b.fatherId == null && cleanText(a.fatherName).isEmpty && cleanText(b.fatherName).isEmpty);
          if (sameFatherId || sameFatherName || bothRootSame) {
            final keep = a.code.compareTo(b.code) <= 0 ? a : b;
            final remove = keep.id == a.id ? b : a;
            _mergeInto(tree, keep, remove);
            removed++;
            changed = true;
            break outer;
          }
        }
      }
    }
    if (removed > 0) tree.logs.add(ActivityLog(id: _uuid.v4(), text: '$removed شخص تکراری خودکار ادغام شد', actor: 'سیستم'));
    return removed;
  }

  Future<String> addFullFamily({
    required String headName,
    required String headFatherName,
    String headGrandfatherName = '',
    String headPhone = '',
    required String spouseName,
    String spouseFatherName = '',
    String spousePhone = '',
    String sonsRaw = '',
    String daughtersRaw = '',
    String branch = '',
    String livingPlace = '',
    String notes = '',
    String? selectedHeadId,
    String actor = 'ادمین',
  }) async {
    final tree = current;
    if (tree == null) return 'اول یک شجره بساز.';
    if (headName.trim().isEmpty) return 'نام پدر خانواده خالی است.';

    final candidates = findFamilyHeadCandidates(headName, headFatherName, headGrandfatherName: headGrandfatherName);
    Person? head;
    if (selectedHeadId != null && selectedHeadId.isNotEmpty) {
      head = tree.people.where((p) => p.id == selectedHeadId).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);
    } else if (candidates.length == 1) {
      head = candidates.first;
    } else if (candidates.length > 1) {
      return 'چند شخص مشابه پیدا شد. قبل از ثبت، جایگاه دقیق پدر خانواده را انتخاب کن.';
    }

    var createdCount = 0;
    var updatedCount = 0;
    if (head == null) {
      head = Person(
        id: _uuid.v4(),
        code: '',
        name: headName.trim(),
        fatherName: headFatherName.trim(),
        grandfatherName: headGrandfatherName.trim(),
        phone: headPhone.trim(),
        gender: 'مرد',
        branch: branch.trim(),
        livingPlace: livingPlace.trim(),
        notes: notes.trim(),
        createdBy: actor,
      );
      autoPlace(tree, head);
      head.code = nextPersonCode(tree);
      tree.people.add(head);
      createdCount++;
    } else {
      if (headFatherName.trim().isNotEmpty) head.fatherName = headFatherName.trim();
      if (headGrandfatherName.trim().isNotEmpty) head.grandfatherName = headGrandfatherName.trim();
      if (headPhone.trim().isNotEmpty) head.phone = headPhone.trim();
      if (branch.trim().isNotEmpty) head.branch = branch.trim();
      if (livingPlace.trim().isNotEmpty) head.livingPlace = livingPlace.trim();
      if (notes.trim().isNotEmpty) head.notes = notes.trim();
      autoPlace(tree, head);
      updatedCount++;
    }

    final Person headPerson = head!;
    Person? spouse;
    if (spouseName.trim().isNotEmpty) {
      final currentSpouse = safeSpouseOf(headPerson);
      if (currentSpouse != null && looseScore(currentSpouse.name, spouseName) < 82) {
        return 'برای ${headPerson.name} قبلاً همسر «${currentSpouse.name}» ثبت شده. اول رابطه قبلی را حذف یا اصلاح کن.';
      }

      spouse = _findExistingSpouse(tree, spouseName, headPerson, spouseFatherName);
      spouse ??= _findByNameAndFather(tree, spouseName, spouseFatherName);
      spouse ??= _firstByName(tree, spouseName);

      if (spouse != null) {
        final spouseCurrent = safeSpouseOf(spouse);
        if (spouseCurrent != null && spouseCurrent.id != headPerson.id) {
          return 'برای ${spouse.name} قبلاً همسر «${spouseCurrent.name}» ثبت شده. اول رابطه قبلی را اصلاح کن.';
        }
      }

      if (spouse == null) {
        spouse = Person(
          id: _uuid.v4(),
          code: '',
          name: spouseName.trim(),
          fatherName: spouseFatherName.trim(),
          phone: spousePhone.trim(),
          gender: 'زن',
          branch: branch.trim(),
          livingPlace: livingPlace.trim(),
          createdBy: actor,
        );
        autoPlace(tree, spouse);
        spouse.code = nextPersonCode(tree);
        tree.people.add(spouse);
        createdCount++;
      } else {
        if (spouseFatherName.trim().isNotEmpty) spouse.fatherName = spouseFatherName.trim();
        if (spousePhone.trim().isNotEmpty) spouse.phone = spousePhone.trim();
        if (branch.trim().isNotEmpty) spouse.branch = branch.trim();
        if (livingPlace.trim().isNotEmpty) spouse.livingPlace = livingPlace.trim();
        if (spouse.gender == 'نامشخص') spouse.gender = 'زن';
        autoPlace(tree, spouse);
        updatedCount++;
      }
      headPerson.spouseId = spouse.id;
      headPerson.spouseName = spouse.name;
      spouse.spouseId = headPerson.id;
      spouse.spouseName = headPerson.name;
      await repairSpouseLinks(tree);
    }

    void addChildren(List<String> names, String gender) {
      for (final childName in names) {
        final existing = _findExistingChild(tree, childName, headPerson);
        if (existing == null) {
          final child = Person(
            id: _uuid.v4(),
            code: nextPersonCode(tree),
            name: childName,
            fatherName: headPerson.name,
            grandfatherName: headPerson.fatherName,
            motherName: spouse?.name ?? '',
            fatherId: headPerson.id,
            motherId: spouse?.id,
            gender: gender,
            branch: branch.trim().isNotEmpty ? branch.trim() : headPerson.branch,
            livingPlace: livingPlace.trim(),
            createdBy: actor,
          );
          tree.people.add(child);
          createdCount++;
        } else {
          existing.fatherId = headPerson.id;
          existing.fatherName = headPerson.name;
          existing.grandfatherName = headPerson.fatherName;
          existing.motherId = spouse?.id ?? existing.motherId;
          existing.motherName = spouse?.name ?? existing.motherName;
          existing.gender = gender;
          if (branch.trim().isNotEmpty) existing.branch = branch.trim();
          if (livingPlace.trim().isNotEmpty) existing.livingPlace = livingPlace.trim();
          updatedCount++;
        }
      }
    }

    addChildren(splitFamilyNames(sonsRaw), 'مرد');
    addChildren(splitFamilyNames(daughtersRaw), 'زن');

    final deduped = dedupeSmart(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'خانواده ${headPerson.name}${spouse == null ? '' : ' و ${spouse.name}'} یک‌جا ثبت شد؛ $createdCount مورد جدید، $updatedCount مورد به‌روزرسانی، $deduped تکراری ادغام شد', actor: actor));
    await save();
    return 'خانواده ثبت شد؛ $createdCount شخص جدید، $updatedCount به‌روزرسانی و $deduped تکراری ادغام شد.';
  }

  Person? _findByName(FamilyTree tree, String cleanedName) {
    for (final p in tree.people) {
      if (cleanText(p.name) == cleanedName) return p;
    }
    return null;
  }

  List<Person> searchPeople(String q) {
    final tree = current;
    if (tree == null) return [];
    final c = cleanText(q);
    if (c.isEmpty) return tree.people;
    return tree.people.where((p) {
      return cleanText(p.name).contains(c) ||
          cleanText(p.fatherName).contains(c) ||
          cleanText(p.grandfatherName).contains(c) ||
          cleanText(p.motherName).contains(c) ||
          cleanText(p.spouseName).contains(c) ||
          cleanText(p.code).contains(c) ||
          cleanText(p.branch).contains(c) ||
          cleanText(p.phone).contains(c) ||
          cleanText(p.livingPlace).contains(c) ||
          cleanText(p.specialTag).contains(c) ||
          cleanText(p.notes).contains(c);
    }).toList();
  }

  Person? personById(String? id) {
    final tree = current;
    if (tree == null || id == null) return null;
    for (final p in tree.people) {
      if (p.id == id) return p;
    }
    return null;
  }

  List<Person> childrenOf(String id) => current?.people.where((p) => p.fatherId == id || p.motherId == id).toList() ?? [];

  List<Person> siblingsOf(Person p) {
    final tree = current;
    if (tree == null || p.fatherId == null) return [];
    return tree.people.where((x) => x.id != p.id && x.fatherId == p.fatherId).toList();
  }

  List<String> ancestorPath(String personId) {
    final path = <String>[];
    var currentId = personId;
    final seen = <String>{};
    while (true) {
      if (seen.contains(currentId)) break;
      seen.add(currentId);
      final p = personById(currentId);
      if (p == null) break;
      path.add(p.id);
      if (p.fatherId == null || p.fatherId!.isEmpty) break;
      currentId = p.fatherId!;
    }
    return path;
  }

  String relationBetween(Person a, Person b) {
    if (a.id == b.id) return 'همان شخص است.';
    final pathA = ancestorPath(a.id);
    final pathB = ancestorPath(b.id);
    final indexAtoB = pathA.indexOf(b.id);
    if (indexAtoB == 1) return '${b.name} پدر ${a.name} است.';
    if (indexAtoB == 2) return '${b.name} پدربزرگ ${a.name} است.';
    if (indexAtoB > 2) return '${b.name} از اجداد ${a.name} است.';
    final indexBtoA = pathB.indexOf(a.id);
    if (indexBtoA == 1) return '${a.name} پدر ${b.name} است.';
    if (indexBtoA == 2) return '${a.name} پدربزرگ ${b.name} است.';
    if (indexBtoA > 2) return '${a.name} از اجداد ${b.name} است.';
    for (final x in pathA) {
      if (pathB.contains(x)) {
        final da = pathA.indexOf(x);
        final db = pathB.indexOf(x);
        if (da == 1 && db == 1) return '${a.name} و ${b.name} خواهر/برادر یا هم‌نسل از یک پدر هستند.';
        if (da == 2 && db == 2) return '${a.name} و ${b.name} پسرعمو/دخترعمو یا هم‌نسل از یک پدربزرگ هستند.';
        return 'نسبت از طریق جد مشترک پیدا شد. فاصله نسل‌ها: $da و $db';
      }
    }
    return 'نسبت مستقیم پیدا نشد.';
  }

  List<List<Person>> duplicateGroups() {
    final tree = current;
    if (tree == null) return [];
    final map = <String, List<Person>>{};
    for (final p in tree.people) {
      final key = '${cleanText(p.name)}|${cleanText(p.fatherName)}|${cleanText(p.grandfatherName)}';
      map.putIfAbsent(key, () => []).add(p);
    }
    return map.values.where((g) => g.length > 1).toList();
  }

  Future<void> mergePersons(Person keep, Person remove) async {
    final tree = current;
    if (tree == null) return;
    for (final p in tree.people) {
      if (p.fatherId == remove.id) p.fatherId = keep.id;
      if (p.motherId == remove.id) p.motherId = keep.id;
    }
    tree.people.removeWhere((p) => p.id == remove.id);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '${remove.name} با ${keep.name} ادغام شد', actor: 'ادمین'));
    await save();
  }

  Future<void> addMember(String name, String phone, String role, {bool approved = true}) async {
    final tree = current;
    if (tree == null) return;
    tree.members.add(TreeMember(id: _uuid.v4(), name: name, phone: phone, role: role, approved: approved));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'عضو $name با نقش $role اضافه شد'));
    await save();
  }

  Future<void> addRequest(String name, String phone, String note) async {
    final tree = current;
    if (tree == null) return;
    tree.requests.add(AccessRequest(id: _uuid.v4(), name: name, phone: phone, note: note));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'درخواست عضویت $name ثبت شد'));
    await save();
  }

  Future<void> approveRequest(AccessRequest r) async {
    final tree = current;
    if (tree == null) return;
    r.status = 'تأیید شده';
    tree.members.add(TreeMember(id: _uuid.v4(), name: r.name, phone: r.phone, role: 'عضو', approved: true));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'درخواست ${r.name} تأیید شد'));
    await save();
  }

  Future<void> addItem(String title, String description, String type, String personId) async {
    final tree = current;
    if (tree == null) return;
    tree.items.add(FamilyItem(id: _uuid.v4(), title: title, description: description, type: type, personId: personId));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '$type جدید ثبت شد: $title'));
    await save();
  }

  Future<void> addEvent(String title, String date, String type, String notes, String personId) async {
    final tree = current;
    if (tree == null) return;
    tree.events.add(FamilyEvent(id: _uuid.v4(), title: title, date: date, type: type, notes: notes, personId: personId));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'رویداد جدید: $title'));
    await save();
  }

  Future<void> addChat(String sender, String text) async {
    final tree = current;
    if (tree == null) return;
    tree.chats.add(ChatMessage(id: _uuid.v4(), sender: sender, text: text));
    await save();
  }

  Future<void> addPoll(String question, List<String> options, bool secret) async {
    final tree = current;
    if (tree == null) return;
    tree.polls.add(Poll(id: _uuid.v4(), question: question, options: options, secret: secret));
    await save();
  }

  Future<void> vote(Poll poll, String option) async {
    poll.votes[option] = (poll.votes[option] ?? 0) + 1;
    await save();
  }


  List<Person> orphanedPeople() {
    final tree = current;
    if (tree == null) return [];
    return tree.people.where((p) {
      final hasFatherText = p.fatherName.trim().isNotEmpty;
      final hasMotherText = p.motherName.trim().isNotEmpty;
      final missingFatherLink = hasFatherText && p.fatherId == null;
      final missingMotherLink = hasMotherText && p.motherId == null;
      return missingFatherLink || missingMotherLink;
    }).toList();
  }

  String treeSummaryText() {
    final tree = current;
    if (tree == null) return 'شجره‌ای ثبت نشده است.';
    final peopleCount = tree.people.length;
    final men = tree.people.where((p) => p.gender == 'مرد').length;
    final women = tree.people.where((p) => p.gender == 'زن').length;
    final couples = tree.people.where((p) => p.spouseId != null).length ~/ 2;
    final roots = tree.people.where((p) => p.fatherId == null && p.motherId == null).length;
    final incomplete = orphanedPeople().length;
    final lines = <String>[
      'خلاصه شجره‌نامه: ${tree.title}',
      'کد شجره: ${tree.code}',
      'ادمین اصلی: ${tree.ownerName}',
      'تعداد افراد: $peopleCount',
      'مردان: $men',
      'زنان: $women',
      'زوج‌ها: $couples',
      'ریشه‌ها/افراد بالادستی: $roots',
      'روابط ناقص: $incomplete',
      '',
      'افراد:',
      ...tree.people.map((p) {
        final spouse = personById(p.spouseId)?.name ?? p.spouseName;
        return '- ${p.name} | کد: ${p.code}${p.fatherName.isEmpty ? '' : ' | فرزند ${p.fatherName}'}${spouse.isEmpty ? '' : ' | همسر: $spouse'}';
      }),
    ];
    return lines.join('\n');
  }

  Future<String> autoRepairCurrentTree() async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';
    await createSafetySnapshot(reason: 'before-auto-repair');

    var fatherLinks = 0;
    var motherLinks = 0;
    var spouseLinks = 0;
    var spouseBackLinks = 0;

    for (final p in tree.people) {
      if (p.fatherId == null && p.fatherName.trim().isNotEmpty) {
        final f = _findByNameAndFather(tree, p.fatherName, p.grandfatherName);
        if (f != null && f.id != p.id) {
          p.fatherId = f.id;
          p.fatherName = f.name;
          p.grandfatherName = f.fatherName;
          fatherLinks++;
        }
      }

      if (p.motherId == null && p.motherName.trim().isNotEmpty) {
        final m = firstWhereOrNull<Person>(tree.people, (x) => cleanText(x.name) == cleanText(p.motherName));
        if (m != null && m.id != p.id) {
          p.motherId = m.id;
          p.motherName = m.name;
          motherLinks++;
        }
      }

      if (p.spouseId == null && p.spouseName.trim().isNotEmpty) {
        final sp = firstWhereOrNull<Person>(tree.people, (x) => cleanText(x.name) == cleanText(p.spouseName));
        if (sp != null && sp.id != p.id) {
          p.spouseId = sp.id;
          sp.spouseId = p.id;
          sp.spouseName = p.name;
          spouseLinks++;
        }
      }

      if (p.spouseId != null) {
        final sp = personById(p.spouseId);
        if (sp != null && sp.spouseId != p.id) {
          sp.spouseId = p.id;
          sp.spouseName = p.name;
          spouseBackLinks++;
        }
      }
    }

    final spouseFixed = await repairSpouseLinks(tree);
    final deduped = dedupeSmart(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'اصلاح خودکار: $fatherLinks پدر، $motherLinks مادر، $spouseLinks همسر، $spouseBackLinks همسر دوطرفه، $spouseFixed پاک‌سازی همسر، $deduped تکراری', actor: 'سیستم'));
    await save();
    return 'اصلاح انجام شد: $fatherLinks پدر، $motherLinks مادر، $spouseLinks همسر، $spouseBackLinks رابطه همسر دوطرفه، $spouseFixed پاک‌سازی همسر و $deduped تکراری ادغام شد.';
  }

  Future<String> deletePerson(Person person) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';
    await createSafetySnapshot(reason: 'before-delete-person');

    for (final p in tree.people) {
      if (p.fatherId == person.id) {
        p.fatherId = null;
        if (cleanText(p.fatherName) == cleanText(person.name)) p.fatherName = '';
      }
      if (p.motherId == person.id) {
        p.motherId = null;
        if (cleanText(p.motherName) == cleanText(person.name)) p.motherName = '';
      }
      if (p.spouseId == person.id) {
        p.spouseId = null;
        if (cleanText(p.spouseName) == cleanText(person.name)) p.spouseName = '';
      }
    }

    tree.people.removeWhere((p) => p.id == person.id);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'شخص ${person.name} حذف شد و رابطه‌های وابسته پاک‌سازی شد', actor: 'ادمین'));
    await save();
    return '${person.name} حذف شد.';
  }


  String treeUnitKeyForPerson(Person person) {
    final spouse = safeSpouseOf(person);
    if (spouse != null && spouse.id != person.id) {
      final ids = [person.id, spouse.id]..sort();
      return ids.join('__');
    }
    return person.id;
  }

  Person? safeSpouseOf(Person person) {
    final tree = current;
    if (tree == null) return null;
    if (person.spouseId != null && person.spouseId != person.id) {
      final byId = personById(person.spouseId);
      if (byId != null && byId.id != person.id) {
        final reciprocal = byId.spouseId == person.id || looseEquals(byId.spouseName, person.name);
        if (reciprocal) return byId;
      }
    }
    if (person.spouseName.trim().isNotEmpty) {
      final candidate = firstWhereOrNull<Person>(tree.people, (p) {
        if (p.id == person.id) return false;
        if (looseScore(p.name, person.spouseName) < 82) return false;
        return p.spouseId == null || p.spouseId == person.id || looseEquals(p.spouseName, person.name);
      });
      if (candidate != null) return candidate;
    }
    return null;
  }

  Future<int> repairSpouseLinks(FamilyTree tree) async {
    var fixed = 0;

    for (final p in tree.people) {
      if (p.spouseId == p.id) {
        p.spouseId = null;
        p.spouseName = '';
        fixed++;
      }
      if (p.spouseId != null && !tree.people.any((x) => x.id == p.spouseId)) {
        p.spouseId = null;
        fixed++;
      }
    }

    // در مدل چندهمسری سبک، یک نفر می‌تواند چند رابطه reverse داشته باشد.
    // بنابراین دیگر رابطه‌های همسر قبلی پاک نمی‌شوند؛ فقط لینک‌های نامعتبر اصلاح می‌شوند.
    for (final p in tree.people) {
      if (p.spouseId == null) continue;
      final spouse = tree.people.where((x) => x.id == p.spouseId && x.id != p.id).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
      if (spouse == null) continue;
      if (!looseEquals(p.spouseName, spouse.name)) {
        p.spouseName = spouse.name;
        fixed++;
      }
      // اگر طرف مقابل هنوز هیچ همسری ندارد، رابطه دوطرفه کامل می‌شود.
      // اگر دارد، آن را نمی‌شکنیم تا چندهمسری خراب نشود.
      if (spouse.spouseId == null && spouse.spouseName.trim().isEmpty) {
        spouse.spouseId = p.id;
        spouse.spouseName = p.name;
      }
    }

    return fixed;
  }

  List<Person> spousesForPerson(FamilyTree tree, Person person) {
    final map = <String, Person>{};
    for (final p in tree.people) {
      if (p.id == person.id) continue;
      final direct = person.spouseId == p.id || looseEquals(person.spouseName, p.name);
      final reverse = p.spouseId == person.id || looseEquals(p.spouseName, person.name);
      if (direct || reverse) map[p.id] = p;
    }
    final list = map.values.toList();
    list.sort((a, b) => looseText(a.name).compareTo(looseText(b.name)));
    return list;
  }

  Future<String> addSpouseForPerson(Person person, {required String spouseName, String spouseFatherName = '', String gender = ''}) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';
    if (spouseName.trim().isEmpty) return 'نام همسر خالی است.';

    final currentSpouses = spousesForPerson(tree, person);
    final already = firstWhereOrNull<Person>(currentSpouses, (p) => looseScore(p.name, spouseName) >= 82);
    if (already != null) return 'این همسر قبلاً برای ${person.name} ثبت شده است.';
    if (currentSpouses.length >= 4) return 'حداکثر ۴ همسر قابل ثبت است.';

    final targetGender = gender.trim().isNotEmpty ? gender : (person.gender == 'زن' ? 'مرد' : 'زن');
    var spouse = _findExistingSpouse(tree, spouseName, person, spouseFatherName);
    spouse ??= _findByNameAndFather(tree, spouseName, spouseFatherName);
    spouse ??= _firstByName(tree, spouseName);

    if (spouse != null && spouse.id == person.id) {
      return 'یک شخص نمی‌تواند همسر خودش باشد.';
    }

    if (spouse != null) {
      final spouseSpouses = spousesForPerson(tree, spouse);
      if (!spouseSpouses.any((p) => p.id == person.id) && spouseSpouses.length >= 4) {
        return 'برای ${spouse.name} حداکثر ۴ همسر ثبت شده است.';
      }
    }

    if (spouse == null) {
      await clearExpiredSubscriptionIfNeeded();
      if (!canAddPeopleCount(1)) return freeLimitMessage(feature: 'ثبت بیش از ۲۵ نفر');
      spouse = Person(
        id: _uuid.v4(),
        code: nextPersonCode(tree),
        name: spouseName.trim(),
        fatherName: spouseFatherName.trim(),
        gender: targetGender,
        branch: person.branch,
        livingPlace: person.livingPlace,
        createdBy: 'ادمین',
      );
      autoPlace(tree, spouse);
      tree.people.add(spouse);
    } else {
      if (spouseFatherName.trim().isNotEmpty) spouse.fatherName = spouseFatherName.trim();
      if (spouse.gender == 'نامشخص') spouse.gender = targetGender;
      autoPlace(tree, spouse);
    }

    // همسر اول به‌صورت مستقیم روی خود شخص ثبت می‌شود.
    // همسرهای بعدی به‌صورت reverse روی کارت همسر ذخیره می‌شوند تا رابطه قبلی خراب نشود.
    if (person.spouseId == null && person.spouseName.trim().isEmpty) {
      person.spouseId = spouse.id;
      person.spouseName = spouse.name;
      if (spouse.spouseId == null && spouse.spouseName.trim().isEmpty) {
        spouse.spouseId = person.id;
        spouse.spouseName = person.name;
      }
    } else {
      spouse.spouseId = person.id;
      spouse.spouseName = person.name;
    }

    final fixed = await repairSpouseLinks(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'همسر ${person.name} ثبت/وصل شد؛ $fixed رابطه همسر پاک‌سازی شد', actor: 'ادمین'));
    await save();
    return 'همسر ثبت و وصل شد.';
  }

  Future<String> addParentForPerson(Person person, {required String parentName, required String type, String grandfatherName = ''}) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';
    if (parentName.trim().isEmpty) return 'نام والد خالی است.';

    final isFather = type == 'father';
    var parent = _findByNameAndFather(tree, parentName, grandfatherName);
    parent ??= _firstByName(tree, parentName);

    if (parent == null) {
      await clearExpiredSubscriptionIfNeeded();
      if (!canAddPeopleCount(1)) return freeLimitMessage(feature: 'ثبت بیش از ۲۵ نفر');
      parent = Person(
        id: _uuid.v4(),
        code: nextPersonCode(tree),
        name: parentName.trim(),
        fatherName: isFather ? grandfatherName.trim() : '',
        gender: isFather ? 'مرد' : 'زن',
        branch: person.branch,
        livingPlace: person.livingPlace,
        createdBy: 'ادمین',
      );
      autoPlace(tree, parent);
      tree.people.add(parent);
    }

    if (isFather && grandfatherName.trim().isNotEmpty) {
      var grand = _firstByName(tree, grandfatherName);
      if (grand == null) {
        grand = Person(
          id: _uuid.v4(),
          code: nextPersonCode(tree),
          name: grandfatherName.trim(),
          gender: 'مرد',
          branch: person.branch,
          createdBy: 'ادمین',
        );
        tree.people.add(grand);
      }
      parent.fatherId = grand.id;
      parent.fatherName = grand.name;
      person.grandfatherName = grand.name;
    }

    if (isFather) {
      person.fatherId = parent.id;
      person.fatherName = parent.name;
      if (grandfatherName.trim().isNotEmpty) person.grandfatherName = grandfatherName.trim();
    } else {
      person.motherId = parent.id;
      person.motherName = parent.name;
    }

    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '${isFather ? 'پدر' : 'مادر'} ${person.name} ثبت/وصل شد', actor: 'ادمین'));
    await save();
    return '${isFather ? 'پدر' : 'مادر'} ثبت و وصل شد.';
  }

  Future<String> addChildrenForPerson(Person parent, {String sonsRaw = '', String daughtersRaw = ''}) async {
    final sons = splitFamilyNames(sonsRaw);
    final daughters = splitFamilyNames(daughtersRaw);
    if (sons.isEmpty && daughters.isEmpty) return 'نام فرزند وارد نشده است.';

    var created = 0;
    var skipped = 0;
    for (final name in sons) {
      final msg = await addChildForParent(parent, childName: name, gender: 'مرد');
      msg.contains('قبلاً') ? skipped++ : created++;
    }
    for (final name in daughters) {
      final msg = await addChildForParent(parent, childName: name, gender: 'زن');
      msg.contains('قبلاً') ? skipped++ : created++;
    }
    return '$created فرزند ثبت شد${skipped > 0 ? ' و $skipped مورد تکراری بود' : ''}.';
  }

  Future<String> addQuickFamilyForPerson(
    Person person, {
    String spouseName = '',
    String spouseFatherName = '',
    String fatherName = '',
    String grandfatherName = '',
    String motherName = '',
    String sonsRaw = '',
    String daughtersRaw = '',
  }) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';

    var changes = 0;
    final messages = <String>[];

    if (fatherName.trim().isNotEmpty) {
      messages.add(await addParentForPerson(person, parentName: fatherName, type: 'father', grandfatherName: grandfatherName));
      changes++;
    }
    if (motherName.trim().isNotEmpty) {
      messages.add(await addParentForPerson(person, parentName: motherName, type: 'mother'));
      changes++;
    }
    if (spouseName.trim().isNotEmpty) {
      messages.add(await addSpouseForPerson(person, spouseName: spouseName, spouseFatherName: spouseFatherName));
      changes++;
    }

    if (sonsRaw.trim().isNotEmpty || daughtersRaw.trim().isNotEmpty) {
      messages.add(await addChildrenForPerson(person, sonsRaw: sonsRaw, daughtersRaw: daughtersRaw));
      changes++;
    }

    if (changes == 0) return 'چیزی برای ثبت وارد نشده است.';
    final deduped = dedupeSmart(tree);
    await save();
    return '${messages.join(' ')}${deduped > 0 ? ' $deduped تکراری ادغام شد.' : ''}';
  }

  Future<String> addChildForParent(Person parent, {required String childName, required String gender}) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';
    if (childName.trim().isEmpty) return 'نام فرزند خالی است.';

    final existing = firstWhereOrNull<Person>(tree.people, (p) {
      final sameName = looseScore(p.name, childName) >= 82;
      final linkedToParent = p.fatherId == parent.id || p.motherId == parent.id || looseEquals(p.fatherName, parent.name) || looseEquals(p.motherName, parent.name);
      return sameName && linkedToParent;
    });
    if (existing != null) return 'این فرزند قبلاً برای این خانواده ثبت شده است.';

    await clearExpiredSubscriptionIfNeeded();
    if (!canAddPeopleCount(1)) return freeLimitMessage(feature: 'ثبت بیش از ۲۵ نفر');
    final parentSpouses = spousesForPerson(tree, parent);
    final spouse = parentSpouses.isEmpty ? null : parentSpouses.first;
    final child = Person(
      id: _uuid.v4(),
      code: nextPersonCode(tree),
      name: childName.trim(),
      gender: gender,
      branch: parent.branch,
      livingPlace: parent.livingPlace,
      createdBy: 'ادمین',
    );

    if (parent.gender == 'زن') {
      child.motherId = parent.id;
      child.motherName = parent.name;
      if (spouse != null) {
        child.fatherId = spouse.id;
        child.fatherName = spouse.name;
        child.grandfatherName = spouse.fatherName;
      }
    } else {
      child.fatherId = parent.id;
      child.fatherName = parent.name;
      child.grandfatherName = parent.fatherName;
      if (spouse != null) {
        child.motherId = spouse.id;
        child.motherName = spouse.name;
      }
    }

    tree.people.add(child);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '${child.name} به عنوان فرزند ${parent.name} اضافه شد', actor: 'ادمین'));
    await save();
    return 'فرزند جدید ثبت شد.';
  }

  Future<String> updatePersonRelations({
    required Person person,
    String? fatherId,
    String? motherId,
    String? spouseId,
  }) async {
    final tree = current;
    if (tree == null) return 'شجره‌ای وجود ندارد.';

    final father = personById(fatherId);
    final mother = personById(motherId);
    final newSpouse = personById(spouseId);

    if (father?.id == person.id || mother?.id == person.id || newSpouse?.id == person.id) {
      return 'یک شخص نمی‌تواند با خودش رابطه مستقیم داشته باشد.';
    }

    if (newSpouse != null) {
      final other = safeSpouseOf(newSpouse);
      if (other != null && other.id != person.id) {
        return 'برای ${newSpouse.name} قبلاً همسر «${other.name}» ثبت شده. اول رابطه قبلی را حذف یا اصلاح کن.';
      }
    }

    final oldSpouse = safeSpouseOf(person);
    if (oldSpouse != null && oldSpouse.id != newSpouse?.id) {
      oldSpouse.spouseId = null;
      if (looseEquals(oldSpouse.spouseName, person.name)) oldSpouse.spouseName = '';
    }

    person.fatherId = father?.id;
    person.fatherName = father?.name ?? '';
    person.grandfatherName = father?.fatherName ?? person.grandfatherName;
    person.motherId = mother?.id;
    person.motherName = mother?.name ?? '';

    person.spouseId = newSpouse?.id;
    person.spouseName = newSpouse?.name ?? '';
    if (newSpouse != null) {
      newSpouse.spouseId = person.id;
      newSpouse.spouseName = person.name;
    }

    final fixed = await repairSpouseLinks(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'رابطه‌های ${person.name} ویرایش شد؛ $fixed رابطه همسر پاک‌سازی شد', actor: 'ادمین'));
    await save();
    return 'رابطه‌ها اصلاح شد.';
  }

  Future<String> detachParent(Person person, String type) async {
    if (type == 'father') {
      person.fatherId = null;
      person.fatherName = '';
      person.grandfatherName = '';
    } else {
      person.motherId = null;
      person.motherName = '';
    }
    await save();
    return 'رابطه حذف شد.';
  }

  Future<String> detachSpouse(Person person) async {
    final spouse = personById(person.spouseId);
    if (spouse != null) {
      spouse.spouseId = null;
      spouse.spouseName = '';
    }
    person.spouseId = null;
    person.spouseName = '';
    await save();
    return 'رابطه همسر حذف شد.';
  }

  String backupJson({String type = 'full-local-backup'}) => const JsonEncoder.withIndent('  ').convert({
        'meta': {
          'schemaVersion': 4,
          'appVersion': '5.8.0+41-bazaar-subscription',
          'type': type,
          'exportedAt': nowIso(),
          'readyForOnlineMigration': true,
        },
        'activeTreeId': activeTreeId,
        'trees': trees.map((e) => e.toJson()).toList(),
        'settings': settingsJson(),
      });

  String safeBackupFileName() {
    final treeName = cleanText(current?.title ?? 'nasabnama').replaceAll(' ', '_').replaceAll(RegExp(r'[^a-zA-Z0-9_؀-ۿ]+'), '');
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    return 'nasabnama_backup_${treeName}_$stamp.json';
  }

  Future<String> saveBackupToDownloads() async {
    final fileName = safeBackupFileName();
    final content = backupJson(type: 'file-backup');
    final targets = <Directory>[
      Directory('/storage/emulated/0/Download'),
      Directory('/storage/emulated/0/Downloads'),
      Directory.systemTemp,
    ];
    Object? lastError;
    for (final dir in targets) {
      try {
        if (!await dir.exists()) await dir.create(recursive: true);
        final file = File('${dir.path}/$fileName');
        await file.writeAsString(content, encoding: utf8);
        lastBackupAt = nowIso();
        await save();
        return 'فایل بکاپ ساخته شد: ${file.path}';
      } catch (e) {
        lastError = e;
      }
    }
    return 'ساخت فایل بکاپ انجام نشد. خطا: $lastError';
  }

  Future<String> restoreBackupFromFilePicker() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json', 'txt']);
    final path = result?.files.single.path;
    if (path == null) return 'فایلی انتخاب نشد.';
    try {
      final raw = await File(path).readAsString();
      return importBackup(raw);
    } catch (_) {
      return 'فایل انتخاب‌شده خوانده نشد.';
    }
  }

  Future<String> createSafetySnapshot({String reason = 'manual'}) async {
    final pref = await SharedPreferences.getInstance();
    await pref.setString('${storageKey}_safety_snapshot', backupJson(type: 'safety-snapshot-$reason'));
    await pref.setString('${storageKey}_safety_snapshot_at', nowIso());
    return 'بکاپ امن داخل گوشی ذخیره شد.';
  }

  Future<String> restoreSafetySnapshot() async {
    final pref = await SharedPreferences.getInstance();
    final raw = pref.getString('${storageKey}_safety_snapshot');
    if (raw == null || raw.trim().isEmpty) return 'بکاپ امنی داخل گوشی پیدا نشد.';
    return importBackup(raw);
  }

  Future<String> importBackup(String raw) async {
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final treeList = data['trees'] as List? ?? [];
      trees = treeList.map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
      activeTreeId = data['activeTreeId'];
      final settings = Map<String, dynamic>.from(data['settings'] as Map? ?? {});
      if (settings.isNotEmpty) {
        showHelp = settings['showHelp'] ?? showHelp;
        protectPhones = settings['protectPhones'] ?? protectPhones;
        appLockEnabled = settings['appLockEnabled'] ?? appLockEnabled;
        appPin = settings['appPin'] ?? appPin;
        adminDisplayName = settings['adminDisplayName'] ?? adminDisplayName;
        lastBackupAt = settings['lastBackupAt'] ?? lastBackupAt;
        treeCardScale = (((settings['treeCardScale'] ?? treeCardScale) as num).toDouble().clamp(.8, 1.35) as num).toDouble();
      }
      await save();
      return 'بازیابی انجام شد. ${trees.length} شجره برگشت داده شد.';
    } catch (e) {
      return 'فایل/متن پشتیبان معتبر نیست.';
    }
  }

  Map<String, int> migrationStats() {
    final people = trees.expand((t) => t.people).toList();
    var missingCodes = 0;
    var missingFatherLinks = 0;
    var missingSpouseBackLinks = 0;
    for (final tree in trees) {
      for (final p in tree.people) {
        if (p.code.trim().isEmpty) missingCodes++;
        if (p.fatherName.trim().isNotEmpty && p.fatherId == null) missingFatherLinks++;
        if (p.spouseId != null) {
          final sp = firstWhereOrNull<Person>(tree.people, (x) => x.id == p.spouseId);
          if (sp == null || sp.spouseId != p.id) missingSpouseBackLinks++;
        }
      }
    }
    return {
      'trees': trees.length,
      'people': people.length,
      'logs': trees.fold(0, (a, b) => a + b.logs.length),
      'items': trees.fold(0, (a, b) => a + b.items.length),
      'events': trees.fold(0, (a, b) => a + b.events.length),
      'missingCodes': missingCodes,
      'missingFatherLinks': missingFatherLinks,
      'missingSpouseBackLinks': missingSpouseBackLinks,
    };
  }

  List<String> onlineReadinessWarnings() {
    final st = migrationStats();
    final warnings = <String>[];
    if ((st['trees'] ?? 0) == 0) warnings.add('هنوز شجره‌ای ساخته نشده است.');
    if ((st['missingCodes'] ?? 0) > 0) warnings.add('${st['missingCodes']} شخص کد اختصاصی ندارد.');
    if ((st['missingFatherLinks'] ?? 0) > 0) warnings.add('${st['missingFatherLinks']} رابطه پدر فقط متنی است و لینک مستقیم ندارد.');
    if ((st['missingSpouseBackLinks'] ?? 0) > 0) warnings.add('${st['missingSpouseBackLinks']} رابطه همسر دوطرفه نیست.');
    if (warnings.isEmpty) warnings.add('داده‌ها برای آنلاین‌سازی آینده آماده هستند.');
    return warnings;
  }

  String onlineMigrationJson() => backupJson(type: 'online-migration-package');

  String _csvIdValue(Map<String, int> header, List<String> row, List<String> aliases) {
    final raw = csvValue(header, row, aliases).trim();
    if (raw.isEmpty || raw == '-' || raw.toLowerCase() == 'nan') return '';
    final normalized = raw.endsWith('.0') ? raw.substring(0, raw.length - 2) : raw;
    return normalized.replaceAll(RegExp(r'[^0-9A-Za-z_\-]'), '');
  }

  String _joinDateParts(String day, String month, String year) {
    final d = day.trim();
    final m = month.trim();
    final y = year.trim();
    if (d.isEmpty && m.isEmpty && y.isEmpty) return '';
    final parts = [y, m.padLeft(2, '0'), d.padLeft(2, '0')].where((e) => e.trim().isNotEmpty && e != '00').toList();
    return parts.join('/');
  }

  Future<String> importCsvText(String raw, {bool createNewTree = false, String newTreeTitle = 'شجره واردشده از CSV'}) async {
    if (raw.trim().isEmpty) return 'متن CSV خالی است.';
    await createSafetySnapshot(reason: 'before-csv-import');

    final rows = parseCsvRows(raw);
    if (rows.length < 2) return 'CSV باید حداقل یک ردیف عنوان ستون و یک ردیف اطلاعات داشته باشد.';

    final headers = rows.first;
    final headerMap = <String, int>{};
    for (var i = 0; i < headers.length; i++) {
      headerMap[normalizeHeader(headers[i])] = i;
    }

    final hasExternalId = headerMap.containsKey(normalizeHeader('شناسه'));
    final hasParentExternalId = headerMap.containsKey(normalizeHeader('شناسه نسل بالادستی'));
    final hasRelationType = headerMap.containsKey(normalizeHeader('نوع ارتباط (فرزند یا همسر)'));
    if (hasExternalId && hasParentExternalId && hasRelationType) {
      return importStructuredCsvText(raw, createNewTree: createNewTree, newTreeTitle: newTreeTitle);
    }

    if (createNewTree || current == null) {
      final title = newTreeTitle.trim().isEmpty ? 'شجره واردشده از CSV' : newTreeTitle.trim();
      final tree = FamilyTree(id: _uuid.v4(), code: nextTreeCode(), title: title, ownerName: 'ادمین', branch: 'واردشده از CSV');
      tree.members.add(TreeMember(id: _uuid.v4(), name: 'ادمین', role: 'ادمین اصلی'));
      trees.add(tree);
      activeTreeId = tree.id;
    }

    final tree = current;
    if (tree == null) return 'امکان ساخت یا انتخاب شجره وجود ندارد.';

    var created = 0;
    var updated = 0;
    var skipped = 0;
    var linkedSpouses = 0;

    for (final row in rows.skip(1)) {
      final name = csvValue(headerMap, row, ['name', 'full_name', 'fullname', 'person', 'نام', 'نام کامل', 'شخص']);
      if (name.trim().isEmpty) {
        skipped++;
        continue;
      }

      final father = csvValue(headerMap, row, ['father_name', 'father', 'fathername', 'نام پدر', 'پدر']);
      final grand = csvValue(headerMap, row, ['grandfather_name', 'grandfather', 'grandfathername', 'نام پدربزرگ', 'پدربزرگ']);
      final mother = csvValue(headerMap, row, ['mother_name', 'mother', 'mothername', 'نام مادر', 'مادر']);
      final spouseName = csvValue(headerMap, row, ['spouse_name', 'spouse', 'wife', 'husband', 'نام همسر', 'همسر']);
      final gender = normalizeGenderValue(csvValue(headerMap, row, ['gender', 'sex', 'جنسیت']));
      final phone = csvValue(headerMap, row, ['phone', 'mobile', 'tel', 'شماره', 'شماره تماس', 'موبایل']);
      final branch = csvValue(headerMap, row, ['branch', 'family_branch', 'شاخه', 'شاخه خانوادگی', 'طایفه']);
      final birthDate = csvValue(headerMap, row, ['birth_date', 'birthdate', 'تاریخ تولد', 'تولد']);
      final deathDate = csvValue(headerMap, row, ['death_date', 'deathdate', 'تاریخ فوت', 'فوت']);
      final livingPlace = csvValue(headerMap, row, ['city', 'living_place', 'livingplace', 'location', 'شهر', 'محل زندگی', 'محل زندگی فعلی', 'آدرس']);
      final notes = csvValue(headerMap, row, ['notes', 'note', 'description', 'توضیحات', 'یادداشت', 'بیوگرافی']);

      var person = _findByNameAndFather(tree, name, father, grandfatherName: grand);
      if (person == null) {
        person = Person(
          id: _uuid.v4(),
          code: '',
          name: name.trim(),
          fatherName: father.trim(),
          grandfatherName: grand.trim(),
          motherName: mother.trim(),
          gender: gender,
          phone: phone.trim(),
          branch: branch.trim(),
          birthDate: birthDate.trim(),
          deathDate: deathDate.trim(),
          livingPlace: livingPlace.trim(),
          notes: notes.trim(),
          createdBy: 'CSV',
        );
        autoPlace(tree, person);
        person.code = nextPersonCode(tree);
        tree.people.add(person);
        created++;
      } else {
        if (mother.trim().isNotEmpty) person.motherName = mother.trim();
        if (gender != 'نامشخص') person.gender = gender;
        if (phone.trim().isNotEmpty) person.phone = phone.trim();
        if (branch.trim().isNotEmpty) person.branch = branch.trim();
        if (birthDate.trim().isNotEmpty) person.birthDate = birthDate.trim();
        if (deathDate.trim().isNotEmpty) person.deathDate = deathDate.trim();
        if (livingPlace.trim().isNotEmpty) person.livingPlace = livingPlace.trim();
        if (notes.trim().isNotEmpty) person.notes = notes.trim();
        autoPlace(tree, person);
        updated++;
      }

      if (spouseName.trim().isNotEmpty) {
        var spouse = _findExistingSpouse(tree, spouseName, person, '');
        if (spouse == null) {
          spouse = Person(
            id: _uuid.v4(),
            code: '',
            name: spouseName.trim(),
            spouseId: person.id,
            spouseName: person.name,
            gender: person.gender == 'مرد' ? 'زن' : person.gender == 'زن' ? 'مرد' : 'نامشخص',
            branch: branch.trim(),
            livingPlace: livingPlace.trim(),
            createdBy: 'CSV',
          );
          spouse.code = nextPersonCode(tree);
          tree.people.add(spouse);
          created++;
        }
        person.spouseId = spouse.id;
        person.spouseName = spouse.name;
        spouse.spouseId = person.id;
        spouse.spouseName = person.name;
        linkedSpouses++;
      }
    }

    final relinked = rebuildRelationshipsByNames(tree);
    final deduped = dedupeSmart(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'CSV وارد شد: $created جدید، $updated به‌روزرسانی، $linkedSpouses همسر لینک شد، $relinked رابطه بازسازی شد، $deduped تکراری ادغام شد', actor: 'CSV'));
    await save();
    return 'Import انجام شد: $created شخص جدید، $updated به‌روزرسانی، $linkedSpouses رابطه همسر، $relinked رابطه بازسازی، $deduped تکراری ادغام شد، $skipped ردیف رد شد.';
  }

  Future<String> importStructuredCsvText(String raw, {bool createNewTree = false, String newTreeTitle = 'شجره واردشده از CSV'}) async {
    final rows = parseCsvRows(raw);
    final headers = rows.first;
    final headerMap = <String, int>{};
    for (var i = 0; i < headers.length; i++) {
      headerMap[normalizeHeader(headers[i])] = i;
    }

    if (createNewTree || current == null) {
      final title = newTreeTitle.trim().isEmpty ? 'شجره واردشده از CSV' : newTreeTitle.trim();
      final tree = FamilyTree(id: _uuid.v4(), code: nextTreeCode(), title: title, ownerName: 'ادمین', branch: 'واردشده از CSV');
      tree.members.add(TreeMember(id: _uuid.v4(), name: 'ادمین', role: 'ادمین اصلی'));
      trees.add(tree);
      activeTreeId = tree.id;
    }

    final tree = current;
    if (tree == null) return 'امکان ساخت یا انتخاب شجره وجود ندارد.';

    final byExternalId = <String, Person>{};
    for (final p in tree.people) {
      final m = RegExp(r'CSV-ID:([^\s|]+)').firstMatch(p.notes);
      if (m != null) byExternalId[m.group(1)!] = p;
    }

    var created = 0;
    var updated = 0;
    var skipped = 0;

    // مرحله ۱: ساخت/به‌روزرسانی همه افراد با شناسه ثابت خارجی
    for (final row in rows.skip(1)) {
      final externalId = _csvIdValue(headerMap, row, ['شناسه', 'id', 'person_id']);
      final firstName = csvValue(headerMap, row, ['نام', 'name']);
      final lastName = csvValue(headerMap, row, ['نام خانوادگی', 'lastname', 'family']);
      final displayName = [firstName.trim(), lastName.trim()].where((e) => e.isNotEmpty && e != '-').join(' ').trim();
      if (externalId.isEmpty || displayName.isEmpty) {
        skipped++;
        continue;
      }

      final gender = normalizeGenderValue(csvValue(headerMap, row, ['جنسیت', 'gender']));
      final phone = csvValue(headerMap, row, ['موبایل', 'تلفن', 'phone', 'mobile']);
      final livingPlace = csvValue(headerMap, row, ['محل زندگی فعلی', 'محل زندگی', 'شهر']);
      final birthPlace = csvValue(headerMap, row, ['محل تولد']);
      final job = csvValue(headerMap, row, ['شغل و حرفه', 'شغل']);
      final bio = csvValue(headerMap, row, ['بیوگرافی', 'توضیحات']);
      final branch = lastName.trim();
      final birthDate = _joinDateParts(
        csvValue(headerMap, row, ['روز تولد']),
        csvValue(headerMap, row, ['ماه تولد']),
        csvValue(headerMap, row, ['سال تولد']),
      );
      final deathDate = _joinDateParts(
        csvValue(headerMap, row, ['روز وفات']),
        csvValue(headerMap, row, ['ماه وفات']),
        csvValue(headerMap, row, ['سال وفات']),
      );

      var person = byExternalId[externalId];
      person ??= _findByNameAndFather(tree, displayName, '');
      if (person == null) {
        person = Person(
          id: _uuid.v4(),
          code: nextPersonCode(tree),
          name: displayName,
          gender: gender,
          phone: phone.trim(),
          branch: branch,
          birthDate: birthDate,
          deathDate: deathDate,
          birthPlace: birthPlace.trim(),
          livingPlace: livingPlace.trim(),
          notes: 'CSV-ID:$externalId${job.trim().isEmpty ? '' : ' | شغل: ${job.trim()}'}${bio.trim().isEmpty || bio.trim() == '-' ? '' : ' | $bio'}',
          createdBy: 'CSV',
        );
        tree.people.add(person);
        byExternalId[externalId] = person;
        created++;
      } else {
        if (gender != 'نامشخص') person.gender = gender;
        if (phone.trim().isNotEmpty && phone.trim() != '-') person.phone = phone.trim();
        if (branch.trim().isNotEmpty && branch.trim() != '-') person.branch = branch.trim();
        if (birthDate.trim().isNotEmpty) person.birthDate = birthDate;
        if (deathDate.trim().isNotEmpty) person.deathDate = deathDate;
        if (birthPlace.trim().isNotEmpty && birthPlace.trim() != '-') person.birthPlace = birthPlace.trim();
        if (livingPlace.trim().isNotEmpty && livingPlace.trim() != '-') person.livingPlace = livingPlace.trim();
        if (!person.notes.contains('CSV-ID:$externalId')) {
          person.notes = '${person.notes.trim()} | CSV-ID:$externalId'.trim();
        }
        updated++;
      }
    }

    var childLinks = 0;
    var spouseLinks = 0;
    var unresolved = 0;

    // مرحله ۲: ساخت رابطه‌ها بر اساس شناسه نسل بالادستی
    for (final row in rows.skip(1)) {
      final externalId = _csvIdValue(headerMap, row, ['شناسه', 'id', 'person_id']);
      final parentExternalId = _csvIdValue(headerMap, row, ['شناسه نسل بالادستی', 'parent_id', 'up_id']);
      final relation = cleanText(csvValue(headerMap, row, ['نوع ارتباط (فرزند یا همسر)', 'نوع ارتباط', 'relation']));
      if (externalId.isEmpty || parentExternalId.isEmpty) continue;

      final person = byExternalId[externalId];
      final upper = byExternalId[parentExternalId];
      if (person == null || upper == null) {
        unresolved++;
        continue;
      }

      if (relation.contains('همسر')) {
        person.spouseId = upper.id;
        person.spouseName = upper.name;
        upper.spouseId = person.id;
        upper.spouseName = person.name;
        spouseLinks++;
      } else {
        final upperIsFemale = upper.gender == 'زن';
        if (upperIsFemale) {
          person.motherId = upper.id;
          person.motherName = upper.name;
          if (upper.spouseId != null && byExternalId.values.any((p) => p.id == upper.spouseId)) {
            final father = firstWhereOrNull<Person>(tree.people, (p) => p.id == upper.spouseId);
            if (father != null) {
              person.fatherId = father.id;
              person.fatherName = father.name;
              person.grandfatherName = father.fatherName;
            }
          }
        } else {
          person.fatherId = upper.id;
          person.fatherName = upper.name;
          person.grandfatherName = upper.fatherName;
          if (upper.spouseId != null) {
            final mother = firstWhereOrNull<Person>(tree.people, (p) => p.id == upper.spouseId);
            if (mother != null) {
              person.motherId = mother.id;
              person.motherName = mother.name;
            }
          }
        }
        childLinks++;
      }
    }

    // مرحله ۳: بعد از مشخص شدن همسرها، مادر/پدر دوم فرزندان را کامل کن
    for (final person in tree.people) {
      if (person.fatherId != null && person.motherId == null) {
        final father = firstWhereOrNull<Person>(tree.people, (p) => p.id == person.fatherId);
        if (father?.spouseId != null) {
          final mother = firstWhereOrNull<Person>(tree.people, (p) => p.id == father!.spouseId);
          if (mother != null && mother.gender == 'زن') {
            person.motherId = mother.id;
            person.motherName = mother.name;
          }
        }
      }
      if (person.motherId != null && person.fatherId == null) {
        final mother = firstWhereOrNull<Person>(tree.people, (p) => p.id == person.motherId);
        if (mother?.spouseId != null) {
          final father = firstWhereOrNull<Person>(tree.people, (p) => p.id == mother!.spouseId);
          if (father != null && father.gender == 'مرد') {
            person.fatherId = father.id;
            person.fatherName = father.name;
          }
        }
      }
    }

    final deduped = dedupeSmart(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'CSV ساختاری وارد شد: $created جدید، $updated به‌روزرسانی، $childLinks رابطه فرزند، $spouseLinks رابطه همسر، $unresolved رابطه نامشخص، $deduped تکراری ادغام شد', actor: 'CSV'));
    await save();
    return 'CSV ساختاری وارد شد: $created جدید، $updated به‌روزرسانی، $childLinks رابطه فرزند، $spouseLinks رابطه همسر، $unresolved رابطه نامشخص، $deduped تکراری ادغام شد.';
  }

  int rebuildRelationshipsByNames(FamilyTree tree) {
    var linked = 0;
    for (final p in tree.people) {
      if (p.fatherId == null && p.fatherName.trim().isNotEmpty) {
        final father = _findByNameAndFather(tree, p.fatherName, p.grandfatherName);
        if (father != null && father.id != p.id) {
          p.fatherId = father.id;
          p.fatherName = father.name;
          linked++;
        }
      }
      if (p.spouseId == null && p.spouseName.trim().isNotEmpty) {
        final spouse = firstWhereOrNull<Person>(tree.people, (x) => cleanText(x.name) == cleanText(p.spouseName));
        if (spouse != null && spouse.id != p.id) {
          p.spouseId = spouse.id;
          spouse.spouseId = p.id;
          spouse.spouseName = p.name;
          linked++;
        }
      }
    }
    return linked;
  }

  Future<void> deleteAll() async {
    trees.clear();
    activeTreeId = null;
    await save();
  }
}

class NasabNamaApp extends StatefulWidget {
  const NasabNamaApp({super.key});
  @override
  State<NasabNamaApp> createState() => _NasabNamaAppState();
}

class _NasabNamaAppState extends State<NasabNamaApp> {
  final store = AppStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return StoreProvider(
      store: store,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'نسب‌نامه',
        theme: ThemeData(
          useMaterial3: true,
          fontFamily: 'sans',
          scaffoldBackgroundColor: C.bg,
          colorScheme: ColorScheme.fromSeed(seedColor: C.blue, brightness: Brightness.light),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: C.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: C.blue, width: 1.4)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const AppShell(),
      ),
    );
  }
}

class StoreProvider extends InheritedNotifier<AppStore> {
  const StoreProvider({super.key, required AppStore store, required Widget child}) : super(notifier: store, child: child);
  static AppStore of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<StoreProvider>()!.notifier!;
}


class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final pin = TextEditingController();
  String error = '';

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: PremiumCard(
              padding: const EdgeInsets.all(22),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const CircleAvatar(radius: 34, backgroundColor: C.sky, child: Icon(Icons.lock, size: 36, color: C.blue)),
                const SizedBox(height: 14),
                const Text('قفل نسب‌نامه', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)),
                const SizedBox(height: 8),
                const Text('رمز محلی اپ را وارد کن.', textAlign: TextAlign.center, style: TextStyle(color: C.muted)),
                const SizedBox(height: 10),
                TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز ۴ یا ۶ رقمی')),
                if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error, style: const TextStyle(color: C.red))),
                const SizedBox(height: 12),
                FilledButton.icon(onPressed: () {
                  if (store.checkPin(pin.text)) {
                    widget.onUnlocked();
                  } else {
                    setState(() => error = 'رمز درست نیست.');
                  }
                }, icon: const Icon(Icons.lock_open), label: const Text('ورود')),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  bool unlocked = false;

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        if (store.appLockEnabled && store.appPin.isNotEmpty && !unlocked) {
          return LockScreen(onUnlocked: () => setState(() => unlocked = true));
        }
        final pages = [
          HomePage(onNavigate: (i) => setState(() => index = i)),
          const TreePage(),
          const AddPersonPage(),
          const SearchPage(),
          const MorePage(),
        ];
        return Scaffold(
          resizeToAvoidBottomInset: true,
          body: pages[index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (i) => setState(() => index = i),
            backgroundColor: C.white,
            indicatorColor: C.mint,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
              NavigationDestination(icon: Icon(Icons.account_tree_outlined), selectedIcon: Icon(Icons.account_tree), label: 'شجره'),
              NavigationDestination(icon: Icon(Icons.person_add_alt_1_outlined), selectedIcon: Icon(Icons.person_add_alt_1), label: 'افزودن'),
              NavigationDestination(icon: Icon(Icons.search), label: 'جستجو'),
              NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'امکانات'),
            ],
          ),
        );
      },
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const AppHeader(title: 'نسب‌نامه', subtitle: 'مدیریت هوشمند شجره‌نامه خانوادگی'),
            const SizedBox(height: 14),
            if (tree == null) EmptyState(onCreate: () => showTreeDialog(context)) else ...[
              TreeSwitcher(store: store),
              const SizedBox(height: 12),
              HeroCard(tree: tree),
              const SizedBox(height: 12),
              StatsGrid(tree: tree),
              const SizedBox(height: 12),
              BackupStatusCard(lastBackupAt: store.lastBackupAt),
              const SizedBox(height: 12),
              SubscriptionStatusCard(store: store),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: QuickButton(title: 'دیدن شجره', icon: Icons.account_tree, color: C.blue, onTap: () => onNavigate(1))),
                const SizedBox(width: 10),
                Expanded(child: QuickButton(title: 'افزودن شخص', icon: Icons.person_add, color: C.green, onTap: () => onNavigate(2))),
              ]),
              const SizedBox(height: 10),
              QuickButton(title: 'افزودن خانواده کامل', icon: Icons.group_add_rounded, color: C.green, onTap: () => push(context, const FullFamilyEntryPage())),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: QuickButton(title: 'اصلاح خودکار', icon: Icons.auto_fix_high, color: C.green, onTap: () => push(context, const AutoRepairPage()))),
                const SizedBox(width: 10),
                Expanded(child: QuickButton(title: 'بکاپ فایل', icon: Icons.backup, color: C.gold, onTap: () => push(context, const BackupPage()))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: QuickButton(title: 'جستجو', icon: Icons.search, color: C.gold, onTap: () => onNavigate(3))),
                const SizedBox(width: 10),
                Expanded(child: QuickButton(title: 'دعوت عضو', icon: Icons.ios_share, color: C.red, onTap: () => shareTreeInvite(context, tree))),
              ]),
              const SizedBox(height: 16),
              SectionTitle(title: 'آخرین تغییرات', action: 'همه امکانات'),
              ...tree.logs.reversed.take(5).map((e) => LogTile(log: e)),
            ],
          ],
        ),
      ),
    );
  }
}


class BackupStatusCard extends StatelessWidget {
  final String lastBackupAt;
  const BackupStatusCard({super.key, required this.lastBackupAt});
  @override
  Widget build(BuildContext context) {
    final hasBackup = lastBackupAt.trim().isNotEmpty;
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        CircleAvatar(backgroundColor: hasBackup ? C.mint : C.sky, child: Icon(hasBackup ? Icons.verified : Icons.info_outline, color: hasBackup ? C.green : C.blue)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(hasBackup ? 'آخرین بکاپ: ${shortDate(lastBackupAt)}' : 'هنوز بکاپ فایل نگرفته‌ای', style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
          const Text('برای حذف و نصب دوباره، حتماً بکاپ JSON فایل بگیر.', style: TextStyle(color: C.muted, fontSize: 12)),
        ])),
        TextButton(onPressed: () => push(context, const BackupPage()), child: const Text('بکاپ')),
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  final VoidCallback onCreate;
  const EmptyState({super.key, required this.onCreate});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      child: Column(
        children: [
          const Icon(Icons.family_restroom, size: 72, color: C.green),
          const SizedBox(height: 12),
          const Text('هنوز شجره‌ای ساخته نشده', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 8),
          const Text('اول یک شجره بساز. بعد افراد را با نام پدر و پدربزرگ اضافه کن تا اپ جایگاهشان را خودش تشخیص دهد.', textAlign: TextAlign.center, style: TextStyle(color: C.muted, height: 1.8)),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: onCreate, icon: const Icon(Icons.add), label: const Text('ساخت شجره جدید')),
        ],
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const AppHeader({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.green, C.blue]), borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 18, offset: Offset(0, 8))]),
          child: const Icon(Icons.account_tree_rounded, color: Colors.white),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.ink)), Text(subtitle, style: const TextStyle(color: C.muted))])),
      ],
    );
  }
}

class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const PremiumCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(26),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            color: C.white,
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: Colors.white.withOpacity(.8)),
            boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 24, offset: Offset(0, 12))],
          ),
          child: child,
        ),
      ),
    );
  }
}

class TreeSwitcher extends StatelessWidget {
  final AppStore store;
  const TreeSwitcher({super.key, required this.store});
  @override
  Widget build(BuildContext context) {
    final current = store.current;
    return Row(
      children: [
        Expanded(
          child: PremiumCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: current?.id,
                isExpanded: true,
                icon: const Icon(Icons.keyboard_arrow_down),
                items: store.trees.map((e) => DropdownMenuItem(value: e.id, child: Text(e.title, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (v) => v == null ? null : store.selectTree(v),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        IconButton.filledTonal(onPressed: () => showTreeDialog(context), icon: const Icon(Icons.add)),
      ],
    );
  }
}

class HeroCard extends StatelessWidget {
  final FamilyTree tree;
  const HeroCard({super.key, required this.tree});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [C.cream, C.sky, C.mint]),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 28, offset: Offset(0, 14))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(radius: 28, backgroundColor: C.white, child: Icon(Icons.family_restroom, color: C.green, size: 32)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tree.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)), Text('ادمین اصلی: ${tree.ownerName}', style: const TextStyle(color: C.muted))])),
          Chip(label: Text(tree.code), backgroundColor: C.white),
        ]),
        const SizedBox(height: 14),
        Text(tree.branch.isEmpty ? 'شاخه خانوادگی ثبت نشده' : 'شاخه: ${tree.branch}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        LinearProgressIndicator(value: min(1, tree.people.length / 30), minHeight: 8, borderRadius: BorderRadius.circular(10), backgroundColor: Colors.white, color: C.green),
        const SizedBox(height: 8),
        Text('${tree.people.length} نفر ثبت شده؛ برای کامل شدن شجره، اعضا را دعوت کن.', style: const TextStyle(color: C.muted)),
      ]),
    );
  }
}

class StatsGrid extends StatelessWidget {
  final FamilyTree tree;
  const StatsGrid({super.key, required this.tree});
  int generations() {
    var maxDepth = 0;
    final byId = {for (final p in tree.people) p.id: p};
    for (final p in tree.people) {
      var depth = 1;
      var f = p.fatherId;
      final seen = <String>{};
      while (f != null && byId.containsKey(f) && !seen.contains(f)) {
        seen.add(f);
        depth++;
        f = byId[f]!.fatherId;
      }
      maxDepth = max(maxDepth, depth);
    }
    return maxDepth;
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final male = tree.people.where((p) => p.gender == 'مرد').length;
    final female = tree.people.where((p) => p.gender == 'زن').length;
    final couples = tree.people.where((p) => p.spouseId != null).length ~/ 2;
    final incomplete = store.orphanedPeople().length;
    final duplicates = store.duplicateGroups().length;
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.95,
      children: [
        StatTile(label: 'افراد', value: '${tree.people.length}', icon: Icons.groups, color: C.blue),
        StatTile(label: 'نسل‌ها', value: '${generations()}', icon: Icons.account_tree, color: C.green),
        StatTile(label: 'زوج‌ها', value: '$couples', icon: Icons.favorite, color: C.red),
        StatTile(label: 'زن / مرد', value: '$female / $male', icon: Icons.pie_chart, color: C.gold),
        StatTile(label: 'روابط ناقص', value: '$incomplete', icon: Icons.warning_amber, color: incomplete == 0 ? C.green : C.red),
        StatTile(label: 'تکراری‌ها', value: '$duplicates', icon: Icons.merge_type, color: duplicates == 0 ? C.green : C.gold),
      ],
    );
  }
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const StatTile({super.key, required this.label, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(13),
      child: Row(children: [
        CircleAvatar(backgroundColor: color.withOpacity(.14), child: Icon(icon, color: color)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: C.ink)), Text(label, style: const TextStyle(color: C.muted))])),
      ]),
    );
  }
}

class QuickButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const QuickButton({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.13), child: Icon(icon, color: color)), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: C.ink)))]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? action;
  const SectionTitle({super.key, required this.title, this.action});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: C.ink))), if (action != null) Text(action!, style: const TextStyle(color: C.blue, fontWeight: FontWeight.w700))]));
}

class LogTile extends StatelessWidget {
  final ActivityLog log;
  const LogTile({super.key, required this.log});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 8), child: PremiumCard(padding: const EdgeInsets.all(12), child: Row(children: [const Icon(Icons.history, color: C.green), const SizedBox(width: 10), Expanded(child: Text(log.text, style: const TextStyle(fontWeight: FontWeight.w700))), Text(shortDate(log.createdAt), style: const TextStyle(color: C.muted, fontSize: 12))])));
}

Future<void> showTreeDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final owner = TextEditingController();
  final phone = TextEditingController();
  final branch = TextEditingController();
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => FormSheet(
      title: 'ساخت شجره جدید',
      children: [
        AppField(controller: title, label: 'نام شجره', hint: 'مثلاً خانواده کدخدایی'),
        AppField(controller: owner, label: 'نام ادمین اصلی', hint: 'نام شما'),
        AppField(controller: phone, label: 'شماره ادمین', keyboard: TextInputType.phone),
        AppField(controller: branch, label: 'شاخه / طایفه', hint: 'اختیاری'),
        FilledButton.icon(
          onPressed: () async {
            if (title.text.trim().isEmpty || owner.text.trim().isEmpty) return;
            final msg = await store.createTree(title: title.text, owner: owner.text, phone: phone.text, branch: branch.text);
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
            if (msg.contains('ساخته شد')) Navigator.pop(context);
          },
          icon: const Icon(Icons.check),
          label: const Text('ثبت شجره'),
        ),
      ],
    ),
  );
}

class FormSheet extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const FormSheet({super.key, required this.title, required this.children});
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .9),
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      decoration: const BoxDecoration(color: C.bg, borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: C.muted.withOpacity(.25), borderRadius: BorderRadius.circular(9)))),
          const SizedBox(height: 14),
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 12),
          ...children.map((e) => Padding(padding: const EdgeInsets.only(bottom: 10), child: e)),
        ]),
      ),
    );
  }
}

class AppField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final TextInputType? keyboard;
  final int maxLines;
  const AppField({super.key, required this.controller, required this.label, this.hint, this.keyboard, this.maxLines = 1});

  @override
  Widget build(BuildContext context) {
    final action = TextInputAction.next;
    return TextField(
      controller: controller,
      keyboardType: keyboard,
      maxLines: maxLines,
      textInputAction: action,
      decoration: InputDecoration(labelText: label, hintText: hint),
    );
  }
}

void shareTreeInvite(BuildContext context, FamilyTree tree) {
  final link = 'https://nasabnama.local/invite/${tree.code}';
  final text = '''سلام 🌿
شما برای مشاهده و تکمیل شجره‌نامه «${tree.title}» دعوت شده‌اید.

لینک دعوت:
$link

کد دعوت:
${tree.code}

لطفاً اطلاعاتی که از خانواده می‌دانید را ثبت کنید تا شجره‌نامه کامل‌تر شود.''';
  Share.share(text, subject: 'دعوت به شجره‌نامه ${tree.title}');
}

class AddPersonPage extends StatefulWidget {
  final Person? editPerson;
  const AddPersonPage({super.key, this.editPerson});
  @override
  State<AddPersonPage> createState() => _AddPersonPageState();
}

class _AddPersonPageState extends State<AddPersonPage> {
  final name = TextEditingController();
  final father = TextEditingController();
  final grand = TextEditingController();
  final mother = TextEditingController();
  final phone = TextEditingController();
  final branch = TextEditingController();
  final birth = TextEditingController();
  final death = TextEditingController();
  final birthPlace = TextEditingController();
  final livingPlace = TextEditingController();
  final notes = TextEditingController();
  final special = TextEditingController();
  String gender = 'نامشخص';
  bool phonePrivate = true;

  @override
  void initState() {
    super.initState();
    final p = widget.editPerson;
    if (p != null) {
      name.text = p.name;
      father.text = p.fatherName;
      grand.text = p.grandfatherName;
      mother.text = p.motherName;
      phone.text = p.phone;
      branch.text = p.branch;
      birth.text = p.birthDate;
      death.text = p.deathDate;
      birthPlace.text = p.birthPlace;
      livingPlace.text = p.livingPlace;
      notes.text = p.notes;
      special.text = p.specialTag;
      gender = p.gender;
      phonePrivate = p.phonePrivate;
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final hasTree = store.current != null;
    return SafeArea(
      child: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 28),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          AppHeader(title: widget.editPerson == null ? 'افزودن شخص' : 'ویرایش شخص', subtitle: 'با نام پدر و پدربزرگ، جایگاه فرد خودکار پیدا می‌شود'),
          const SizedBox(height: 12),
          if (!hasTree) EmptyState(onCreate: () => showTreeDialog(context)) else ...[
            QuickSectionCard(
              title: 'ثبت گروهی و خانواده',
              subtitle: 'برای ثبت یک خانواده کامل، این بخش از صفحه امکانات حذف شد و اینجا قرار گرفت.',
              children: [
                QuickMiniButton(title: 'افزودن خانواده کامل', icon: Icons.group_add_rounded, color: C.green, onTap: () => push(context, const FullFamilyEntryPage())),
              ],
            ),
            const SizedBox(height: 12),
            PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const HelpBox(text: 'حداقل نام شخص را وارد کن. اگر نام پدر و پدربزرگ را بنویسی، اپ پدر/پدربزرگ را پیدا می‌کند یا در صورت نبود، شاخه را خودکار می‌سازد.'),
            const SizedBox(height: 12),
            AppField(controller: name, label: 'نام شخص *'),
            AppField(controller: father, label: 'نام پدر'),
            AppField(controller: grand, label: 'نام پدربزرگ'),
            AppField(controller: mother, label: 'نام مادر'),
            DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'جنسیت'), items: const ['نامشخص', 'مرد', 'زن'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => gender = v ?? 'نامشخص')),
            const SizedBox(height: 10),
            AppField(controller: phone, label: 'شماره تماس', keyboard: TextInputType.phone),
            SwitchListTile(contentPadding: EdgeInsets.zero, value: phonePrivate, onChanged: (v) => setState(() => phonePrivate = v), title: const Text('شماره تماس خصوصی باشد'), subtitle: const Text('فقط ادمین‌ها ببینند')),
            AppField(controller: branch, label: 'شاخه خانوادگی'),
            Row(children: [Expanded(child: AppField(controller: birth, label: 'تاریخ تولد')), const SizedBox(width: 8), Expanded(child: AppField(controller: death, label: 'تاریخ فوت'))]),
            AppField(controller: birthPlace, label: 'محل تولد'),
            AppField(controller: livingPlace, label: 'محل زندگی'),
            AppField(controller: special, label: 'عنوان ویژه', hint: 'ریش‌سفید، استاد، شهید، پزشک و...'),
            AppField(controller: notes, label: 'توضیحات', maxLines: 4),
            const SizedBox(height: 8),
            FilledButton.icon(onPressed: () async {
              final base = widget.editPerson?.copy();
              final p = base ?? Person(id: _uuid.v4(), code: '', name: '');
              p.name = name.text.trim();
              p.fatherName = father.text.trim();
              p.grandfatherName = grand.text.trim();
              p.motherName = mother.text.trim();
              p.phone = phone.text.trim();
              p.gender = gender;
              p.branch = branch.text.trim();
              p.birthDate = birth.text.trim();
              p.deathDate = death.text.trim();
              p.birthPlace = birthPlace.text.trim();
              p.livingPlace = livingPlace.text.trim();
              p.notes = notes.text.trim();
              p.specialTag = special.text.trim();
              p.phonePrivate = phonePrivate;
              final msg = await store.addOrUpdatePerson(p);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
                if (widget.editPerson != null) Navigator.pop(context);
                if (widget.editPerson == null && msg.startsWith('ثبت')) {
                  name.clear(); father.clear(); grand.clear(); mother.clear(); phone.clear(); branch.clear(); birth.clear(); death.clear(); birthPlace.clear(); livingPlace.clear(); notes.clear(); special.clear();
                }
              }
            }, icon: const Icon(Icons.save), label: const Text('ذخیره شخص')),
            ])),
          ],
        ]),
      ),
    );
  }
}

class HelpBox extends StatelessWidget {
  final String text;
  const HelpBox({super.key, required this.text});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    if (!store.showHelp) return const SizedBox.shrink();
    return Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: C.sky, borderRadius: BorderRadius.circular(18)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.help_outline, color: C.blue), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(color: C.ink, height: 1.7)))]));
  }
}




class TreePage extends StatefulWidget {
  const TreePage({super.key});

  @override
  State<TreePage> createState() => _TreePageState();
}

class _TreePageState extends State<TreePage> {
  String? focusPersonId;

  Person? _defaultFocus(FamilyTree tree) {
    if (tree.people.isEmpty) return null;
    final roots = tree.people.where((p) {
      final hasParent = p.fatherId != null || p.motherId != null || p.fatherName.trim().isNotEmpty || p.motherName.trim().isNotEmpty;
      final hasChild = tree.people.any((c) => c.fatherId == p.id || c.motherId == p.id || looseEquals(c.fatherName, p.name) || looseEquals(c.motherName, p.name));
      return !hasParent && hasChild;
    }).toList();
    if (roots.isNotEmpty) return roots.first;
    final withFamily = tree.people.where((p) {
      final hasSpouse = p.spouseId != null || p.spouseName.trim().isNotEmpty;
      final hasChild = tree.people.any((c) => c.fatherId == p.id || c.motherId == p.id || looseEquals(c.fatherName, p.name) || looseEquals(c.motherName, p.name));
      return hasSpouse || hasChild;
    }).toList();
    return withFamily.isNotEmpty ? withFamily.first : tree.people.first;
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    Person? focus;
    if (tree != null && tree.people.isNotEmpty) {
      focus = tree.people.firstWhere((p) => p.id == focusPersonId, orElse: () => _defaultFocus(tree)!);
      focusPersonId = focus.id;
    }

    return SafeArea(
      child: tree == null
          ? Center(child: EmptyState(onCreate: () => showTreeDialog(context)))
          : tree.people.isEmpty
              ? const Center(child: Text('هنوز شخصی ثبت نشده است.'))
              : HtmlReferenceTreeView(
                  tree: tree,
                  store: store,
                  focusPersonId: focusPersonId,
                  onFocus: (p) => setState(() => focusPersonId = p.id),
                ),
    );
  }
}

String? effectiveFatherIdInTree(FamilyTree tree, Person person) {
  final ids = tree.people.map((e) => e.id).toSet();
  if (person.fatherId != null && ids.contains(person.fatherId)) return person.fatherId;
  final f = looseText(person.fatherName);
  if (f.isEmpty) return null;
  final g = looseText(person.grandfatherName);
  Person? best;
  var bestScore = 0;
  for (final candidate in tree.people) {
    if (candidate.id == person.id) continue;
    final nameScore = looseScore(candidate.name, f);
    if (nameScore < 70) continue;
    var score = nameScore;
    if (g.isNotEmpty) {
      final grand = tree.people.where((x) => x.id == candidate.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
      final grandScore = max(looseScore(candidate.fatherName, g), looseScore(grand?.name ?? '', g));
      score += grandScore >= 70 ? 25 : -12;
    }
    if (score > bestScore) {
      bestScore = score;
      best = candidate;
    }
  }
  return bestScore >= (g.isEmpty ? 70 : 82) ? best?.id : null;
}


class HtmlReferenceTreeView extends StatelessWidget {
  final FamilyTree tree;
  final AppStore store;
  final String? focusPersonId;
  final ValueChanged<Person> onFocus;
  const HtmlReferenceTreeView({super.key, required this.tree, required this.store, required this.focusPersonId, required this.onFocus});

  @override
  Widget build(BuildContext context) {
    final peopleById = {for (final p in tree.people) p.id: p};

    Person? byId(String? id) => id == null ? null : peopleById[id];

    Person? byLooseName(String name) {
      if (name.trim().isEmpty) return null;
      Person? best;
      var bestScore = 0;
      for (final p in tree.people) {
        final score = looseScore(p.name, name);
        if (score > bestScore) {
          best = p;
          bestScore = score;
        }
      }
      return bestScore >= 84 ? best : null;
    }

    final focus = byId(focusPersonId) ?? (tree.people.isEmpty ? null : tree.people.first);
    if (focus == null) return const Center(child: Text('شخصی برای نمایش وجود ندارد.'));

    List<Person> spousesOf(Person person) {
      final map = <String, Person>{};
      final direct = byId(person.spouseId) ?? byLooseName(person.spouseName);
      if (direct != null && direct.id != person.id) map[direct.id] = direct;
      for (final p in tree.people) {
        if (p.id == person.id) continue;
        if (p.spouseId == person.id || looseEquals(p.spouseName, person.name)) map[p.id] = p;
      }
      final list = map.values.toList();
      list.sort((a, b) => looseText(a.name).compareTo(looseText(b.name)));
      return list;
    }

    List<Person> childrenOfPersonOrSpouses(Person person, List<Person> spouses) {
      final ids = {person.id, ...spouses.map((e) => e.id)};
      final names = {looseText(person.name), ...spouses.map((e) => looseText(e.name))};
      final list = tree.people.where((p) {
        if (ids.contains(p.id)) return false;
        if (p.fatherId != null && ids.contains(p.fatherId)) return true;
        if (p.motherId != null && ids.contains(p.motherId)) return true;
        final f = looseText(p.fatherName);
        final m = looseText(p.motherName);
        return (f.isNotEmpty && names.contains(f)) || (m.isNotEmpty && names.contains(m));
      }).toList();
      list.sort((a, b) {
        if (a.gender != b.gender) {
          if (a.gender == 'مرد') return -1;
          if (b.gender == 'مرد') return 1;
        }
        return looseText(a.name).compareTo(looseText(b.name));
      });
      return list;
    }

    List<Person> ancestorsOf(Person person) {
      final result = <Person>[];
      var current = person;
      final seen = <String>{person.id};
      for (var i = 0; i < 5; i++) {
        final father = byId(effectiveFatherIdInTree(tree, current)) ?? byLooseName(current.fatherName);
        if (father == null || seen.contains(father.id)) break;
        result.add(father);
        seen.add(father.id);
        current = father;
      }
      return result.reversed.toList();
    }

    final spouses = spousesOf(focus);
    final displaySpouses = spouses.take(4).toList();
    final children = childrenOfPersonOrSpouses(focus, displaySpouses);
    final ancestors = ancestorsOf(focus);
    final collapsed = store.isTreeUnitCollapsed('html-ref-${focus.id}');
    final shownChildren = collapsed ? <Person>[] : children;
    final childCount = shownChildren.length;
    final focusGeneration = ancestors.length + 1;

    return LayoutBuilder(builder: (context, constraints) {
      final screenW = constraints.maxWidth;
      const childW = 164.0;
      const childGap = 18.0;
      const mainW = 620.0;
      final childrenRowWidth = childCount == 0 ? 0.0 : childCount * childW + max(0, childCount - 1) * childGap;
      final treeContentW = max(mainW, childrenRowWidth);
      final boardW = max(screenW, max(760.0, treeContentW + 48.0));
      final boardH = max(620.0, constraints.maxHeight - 16.0);
      final contentLeft = boardW - 24.0 - treeContentW;
      final mainLeft = contentLeft + (treeContentW - mainW) / 2;
      final mainCenter = contentLeft + treeContentW / 2;
      final childStartRight = mainCenter + childrenRowWidth / 2;

      return Container(
        color: const Color(0xFFF8F2E8),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
            child: Row(textDirection: TextDirection.rtl, children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF2DBE98), Color(0xFF286FE8)]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 18, offset: Offset(0, 8))],
                ),
                child: const Icon(Icons.account_tree_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('شجره‌نامه خانوادگی', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: C.ink)),
                  SizedBox(height: 4),
                  Text('کارت خانواده و فرزندان مستقل، جمع‌وجور و شبیه نمونه HTML', style: TextStyle(fontSize: 12.5, color: C.muted, fontWeight: FontWeight.w700)),
                ]),
              ),
            ]),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(34),
                color: Colors.white.withOpacity(.86),
                border: Border.all(color: C.gold.withOpacity(.18)),
                boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 22, offset: Offset(0, 10))],
              ),
              clipBehavior: Clip.antiAlias,
              child: InteractiveViewer(
                constrained: false,
                panEnabled: true,
                scaleEnabled: true,
                minScale: .45,
                maxScale: 2.8,
                boundaryMargin: const EdgeInsets.all(700),
                child: SizedBox(
                  width: boardW,
                  height: boardH,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 32),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      if (ancestors.isNotEmpty)
                        Align(
                          alignment: Alignment.centerRight,
                          child: Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            textDirection: TextDirection.rtl,
                            children: [for (var i = 0; i < ancestors.length; i++) V55AncestorChip(person: ancestors[i], generation: i + 1, onTap: () => onFocus(ancestors[i]), onMore: () => showTreePersonActions(context, ancestors[i]))],
                          ),
                        ),
                      if (ancestors.isNotEmpty) const SizedBox(height: 12),
                      Padding(
                        padding: EdgeInsets.only(right: boardW - mainLeft - mainW - 24.0, left: mainLeft - 24.0),
                        child: SizedBox(
                          width: mainW,
                          child: V55FamilyCard(
                            focus: focus,
                            spouses: displaySpouses,
                            generation: focusGeneration,
                            spouseCount: spouses.length,
                            childrenCount: children.length,
                            collapsed: collapsed,
                            onFocus: onFocus,
                            onMore: (p) => showTreePersonActions(context, p),
                            onToggle: () => store.toggleTreeUnit('html-ref-${focus.id}'),
                            onAdd: () => showQuickFamilySheet(context, focus),
                            onAddSpouse: () => showQuickFamilySheet(context, focus, focus: 'spouse'),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      if (shownChildren.isNotEmpty)
                        SizedBox(
                          height: 78,
                          width: boardW,
                          child: CustomPaint(
                            painter: V55TreeConnectorPainter(
                              childCount: shownChildren.length,
                              childWidth: childW,
                              childGap: childGap,
                              boardWidth: boardW,
                              mainCenter: mainCenter,
                              childStartRight: childStartRight,
                            ),
                          ),
                        ),
                      if (shownChildren.isNotEmpty)
                        Padding(
                          padding: EdgeInsets.only(
                            right: max(0.0, boardW - childStartRight - 24.0),
                            left: max(0.0, childStartRight - childrenRowWidth - 24.0),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            textDirection: TextDirection.rtl,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              for (var i = 0; i < shownChildren.length; i++) ...[
                                SizedBox(
                                  width: childW,
                                  child: V55ChildCard(
                                    person: shownChildren[i],
                                    generation: focusGeneration + 1,
                                    onTap: () => onFocus(shownChildren[i]),
                                    onMore: () => showTreePersonActions(context, shownChildren[i]),
                                  ),
                                ),
                                if (i != shownChildren.length - 1) const SizedBox(width: childGap),
                              ],
                            ],
                          ),
                        )
                      else
                        Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            width: min(340.0, mainW),
                            child: V55EmptyChildCard(
                              collapsed: collapsed,
                              onTap: collapsed ? () => store.toggleTreeUnit('html-ref-${focus.id}') : () => showQuickFamilySheet(context, focus),
                            ),
                          ),
                        ),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ]),
      );
    });
  }
}

class V55TreeConnectorPainter extends CustomPainter {
  final int childCount;
  final double childWidth;
  final double childGap;
  final double boardWidth;
  final double mainCenter;
  final double childStartRight;
  const V55TreeConnectorPainter({required this.childCount, required this.childWidth, required this.childGap, required this.boardWidth, required this.mainCenter, required this.childStartRight});

  @override
  void paint(Canvas canvas, Size size) {
    if (childCount == 0) return;
    final paint = Paint()
      ..color = C.gold.withOpacity(.82)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final topY = 0.0;
    final jointY = 34.0;
    final bottomY = 74.0;
    final centers = <double>[];
    for (var i = 0; i < childCount; i++) {
      final right = childStartRight - i * (childWidth + childGap);
      centers.add(right - childWidth / 2);
    }

    canvas.drawCircle(Offset(mainCenter, topY), 4, Paint()..color = C.gold);

    if (centers.length == 1) {
      final x = centers.first;
      canvas.drawLine(Offset(mainCenter, topY), Offset(x, bottomY), paint);
      canvas.drawCircle(Offset(x, bottomY), 4, Paint()..color = C.gold);
      return;
    }

    canvas.drawLine(Offset(mainCenter, topY), Offset(mainCenter, jointY), paint);
    final minX = centers.reduce(min);
    final maxX = centers.reduce(max);
    canvas.drawLine(Offset(minX, jointY), Offset(maxX, jointY), paint);

    for (final x in centers) {
      canvas.drawLine(Offset(x, jointY), Offset(x, bottomY), paint);
      canvas.drawCircle(Offset(x, bottomY), 4, Paint()..color = C.gold);
    }
  }

  @override
  bool shouldRepaint(covariant V55TreeConnectorPainter oldDelegate) => true;
}

class V55FamilyCard extends StatelessWidget {
  final Person focus;
  final List<Person> spouses;
  final int generation;
  final int spouseCount;
  final int childrenCount;
  final bool collapsed;
  final ValueChanged<Person> onFocus;
  final ValueChanged<Person> onMore;
  final VoidCallback onToggle;
  final VoidCallback onAdd;
  final VoidCallback onAddSpouse;

  const V55FamilyCard({
    super.key,
    required this.focus,
    required this.spouses,
    required this.generation,
    required this.spouseCount,
    required this.childrenCount,
    required this.collapsed,
    required this.onFocus,
    required this.onMore,
    required this.onToggle,
    required this.onAdd,
    required this.onAddSpouse,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 222,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFEFA), Color(0xFFFFF7EA)], begin: Alignment.topRight, end: Alignment.bottomLeft),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: C.gold.withOpacity(.75), width: 1.6),
        boxShadow: [BoxShadow(color: C.ink.withOpacity(.08), blurRadius: 24, offset: const Offset(0, 10))],
      ),
      child: Column(children: [
        Row(textDirection: TextDirection.rtl, children: [
          const Text('خانواده اصلی', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 14)),
          const Spacer(),
          V55Pill(text: 'نسل $generation'),
          const SizedBox(width: 8),
          InkWell(
            onTap: () => onMore(focus),
            borderRadius: BorderRadius.circular(18),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 8)]),
              child: const Icon(Icons.more_horiz, size: 18, color: C.muted),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Expanded(
          child: Row(textDirection: TextDirection.rtl, children: [
            Expanded(child: V55MemberBlock(person: focus, role: 'فرد اصلی', selected: true, onTap: () => onFocus(focus), onMore: () => onMore(focus))),
            Container(
              width: 56,
              alignment: Alignment.center,
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(width: 3, height: 38, decoration: BoxDecoration(color: C.gold.withOpacity(.35), borderRadius: BorderRadius.circular(8))),
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: C.gold.withOpacity(.65)), boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 8)]),
                  child: const Icon(Icons.favorite_border, color: C.gold, size: 20),
                ),
                Container(width: 3, height: 20, decoration: BoxDecoration(color: C.gold.withOpacity(.35), borderRadius: BorderRadius.circular(8))),
              ]),
            ),
            Expanded(
              child: spouses.isEmpty
                  ? InkWell(
                      onTap: onAddSpouse,
                      borderRadius: BorderRadius.circular(22),
                      child: Container(
                        height: 100,
                        decoration: BoxDecoration(color: Colors.white.withOpacity(.75), borderRadius: BorderRadius.circular(22), border: Border.all(color: C.gold.withOpacity(.35))),
                        child: const Center(child: Text('افزودن همسر', style: TextStyle(color: C.gold, fontWeight: FontWeight.w900))),
                      ),
                    )
                  : Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: spouses.take(4).map((sp) => SizedBox(
                        width: spouses.length == 1 ? double.infinity : 118,
                        child: V55MemberBlock(person: sp, role: 'همسر', compact: spouses.length > 1, onTap: () => onFocus(sp), onMore: () => onMore(sp)),
                      )).toList(),
                    ),
            ),
          ]),
        ),
        const SizedBox(height: 10),
        Row(textDirection: TextDirection.rtl, children: [
          V55Pill(text: '$childrenCount فرزند'),
          const SizedBox(width: 8),
          V55Pill(text: '$spouseCount همسر'),
          const Spacer(),
          V55Action(text: collapsed ? 'باز کردن فرزندان' : 'بستن فرزندان', icon: collapsed ? Icons.add : Icons.remove, onTap: onToggle),
          const SizedBox(width: 8),
          V55Action(text: 'افزودن', icon: Icons.person_add_alt_1, onTap: onAdd),
        ]),
      ]),
    );
  }
}

class V55MemberBlock extends StatelessWidget {
  final Person person;
  final String role;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onMore;
  final bool compact;
  const V55MemberBlock({super.key, required this.person, required this.role, required this.onTap, required this.onMore, this.selected = false, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final isFemale = person.gender == 'زن';
    final isMale = person.gender == 'مرد';
    final color = isFemale ? const Color(0xFFD88DAA) : isMale ? const Color(0xFF73A9E8) : C.green;
    final bg1 = isFemale ? const Color(0xFFFFF8FB) : isMale ? const Color(0xFFF8FCFF) : const Color(0xFFF8FFFB);
    final bg2 = isFemale ? const Color(0xFFFFEFF6) : isMale ? const Color(0xFFEEF6FF) : const Color(0xFFE8F8F0);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Stack(clipBehavior: Clip.none, children: [
        Container(
          height: compact ? 86 : 100,
          padding: EdgeInsets.all(compact ? 8 : 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [bg1, bg2], begin: Alignment.topCenter, end: Alignment.bottomCenter),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: selected ? C.gold : color.withOpacity(.85), width: selected ? 1.8 : 1.1),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(isFemale ? Icons.female : isMale ? Icons.male : Icons.person, color: isFemale ? const Color(0xFFC45784) : isMale ? C.blue : C.green, size: compact ? 21 : 25),
            SizedBox(height: compact ? 4 : 6),
            Text(person.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: compact ? 12.2 : 14)),
            const SizedBox(height: 2),
            Text(role, style: TextStyle(color: C.muted, fontSize: compact ? 9 : 10, fontWeight: FontWeight.w700)),
          ]),
        ),
        Positioned(
          left: -5,
          top: -5,
          child: InkWell(
            onTap: onMore,
            borderRadius: BorderRadius.circular(18),
            child: Container(width: 28, height: 28, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 7)]), child: const Icon(Icons.more_horiz, color: C.muted, size: 16)),
          ),
        ),
      ]),
    );
  }
}

class V55ChildCard extends StatelessWidget {
  final Person person;
  final int generation;
  final VoidCallback onTap;
  final VoidCallback onMore;
  const V55ChildCard({super.key, required this.person, required this.generation, required this.onTap, required this.onMore});

  @override
  Widget build(BuildContext context) {
    final isFemale = person.gender == 'زن';
    final isMale = person.gender == 'مرد';
    final color = isFemale ? const Color(0xFFD88DAA) : isMale ? const Color(0xFF73A9E8) : C.green;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(23),
      child: Container(
        height: 194,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFEFA),
          borderRadius: BorderRadius.circular(23),
          border: Border.all(color: C.gold.withOpacity(.52), width: 1.05),
          boxShadow: [BoxShadow(color: C.ink.withOpacity(.055), blurRadius: 16, offset: const Offset(0, 8))],
        ),
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned(
            left: -6,
            top: -6,
            child: InkWell(
              onTap: onMore,
              borderRadius: BorderRadius.circular(18),
              child: Container(width: 28, height: 28, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 7)]), child: const Icon(Icons.more_horiz, color: C.muted, size: 16)),
            ),
          ),
          Positioned(right: 0, top: 0, child: V55Pill(text: 'نسل $generation')),
          Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: (isFemale ? const Color(0xFFFFEFF6) : const Color(0xFFEEF6FF)),
                child: Icon(isFemale ? Icons.female : isMale ? Icons.male : Icons.person, color: isFemale ? const Color(0xFFC45784) : C.blue, size: 26),
              ),
              const SizedBox(height: 12),
              Text(person.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 16)),
              const SizedBox(height: 5),
              Text(person.fatherName.isNotEmpty ? 'فرزند ${person.fatherName}' : person.code, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: C.muted, fontSize: 10.5)),
              const SizedBox(height: 14),
              Container(
                height: 34,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: C.gold.withOpacity(.25))),
                child: const Center(child: Text('مشاهده', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 12))),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class V55EmptyChildCard extends StatelessWidget {
  final bool collapsed;
  final VoidCallback onTap;
  const V55EmptyChildCard({super.key, required this.collapsed, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        height: 92,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white.withOpacity(.88), borderRadius: BorderRadius.circular(22), border: Border.all(color: C.gold.withOpacity(.3))),
        child: Center(child: Text(collapsed ? 'شاخه بسته است؛ باز کن' : 'فرزندی ثبت نشده؛ افزودن فرزند', textAlign: TextAlign.center, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w800))),
      ),
    );
  }
}

class V55AncestorChip extends StatelessWidget {
  final Person person;
  final int generation;
  final VoidCallback onTap;
  final VoidCallback onMore;
  const V55AncestorChip({super.key, required this.person, required this.generation, required this.onTap, required this.onMore});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 154,
      child: V55ChildCard(person: person, generation: generation, onTap: onTap, onMore: onMore),
    );
  }
}

class V55Pill extends StatelessWidget {
  final String text;
  const V55Pill({super.key, required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: const Color(0xFFFFF8E9), borderRadius: BorderRadius.circular(15), border: Border.all(color: C.gold.withOpacity(.18))),
      child: Center(child: Text(text, style: const TextStyle(color: Color(0xFF9B741F), fontSize: 11, fontWeight: FontWeight.w900))),
    );
  }
}

class V55Action extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onTap;
  const V55Action({super.key, required this.text, required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        height: 36,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: C.gold.withOpacity(.22))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: C.ink, size: 16),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 12)),
        ]),
      ),
    );
  }
}

class HtmlBadge extends StatelessWidget {
  final String text;
  const HtmlBadge({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFFAF3E3), borderRadius: BorderRadius.circular(999), border: Border.all(color: C.gold.withOpacity(.18))), child: Text(text, style: const TextStyle(fontSize: 10.5, color: Color(0xFF66511E), fontWeight: FontWeight.w800)));
}

class HtmlEmptyBox extends StatelessWidget {
  final String text;
  const HtmlEmptyBox({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(24), border: Border.all(color: C.gold.withOpacity(.22))), child: Text(text, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700, height: 1.8)));
}

class HtmlAddBox extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const HtmlAddBox({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(24), child: Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFFFFF8E8), borderRadius: BorderRadius.circular(24), border: Border.all(color: C.gold.withOpacity(.24), style: BorderStyle.solid)), child: Row(children: [const Icon(Icons.add_circle, color: C.gold), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(color: Color(0xFF7A6031), fontWeight: FontWeight.w800, height: 1.7)))])));
}

Future<void> showTreePersonActions(BuildContext context, Person person) async {
  final store = StoreProvider.of(context);
  final hasChildren = store.childrenOf(person.id).isNotEmpty;
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: FormSheet(title: 'عملیات سریع برای ${person.name}', children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          ActionChip(avatar: const Icon(Icons.person), label: const Text('پروفایل'), onPressed: () { Navigator.pop(context); openPerson(context, person); }),
          ActionChip(avatar: const Icon(Icons.family_restroom), label: const Text('خانواده'), onPressed: () { Navigator.pop(context); push(context, PersonFamilyPage(personId: person.id)); }),
          ActionChip(avatar: const Icon(Icons.favorite), label: const Text('افزودن همسر'), onPressed: () { Navigator.pop(context); showQuickFamilySheet(context, person, focus: 'spouse'); }),
          ActionChip(avatar: const Icon(Icons.male), label: const Text('افزودن پسر'), onPressed: () { Navigator.pop(context); showQuickFamilySheet(context, person, focus: 'sons'); }),
          ActionChip(avatar: const Icon(Icons.female), label: const Text('افزودن دختر'), onPressed: () { Navigator.pop(context); showQuickFamilySheet(context, person, focus: 'daughters'); }),
          ActionChip(avatar: const Icon(Icons.group_add), label: const Text('چند فرزند'), onPressed: () { Navigator.pop(context); showQuickFamilySheet(context, person); }),
          ActionChip(avatar: const Icon(Icons.elderly), label: const Text('افزودن پدر/مادر'), onPressed: () { Navigator.pop(context); showQuickFamilySheet(context, person, focus: 'parents'); }),
          ActionChip(avatar: const Icon(Icons.account_tree), label: const Text('اصلاح رابطه‌ها'), onPressed: () { Navigator.pop(context); showEditRelationsSheet(context, person); }),
        ]),
        const SizedBox(height: 8),
        HelpBox(text: hasChildren ? 'برای باز و بسته کردن شاخه، دکمه + یا - روی کارت را بزن.' : 'برای همین شخص می‌توانی همسر، پسر، دختر، پدر و مادر را مستقیم از نمودار اضافه کنی.'),
      ]),
    ),
  );
}

Future<void> showQuickFamilySheet(BuildContext context, Person person, {String focus = ''}) async {
  final store = StoreProvider.of(context);
  final spouse = TextEditingController();
  final spouseFather = TextEditingController();
  final father = TextEditingController();
  final grandfather = TextEditingController();
  final mother = TextEditingController();
  final sons = TextEditingController();
  final daughters = TextEditingController();

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: FormSheet(title: 'افزودن سریع برای ${person.name}', children: [
        const HelpBox(text: 'از این بخش می‌توانی مستقیم از روی نمودار، همسر، پسران، دختران، پدر و مادر را برای همین شخص ثبت کنی. چند نام را با ویرگول جدا کن.'),
        if (focus.isEmpty || focus == 'spouse') ...[
          AppField(controller: spouse, label: 'نام همسر'),
          AppField(controller: spouseFather, label: 'نام پدر همسر'),
          const Divider(height: 22),
        ],
        if (focus.isEmpty || focus == 'parents') ...[
          AppField(controller: father, label: 'نام پدر'),
          AppField(controller: grandfather, label: 'نام پدربزرگ / پدرِ پدر'),
          AppField(controller: mother, label: 'نام مادر'),
          const Divider(height: 22),
        ],
        if (focus.isEmpty || focus == 'sons') AppField(controller: sons, label: 'پسران', hint: 'مثلاً سهیل، الیاس'),
        if (focus.isEmpty || focus == 'daughters') AppField(controller: daughters, label: 'دختران', hint: 'مثلاً مریم، الینا'),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () async {
            final msg = await store.addQuickFamilyForPerson(
              person,
              spouseName: spouse.text,
              spouseFatherName: spouseFather.text,
              fatherName: father.text,
              grandfatherName: grandfather.text,
              motherName: mother.text,
              sonsRaw: sons.text,
              daughtersRaw: daughters.text,
            );
            if (!context.mounted) return;
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
          },
          icon: const Icon(Icons.save),
          label: const Text('ثبت و نمایش در نمودار'),
        ),
      ]),
    ),
  );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final q = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final result = store.searchPeople(q.text);
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const AppHeader(title: 'جستجو و مدیریت افراد', subtitle: 'جستجو، اصلاح رابطه‌ها، تکراری‌ها و مدیریت افراد'),
            const SizedBox(height: 12),
            if (store.current != null) QuickSectionCard(
              title: 'ابزارهای مربوط به افراد',
              subtitle: 'ابزارهای مدیریتی از صفحه امکانات منتقل شدند.',
              children: [
                QuickMiniButton(title: 'مدیریت افراد', icon: Icons.manage_accounts_rounded, color: C.blue, onTap: () => push(context, const PeopleManagePage())),
                QuickMiniButton(title: 'افراد تکراری', icon: Icons.merge_type, color: C.green, onTap: () => push(context, const DuplicatesPage())),
                QuickMiniButton(title: 'اصلاح خودکار', icon: Icons.auto_fix_high_rounded, color: C.green, onTap: () => push(context, const AutoRepairPage())),
              ],
            ),
            const SizedBox(height: 12),
            TextField(controller: q, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'نام، پدر، مادر، همسر، کد، شهر یا شماره')),
          ]),
        ),
        Expanded(child: result.isEmpty ? const Center(child: Text('نتیجه‌ای پیدا نشد.')) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: result.length, itemBuilder: (_, i) => PersonListTile(person: result[i]))),
      ]),
    );
  }
}

class PersonListTile extends StatelessWidget {
  final Person person;
  const PersonListTile({super.key, required this.person});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: PremiumCard(
        onTap: () => openPerson(context, person),
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          CircleAvatar(backgroundColor: C.mint, child: Text(person.name.isEmpty ? '?' : person.name.characters.first, style: const TextStyle(color: C.green, fontWeight: FontWeight.w900))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(person.name, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)), Text(person.fatherName.isEmpty ? person.code : 'فرزند ${person.fatherName} • ${person.code}', style: const TextStyle(color: C.muted, fontSize: 12))])),
          const Icon(Icons.chevron_left, color: C.muted),
        ]),
      ),
    );
  }
}

void openPerson(BuildContext context, Person p) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => PersonDetailsPage(personId: p.id)));
}

class PersonDetailsPage extends StatelessWidget {
  final String personId;
  const PersonDetailsPage({super.key, required this.personId});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return AnimatedBuilder(animation: store, builder: (_, __) {
      final p = store.personById(personId);
      if (p == null) return const Scaffold(body: Center(child: Text('شخص پیدا نشد.')));
      final father = store.personById(p.fatherId);
      final spouse = store.personById(p.spouseId);
      final children = store.childrenOf(p.id);
      final siblings = store.siblingsOf(p);
      final tree = store.current!;
      return Scaffold(
        appBar: AppBar(title: Text(p.name), actions: [
          IconButton(onPressed: () => sharePersonInvite(context, tree, p), icon: const Icon(Icons.ios_share)),
          IconButton(onPressed: () => showAddChildSheet(context, p), icon: const Icon(Icons.child_care)),
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddPersonPage(editPerson: p))), icon: const Icon(Icons.edit)),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'relations') showEditRelationsSheet(context, p);
              if (value == 'delete') confirmDeletePerson(context, p, closePage: true);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'relations', child: Text('اصلاح رابطه‌ها')),
              PopupMenuItem(value: 'delete', child: Text('حذف شخص')),
            ],
          ),
        ]),
        body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.sky, C.cream, C.mint]), borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 24, offset: Offset(0, 12))]),
            child: Column(children: [
              const CircleAvatar(radius: 42, backgroundColor: C.white, child: Icon(Icons.person, size: 48, color: C.green)),
              const SizedBox(height: 10),
              Text(p.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.ink)),
              Text(p.code, style: const TextStyle(color: C.muted)),
              if (p.specialTag.isNotEmpty) Chip(label: Text(p.specialTag), backgroundColor: C.white),
            ]),
          ),
          const SizedBox(height: 12),
          InfoGrid(items: {
            'پدر': father?.name ?? p.fatherName,
            'پدربزرگ': p.grandfatherName,
            'مادر': p.motherName,
            'همسر': spouse?.name ?? p.spouseName,
            'جنسیت': p.gender,
            'تولد': p.birthDate,
            'فوت': p.deathDate,
            'محل تولد': p.birthPlace,
            'محل زندگی': p.livingPlace,
            'شاخه': p.branch,
            'شماره': (p.phonePrivate || store.protectPhones) ? 'خصوصی' : p.phone,
          }),
          if (p.notes.isNotEmpty) ...[const SizedBox(height: 12), PremiumCard(child: Text(p.notes, style: const TextStyle(height: 1.8, color: C.ink)))],
          const SizedBox(height: 12),
          SectionTitle(title: 'خانواده این شخص'),
          FamilySummaryCard(person: p, father: father, mother: store.personById(p.motherId), spouse: spouse, children: children),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(onPressed: () => push(context, PersonFamilyPage(personId: p.id)), icon: const Icon(Icons.family_restroom), label: const Text('نمای کامل خانواده این شخص')),
          const SizedBox(height: 12),
          SectionTitle(title: 'روابط خانوادگی'),
          RelationWrap(title: 'فرزندان', people: children),
          RelationWrap(title: 'خواهر/برادر', people: siblings),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => showAddChildSheet(context, p), icon: const Icon(Icons.child_care), label: const Text('افزودن فرزند برای این شخص')),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(onPressed: () => showEditRelationsSheet(context, p), icon: const Icon(Icons.account_tree), label: const Text('اصلاح دستی پدر/مادر/همسر')),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: () => showRelationDialog(context, p), icon: const Icon(Icons.compare_arrows), label: const Text('جستجوی نسبت با شخص دیگر')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () => sharePersonInvite(context, tree, p), icon: const Icon(Icons.ios_share), label: const Text('ارسال دعوت برای تکمیل اطلاعات')),
        ])),
      );
    });
  }
}

class InfoGrid extends StatelessWidget {
  final Map<String, String> items;
  const InfoGrid({super.key, required this.items});
  @override
  Widget build(BuildContext context) {
    final entries = items.entries.where((e) => e.value.trim().isNotEmpty).toList();
    return PremiumCard(child: Column(children: entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [SizedBox(width: 86, child: Text(e.key, style: const TextStyle(color: C.muted))), Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800, color: C.ink)))]))).toList()));
  }
}

class RelationWrap extends StatelessWidget {
  final String title;
  final List<Person> people;
  const RelationWrap({super.key, required this.title, required this.people});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
        const SizedBox(height: 8),
        if (people.isEmpty) const Text('ثبت نشده', style: TextStyle(color: C.muted)) else Wrap(spacing: 8, runSpacing: 8, children: people.map((p) => ActionChip(label: Text(p.name), onPressed: () => openPerson(context, p))).toList()),
      ]),
    );
  }
}


class FamilySummaryCard extends StatelessWidget {
  final Person person;
  final Person? father;
  final Person? mother;
  final Person? spouse;
  final List<Person> children;
  const FamilySummaryCard({super.key, required this.person, this.father, this.mother, this.spouse, required this.children});

  @override
  Widget build(BuildContext context) {
    Widget chip(String label, Person? p, IconData icon) {
      return ActionChip(
        avatar: Icon(icon, size: 18, color: C.blue),
        label: Text(p?.name ?? 'ثبت نشده'),
        onPressed: p == null ? null : () => openPerson(context, p),
      );
    }

    return PremiumCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          chip('پدر', father, Icons.man),
          chip('مادر', mother, Icons.woman),
          chip('همسر', spouse, Icons.favorite),
        ]),
        const SizedBox(height: 12),
        Text('فرزندان: ${children.isEmpty ? 'ثبت نشده' : children.length}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (children.isNotEmpty) Wrap(spacing: 8, runSpacing: 8, children: children.map((c) => ActionChip(label: Text(c.name), onPressed: () => openPerson(context, c))).toList()),
      ]),
    );
  }
}

Future<void> showAddChildSheet(BuildContext context, Person parent) async {
  final store = StoreProvider.of(context);
  final name = TextEditingController();
  var gender = 'نامشخص';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'افزودن فرزند برای ${parent.name}', children: [
      const HelpBox(text: 'فرزند جدید زیر همین شخص ثبت می‌شود. اگر این شخص همسر داشته باشد، پدر/مادر دوم هم خودکار وصل می‌شود.'),
      AppField(controller: name, label: 'نام فرزند'),
      DropdownButtonFormField<String>(
        value: gender,
        decoration: const InputDecoration(labelText: 'جنسیت'),
        items: const ['نامشخص', 'مرد', 'زن'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setModal(() => gender = v ?? 'نامشخص'),
      ),
      FilledButton.icon(
        onPressed: () async {
          final msg = await store.addChildForParent(parent, childName: name.text, gender: gender);
          if (!context.mounted) return;
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
        },
        icon: const Icon(Icons.save),
        label: const Text('ثبت فرزند'),
      ),
    ])),
  );
}

Future<void> showEditRelationsSheet(BuildContext context, Person person) async {
  final store = StoreProvider.of(context);
  String? fatherId = person.fatherId;
  String? motherId = person.motherId;
  String? spouseId = person.spouseId;

  List<DropdownMenuItem<String?>> items(String noneText, {String? excludeId}) {
    final people = store.current?.people.where((p) => p.id != excludeId).toList() ?? [];
    return [
      DropdownMenuItem<String?>(value: null, child: Text(noneText)),
      ...people.map((p) => DropdownMenuItem<String?>(value: p.id, child: Text('${p.name} • ${p.code}'))),
    ];
  }

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'اصلاح رابطه‌های ${person.name}', children: [
      const HelpBox(text: 'اینجا می‌توانی پدر، مادر یا همسر را دستی انتخاب کنی. رابطه همسر به صورت دوطرفه اصلاح می‌شود.'),
      DropdownButtonFormField<String?>(
        value: fatherId,
        decoration: const InputDecoration(labelText: 'پدر'),
        items: items('بدون پدر', excludeId: person.id),
        onChanged: (v) => setModal(() => fatherId = v),
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String?>(
        value: motherId,
        decoration: const InputDecoration(labelText: 'مادر'),
        items: items('بدون مادر', excludeId: person.id),
        onChanged: (v) => setModal(() => motherId = v),
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String?>(
        value: spouseId,
        decoration: const InputDecoration(labelText: 'همسر'),
        items: items('بدون همسر', excludeId: person.id),
        onChanged: (v) => setModal(() => spouseId = v),
      ),
      Row(children: [
        Expanded(child: OutlinedButton(onPressed: () async { final msg = await store.detachSpouse(person); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg))); setModal(() => spouseId = null); }, child: const Text('حذف همسر'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton(onPressed: () => setModal(() { fatherId = null; motherId = null; }), child: const Text('حذف والدین'))),
      ]),
      FilledButton.icon(
        onPressed: () async {
          final msg = await store.updatePersonRelations(person: person, fatherId: fatherId, motherId: motherId, spouseId: spouseId);
          if (!context.mounted) return;
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
        },
        icon: const Icon(Icons.save),
        label: const Text('ذخیره رابطه‌ها'),
      ),
    ])),
  );
}

Future<void> confirmDeletePerson(BuildContext context, Person person, {bool closePage = false}) async {
  final store = StoreProvider.of(context);
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('حذف شخص'),
      content: Text('آیا ${person.name} حذف شود؟ رابطه فرزندان/همسر هم پاک‌سازی می‌شود. قبل از حذف بکاپ امن گرفته می‌شود.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
      ],
    ),
  );
  if (ok != true) return;
  final msg = await store.deletePerson(person);
  if (!context.mounted) return;
  if (closePage) Navigator.pop(context);
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

void sharePersonInvite(BuildContext context, FamilyTree tree, Person p) {
  final link = 'https://nasabnama.local/invite/${tree.code}/${p.code}';
  final text = '''سلام 🌿
شما به عنوان عضوی از شجره‌نامه «${tree.title}» ثبت شده‌اید.

نام ثبت‌شده: ${p.name}
کد شخص: ${p.code}
کد دعوت شجره: ${tree.code}

برای مشاهده و تکمیل اطلاعات خانوادگی از این لینک استفاده کنید:
$link''';
  Share.share(text, subject: 'دعوت شجره‌نامه');
}

Future<void> showRelationDialog(BuildContext context, Person base) async {
  final store = StoreProvider.of(context);
  Person? selected;
  String message = '';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'جستجوی نسبت فامیلی', children: [
      DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'شخص دوم'), items: (store.current?.people ?? []).where((p) => p.id != base.id).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (id) => setModal(() => selected = store.personById(id))),
      FilledButton(onPressed: selected == null ? null : () => setModal(() => message = store.relationBetween(base, selected!)), child: const Text('محاسبه نسبت')),
      if (message.isNotEmpty) HelpBox(text: message),
    ])),
  );
}


class FullFamilyEntryPage extends StatefulWidget {
  const FullFamilyEntryPage({super.key});
  @override
  State<FullFamilyEntryPage> createState() => _FullFamilyEntryPageState();
}

class _FullFamilyEntryPageState extends State<FullFamilyEntryPage> {
  final headName = TextEditingController();
  final headFatherName = TextEditingController();
  final headGrandfatherName = TextEditingController();
  final headPhone = TextEditingController();
  final spouseName = TextEditingController();
  final spouseFatherName = TextEditingController();
  final spousePhone = TextEditingController();
  final sons = TextEditingController();
  final daughters = TextEditingController();
  final branch = TextEditingController();
  final livingPlace = TextEditingController();
  final notes = TextEditingController();

  String? selectedHeadId;

  @override
  void dispose() {
    headName.dispose();
    headFatherName.dispose();
    headGrandfatherName.dispose();
    headPhone.dispose();
    spouseName.dispose();
    spouseFatherName.dispose();
    spousePhone.dispose();
    sons.dispose();
    daughters.dispose();
    branch.dispose();
    livingPlace.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> _openPreview(BuildContext context, AppStore store) async {
    final sonList = store.splitFamilyNames(sons.text);
    final daughterList = store.splitFamilyNames(daughters.text);
    final candidates = store.findFamilyHeadCandidates(
      headName.text,
      headFatherName.text,
      headGrandfatherName: headGrandfatherName.text,
    );
    if (candidates.length == 1) selectedHeadId ??= candidates.first.id;
    if (selectedHeadId != null && !candidates.any((p) => p.id == selectedHeadId)) selectedHeadId = null;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .86),
                padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 18),
                decoration: const BoxDecoration(
                  color: C.bg,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                ),
                child: SingleChildScrollView(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Center(child: Container(width: 54, height: 5, decoration: BoxDecoration(color: C.muted.withOpacity(.35), borderRadius: BorderRadius.circular(99)))),
                    const SizedBox(height: 14),
                    const SectionTitle(title: 'پیش‌نمایش ثبت خانواده'),
                    PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      PreviewLine(label: 'پدر خانواده', value: headName.text.trim().isEmpty ? 'ثبت نشده' : '${headName.text.trim()}${headFatherName.text.trim().isEmpty ? '' : ' فرزند ${headFatherName.text.trim()}'}'),
                      PreviewLine(label: 'پدربزرگ پدر', value: headGrandfatherName.text.trim().isEmpty ? 'ثبت نشده' : headGrandfatherName.text.trim()),
                      PreviewLine(label: 'همسر', value: spouseName.text.trim().isEmpty ? 'ثبت نشده' : spouseName.text.trim()),
                      PreviewLine(label: 'پسران', value: sonList.isEmpty ? 'ثبت نشده' : sonList.join('، ')),
                      PreviewLine(label: 'دختران', value: daughterList.isEmpty ? 'ثبت نشده' : daughterList.join('، ')),
                      const SizedBox(height: 10),
                      if (candidates.isEmpty)
                        const HelpBox(text: 'شخص مشابهی برای پدر خانواده پیدا نشد. در صورت ثبت، پدر خانواده در جایگاه واردشده ساخته می‌شود و اگر پدر/پدربزرگش در شجره نبود، شاخه بالادستی هم خودکار ساخته می‌شود.'),
                      if (candidates.length == 1)
                        HelpBox(text: 'جایگاه پیشنهادی پیدا شد: ${candidates.first.name} • ${candidates.first.code}. اطلاعات جدید با همین شخص ادغام می‌شود و تکراری ساخته نمی‌شود.'),
                      if (candidates.length > 1) ...[
                        const HelpBox(text: 'چند شخص مشابه پیدا شد. مشخص کن این خانواده باید به کدام شخص وصل شود تا اسم تکراری ساخته نشود.'),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          value: selectedHeadId,
                          decoration: const InputDecoration(labelText: 'انتخاب جایگاه پدر خانواده'),
                          items: candidates.map((p) => DropdownMenuItem(value: p.id, child: Text('${p.name} • ${p.fatherName.isEmpty ? p.code : 'فرزند ${p.fatherName}'}'))).toList(),
                          onChanged: (v) {
                            selectedHeadId = v;
                            setSheetState(() {});
                            setState(() {});
                          },
                        ),
                      ],
                    ])),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.edit), label: const Text('ویرایش'))),
                      const SizedBox(width: 10),
                      Expanded(flex: 2, child: FilledButton.icon(
                        onPressed: headName.text.trim().isEmpty || (candidates.length > 1 && selectedHeadId == null) ? null : () async {
                          final msg = await store.addFullFamily(
                            headName: headName.text,
                            headFatherName: headFatherName.text,
                            headGrandfatherName: headGrandfatherName.text,
                            headPhone: headPhone.text,
                            spouseName: spouseName.text,
                            spouseFatherName: spouseFatherName.text,
                            spousePhone: spousePhone.text,
                            sonsRaw: sons.text,
                            daughtersRaw: daughters.text,
                            branch: branch.text,
                            livingPlace: livingPlace.text,
                            notes: notes.text,
                            selectedHeadId: selectedHeadId,
                          );
                          if (!mounted) return;
                          Navigator.pop(sheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
                          if (msg.startsWith('خانواده ثبت شد')) {
                            setState(() {
                              selectedHeadId = null;
                              headName.clear();
                              headFatherName.clear();
                              headGrandfatherName.clear();
                              headPhone.clear();
                              spouseName.clear();
                              spouseFatherName.clear();
                              spousePhone.clear();
                              sons.clear();
                              daughters.clear();
                              branch.clear();
                              livingPlace.clear();
                              notes.clear();
                            });
                          }
                        },
                        icon: const Icon(Icons.save),
                        label: const Text('تأیید و ثبت خانواده'),
                      )),
                    ]),
                  ]),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;

    return Scaffold(
      appBar: AppBar(title: const Text('افزودن خانواده کامل')),
      body: SafeArea(
        child: tree == null
            ? Center(child: Padding(padding: const EdgeInsets.all(16), child: EmptyState(onCreate: () => showTreeDialog(context))))
            : SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 24),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const AppHeader(title: 'ثبت یک‌جای خانواده', subtitle: 'پدر، مادر و فرزندان را یک‌جا وارد کن؛ پیش‌نمایش داخل پاپ‌آپ باز می‌شود'),
                  const SizedBox(height: 12),
                  PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const HelpBox(text: 'مثلاً: محمد فرزند عبدالواحد، پدربزرگ ملاعمر، همسر صدیقه، پسران سهیل و الیاس، دختران مریم و الینا. اپ قبل از ثبت، جایگاه و افراد تکراری را بررسی می‌کند.'),
                    const SizedBox(height: 12),
                    AppField(controller: headName, label: 'نام پدر خانواده *', hint: 'مثلاً محمد'),
                    AppField(controller: headFatherName, label: 'نام پدرِ پدر خانواده', hint: 'مثلاً عبدالواحد'),
                    AppField(controller: headGrandfatherName, label: 'نام پدربزرگِ پدر خانواده', hint: 'مثلاً ملاعمر'),
                    AppField(controller: headPhone, label: 'شماره پدر خانواده، اختیاری', keyboard: TextInputType.phone),
                    const Divider(height: 26),
                    AppField(controller: spouseName, label: 'نام همسر', hint: 'مثلاً صدیقه'),
                    AppField(controller: spouseFatherName, label: 'نام پدرِ همسر، اختیاری'),
                    AppField(controller: spousePhone, label: 'شماره همسر، اختیاری', keyboard: TextInputType.phone),
                    const Divider(height: 26),
                    AppField(controller: sons, label: 'پسران', hint: 'سهیل، الیاس یا سهیل و الیاس', maxLines: 2),
                    AppField(controller: daughters, label: 'دختران', hint: 'مریم، الینا یا مریم و الینا', maxLines: 2),
                    Row(children: [Expanded(child: AppField(controller: branch, label: 'شاخه خانوادگی')), const SizedBox(width: 8), Expanded(child: AppField(controller: livingPlace, label: 'محل زندگی'))]),
                    AppField(controller: notes, label: 'توضیحات مشترک خانواده', maxLines: 3),
                    const SizedBox(height: 8),
                    FilledButton.icon(onPressed: () => _openPreview(context, store), icon: const Icon(Icons.visibility), label: const Text('پیش‌نمایش قبل از ثبت')),
                  ])),
                ]),
              ),
      ),
    );
  }
}

class PreviewLine extends StatelessWidget {
  final String label;
  final String value;
  const PreviewLine({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 96, child: Text(label, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700))),
        Expanded(child: Text(value, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900))),
      ]),
    );
  }
}


class QuickSectionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Widget> children;
  const QuickSectionCard({super.key, required this.title, required this.subtitle, required this.children});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 16)),
        if (subtitle.trim().isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: C.muted, height: 1.5, fontSize: 12)),
        ],
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: children),
      ]),
    );
  }
}

class QuickMiniButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const QuickMiniButton({super.key, required this.title, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(icon, size: 18, color: color),
      label: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      onPressed: onTap,
      backgroundColor: color.withOpacity(.10),
      side: BorderSide(color: color.withOpacity(.22)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const AppHeader(title: 'بخش‌های جانبی', subtitle: 'موارد اصلی به صفحه‌های مرتبط منتقل شدند'),
          const SizedBox(height: 12),
          if (tree == null) EmptyState(onCreate: () => showTreeDialog(context)) else ...[
            const HelpBox(text: 'افزودن خانواده در صفحه افزودن است. مدیریت افراد و اصلاح تکراری‌ها در صفحه جستجو است. بکاپ، CSV و تنظیمات هم در صفحه تنظیمات/بکاپ هستند.'),
            const SizedBox(height: 12),
            SectionTitle(title: 'اعضا و ارتباط خانوادگی'),
            QuickSectionCard(
              title: 'اعضا و مشارکت',
              subtitle: 'دسترسی، چت و رأی‌گیری محلی',
              children: [
                QuickMiniButton(title: 'اعضا و دسترسی', icon: Icons.admin_panel_settings, color: C.blue, onTap: () => push(context, const MembersPage())),
                QuickMiniButton(title: 'چت خانوادگی', icon: Icons.chat_bubble, color: C.green, onTap: () => push(context, const ChatPage())),
                QuickMiniButton(title: 'رأی‌گیری', icon: Icons.how_to_vote, color: C.blue, onTap: () => push(context, const PollsPage())),
              ],
            ),
            const SizedBox(height: 12),
            SectionTitle(title: 'محتوا و اسناد'),
            QuickSectionCard(
              title: 'اسناد و رویدادها',
              subtitle: 'تصاویر، مدارک و مناسبت‌های خانوادگی',
              children: [
                QuickMiniButton(title: 'گالری و اسناد', icon: Icons.photo_library, color: C.gold, onTap: () => push(context, const ItemsPage())),
                QuickMiniButton(title: 'مناسبت‌ها', icon: Icons.event, color: C.red, onTap: () => push(context, const EventsPage())),
              ],
            ),
            const SizedBox(height: 12),
            SectionTitle(title: 'راهنما و تنظیمات'),
            QuickSectionCard(
              title: 'کمک و تنظیمات',
              subtitle: 'تنظیمات امنیتی و راهنمای استفاده',
              children: [
                QuickMiniButton(title: 'اشتراک', icon: Icons.workspace_premium_rounded, color: C.gold, onTap: () => push(context, const SubscriptionPage())),
                QuickMiniButton(title: 'تنظیمات و امنیت', icon: Icons.settings, color: C.blue, onTap: () => push(context, const SettingsPage())),
                QuickMiniButton(title: 'راهنما', icon: Icons.help, color: C.red, onTap: () => push(context, const HelpPage())),
              ],
            ),
          ],
        ]),
      ),
    );
  }
}

void push(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

class FeatureTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const FeatureTile({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => PremiumCard(onTap: onTap, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [CircleAvatar(radius: 26, backgroundColor: color.withOpacity(.13), child: Icon(icon, color: color)), const SizedBox(height: 10), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink))]));
}




class SubscriptionStatusCard extends StatelessWidget {
  final AppStore store;
  const SubscriptionStatusCard({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final premium = store.isPremium;
    return PremiumCard(
      onTap: () => push(context, const SubscriptionPage()),
      padding: const EdgeInsets.all(14),
      child: Row(textDirection: TextDirection.rtl, children: [
        CircleAvatar(
          backgroundColor: premium ? const Color(0xFFFFF3D7) : C.sky,
          child: Icon(premium ? Icons.workspace_premium_rounded : Icons.lock_clock_rounded, color: premium ? C.gold : C.blue),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(premium ? 'اشتراک فعال: ${store.planTitle}' : 'نسخه رایگان محدود', style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 4),
          Text(premium ? 'اعتبار تا ${store.planExpireText}' : '۱ شجره و ۲۵ نفر رایگان؛ برای امکانات کامل اشتراک فعال کن.', style: const TextStyle(color: C.muted, fontSize: 12.5, height: 1.5)),
        ])),
        const SizedBox(width: 8),
        const Icon(Icons.chevron_left_rounded, color: C.muted),
      ]),
    );
  }
}

class SubscriptionPage extends StatefulWidget {
  const SubscriptionPage({super.key});

  @override
  State<SubscriptionPage> createState() => _SubscriptionPageState();
}

class _SubscriptionPageState extends State<SubscriptionPage> {
  bool loading = false;
  String? loadingProductId;

  bool get _hasBazaarKey => kBazaarPublicKey.trim().isNotEmpty && kBazaarPublicKey != 'CHANGE_THIS_BAZAAR_PUBLIC_KEY';

  Future<void> _buy(BuildContext context, NasabSubscriptionPlan plan) async {
    final store = StoreProvider.of(context);
    if (!_hasBazaarKey) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کلید عمومی پرداخت بازار هنوز تنظیم نشده است.')));
      return;
    }
    setState(() {
      loading = true;
      loadingProductId = plan.id;
    });
    try {
      final bazaar = CafebazaarFlutter.instance;
      final inapp = bazaar.inAppPurchase(kBazaarPublicKey);
      final dynamic purchaseInfo = await inapp.subscribe(plan.id, payLoad: 'nasab_${plan.id}_${DateTime.now().millisecondsSinceEpoch}');
      if (purchaseInfo != null) {
        final orderId = (purchaseInfo.orderId ?? '').toString();
        final token = (purchaseInfo.purchaseToken ?? '').toString();
        final msg = await store.activateSubscriptionFromBazaarProduct(plan.id, orderId: orderId, purchaseToken: token);
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
        setState(() {});
      } else {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خرید انجام نشد یا لغو شد.')));
      }
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خرید انجام نشد. اگر پرداخت را لغو کرده‌ای، دوباره تلاش کن.')));
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
          loadingProductId = null;
        });
      }
    }
  }

  Future<void> _restore(BuildContext context) async {
    final store = StoreProvider.of(context);
    if (!_hasBazaarKey) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کلید عمومی پرداخت بازار هنوز تنظیم نشده است.')));
      return;
    }
    setState(() {
      loading = true;
      loadingProductId = 'restore';
    });
    try {
      final bazaar = CafebazaarFlutter.instance;
      final inapp = bazaar.inAppPurchase(kBazaarPublicKey);
      final dynamic purchases = await inapp.getSubscribedProducts();
      String? restoredProductId;
      String orderId = '';
      String token = '';
      if (purchases is Iterable) {
        for (final item in purchases) {
          final productId = (item.productId ?? '').toString();
          if (planById(productId) != null) {
            restoredProductId = productId;
            orderId = (item.orderId ?? '').toString();
            token = (item.purchaseToken ?? '').toString();
            break;
          }
        }
      }
      if (restoredProductId == null) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اشتراک فعالی در بازار پیدا نشد.')));
      } else {
        final msg = await store.activateSubscriptionFromBazaarProduct(restoredProductId, orderId: orderId, purchaseToken: token);
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('بازیابی شد؛ $msg')));
        setState(() {});
      }
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بازیابی خرید انجام نشد. اتصال به بازار را بررسی کن.')));
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
          loadingProductId = null;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final premium = store.isPremium;
    return Scaffold(
      appBar: AppBar(title: const Text('اشتراک کافه‌بازار')),
      body: AnimatedBuilder(
        animation: store,
        builder: (_, __) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            PremiumCard(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(textDirection: TextDirection.rtl, children: [
                  CircleAvatar(radius: 25, backgroundColor: premium ? const Color(0xFFFFF3D7) : C.sky, child: Icon(premium ? Icons.workspace_premium_rounded : Icons.lock_outline_rounded, color: premium ? C.gold : C.blue)),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(premium ? 'اشتراک فعال است' : 'نسخه رایگان محدود', style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 18)),
                    const SizedBox(height: 4),
                    Text(premium ? '${store.planTitle} تا ${store.planExpireText}' : 'رایگان: فقط ۱ شجره و حداکثر ۲۵ نفر', style: const TextStyle(color: C.muted, height: 1.5)),
                  ])),
                ]),
                const SizedBox(height: 12),
                const Divider(),
                const SizedBox(height: 8),
                const Text('با فعال شدن اشتراک، محدودیت تعداد شجره و افراد برداشته می‌شود و امکانات حرفه‌ای آینده مثل خروجی PDF، عکس شجره، CSV و بکاپ کامل برای کاربر باز خواهد شد.', textAlign: TextAlign.right, style: TextStyle(color: C.muted, height: 1.7, fontWeight: FontWeight.w700)),
              ]),
            ),
            const SizedBox(height: 14),
            if (!_hasBazaarKey)
              const HelpBox(text: 'برای فعال شدن پرداخت واقعی، کلید عمومی پرداخت درون‌برنامه‌ای بازار باید در GitHub Secrets با نام BAZAAR_PUBLIC_KEY ثبت شود. Product IDها داخل همین صفحه مشخص هستند.'),
            const SizedBox(height: 12),
            const SectionTitle(title: 'پلن‌های اشتراک بازار'),
            ...kNasabSubscriptionPlans.map((plan) => SubscriptionPlanCard(
                  plan: plan,
                  active: premium && store.subscriptionPlanId == plan.id,
                  loading: loading && loadingProductId == plan.id,
                  onTap: loading ? null : () => _buy(context, plan),
                )),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: loading ? null : () => _restore(context),
              icon: loadingProductId == 'restore' ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.restore_rounded),
              label: const Text('بازیابی خرید از کافه‌بازار'),
            ),
            const SizedBox(height: 12),
            const HelpBox(text: 'Product IDهایی که باید در پنل کافه‌بازار بسازی: nasab_monthly_100، nasab_3month_250، nasab_6month_560، nasab_yearly_1000'),
          ],
        ),
      ),
    );
  }
}

class SubscriptionPlanCard extends StatelessWidget {
  final NasabSubscriptionPlan plan;
  final bool active;
  final bool loading;
  final VoidCallback? onTap;
  const SubscriptionPlanCard({super.key, required this.plan, required this.active, required this.loading, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      child: Row(textDirection: TextDirection.rtl, children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: active ? const [Color(0xFFF9D976), Color(0xFFF39F86)] : const [Color(0xFFE9F8F3), Color(0xFFEAF2FF)]),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Icon(active ? Icons.verified_rounded : Icons.workspace_premium_rounded, color: active ? Colors.white : C.blue),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Row(textDirection: TextDirection.rtl, children: [
            Expanded(child: Text(plan.title, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 16))),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: C.gold.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
              child: Text(plan.badge, style: const TextStyle(color: C.gold, fontWeight: FontWeight.w900, fontSize: 11)),
            ),
          ]),
          const SizedBox(height: 6),
          Text(plan.priceText, textAlign: TextAlign.right, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text('Product ID: ${plan.id}', textAlign: TextAlign.right, style: const TextStyle(color: C.muted, fontSize: 10.5)),
        ])),
        const SizedBox(width: 10),
        FilledButton(
          onPressed: active ? null : onTap,
          child: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(active ? 'فعال' : 'خرید'),
        ),
      ]),
    );
  }
}


class AutoRepairPage extends StatelessWidget {
  const AutoRepairPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final orphans = store.orphanedPeople();
    final warnings = store.onlineReadinessWarnings();
    return Scaffold(
      appBar: AppBar(title: const Text('اصلاح خودکار شجره')),
      body: AnimatedBuilder(animation: store, builder: (_, __) {
        final orphanList = store.orphanedPeople();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const HelpBox(text: 'این ابزار قبل از اصلاح، بکاپ امن می‌گیرد و بعد رابطه‌های ناقص، همسرهای یک‌طرفه و افراد تکراری را بررسی می‌کند.'),
            const SizedBox(height: 12),
            PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('گزارش سریع', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 18)),
              const SizedBox(height: 8),
              PreviewLine(label: 'روابط ناقص', value: '${orphanList.length}'),
              PreviewLine(label: 'تکراری‌ها', value: '${store.duplicateGroups().length} گروه'),
              ...warnings.map((w) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('• $w', style: const TextStyle(color: C.muted, height: 1.6)))),
            ])),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () async {
                final msg = await store.autoRepairCurrentTree();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
              },
              icon: const Icon(Icons.auto_fix_high),
              label: const Text('اجرای اصلاح خودکار'),
            ),
            const SizedBox(height: 12),
            const SectionTitle(title: 'افراد دارای رابطه ناقص'),
            if (orphanList.isEmpty)
              const PremiumCard(child: Text('رابطه ناقصی پیدا نشد.', style: TextStyle(color: C.ink)))
            else
              ...orphanList.map((p) => PremiumCard(
                    padding: const EdgeInsets.all(12),
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.warning_amber_rounded, color: C.gold),
                      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('پدر: ${p.fatherName.isEmpty ? '-' : p.fatherName} | مادر: ${p.motherName.isEmpty ? '-' : p.motherName}'),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () => openPerson(context, p),
                    ),
                  )),
          ],
        );
      }),
    );
  }
}

class TextExportPage extends StatelessWidget {
  const TextExportPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final text = store.treeSummaryText();
    return Scaffold(
      appBar: AppBar(title: const Text('خروجی متنی شجره')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const HelpBox(text: 'این خروجی برای بررسی سریع، ارسال برای اعضا یا نگهداری کنار بکاپ JSON مناسب است. خروجی اصلی انتقال به سرور همچنان از بخش بکاپ/آنلاین‌سازی انجام می‌شود.'),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => Share.share(text, subject: 'خلاصه شجره‌نامه'), icon: const Icon(Icons.ios_share), label: const Text('اشتراک‌گذاری متن')),
          const SizedBox(height: 12),
          PremiumCard(child: SelectableText(text, style: const TextStyle(height: 1.8, color: C.ink))),
        ]),
      ),
    );
  }
}

class PersonFamilyPage extends StatelessWidget {
  final String personId;
  const PersonFamilyPage({super.key, required this.personId});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return AnimatedBuilder(animation: store, builder: (_, __) {
      final p = store.personById(personId);
      if (p == null) return const Scaffold(body: Center(child: Text('شخص پیدا نشد.')));
      final father = store.personById(p.fatherId);
      final mother = store.personById(p.motherId);
      final spouse = store.personById(p.spouseId);
      final children = store.childrenOf(p.id);
      final siblings = store.siblingsOf(p);
      final grandchildren = children.expand((c) => store.childrenOf(c.id)).toList();
      final grandfather = father == null ? null : store.personById(father.fatherId);

      Widget section(String title, List<Person> people, IconData icon) {
        return PremiumCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: C.blue), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 16))]),
            const SizedBox(height: 10),
            if (people.isEmpty) const Text('ثبت نشده', style: TextStyle(color: C.muted)) else Wrap(spacing: 8, runSpacing: 8, children: people.map((x) => ActionChip(label: Text(x.name), onPressed: () => openPerson(context, x))).toList()),
          ]),
        );
      }

      return Scaffold(
        appBar: AppBar(title: Text('خانواده ${p.name}')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          PremiumCard(child: Column(children: [
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)),
            Text(p.code, style: const TextStyle(color: C.muted)),
          ])),
          const SizedBox(height: 12),
          section('والدین', [if (father != null) father, if (mother != null) mother], Icons.group),
          section('همسر', [if (spouse != null) spouse], Icons.favorite),
          section('فرزندان', children, Icons.child_care),
          section('خواهر و برادر', siblings, Icons.diversity_3),
          section('نوه‌ها', grandchildren, Icons.family_restroom),
          section('پدربزرگ', [if (grandfather != null) grandfather], Icons.elderly),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: () => showAddChildSheet(context, p), icon: const Icon(Icons.add), label: const Text('افزودن فرزند')),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(onPressed: () => showEditRelationsSheet(context, p), icon: const Icon(Icons.account_tree), label: const Text('اصلاح رابطه‌ها')),
        ]),
      );
    });
  }
}

class PeopleManagePage extends StatefulWidget {
  const PeopleManagePage({super.key});
  @override
  State<PeopleManagePage> createState() => _PeopleManagePageState();
}

class _PeopleManagePageState extends State<PeopleManagePage> {
  final q = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final people = store.searchPeople(q.text);
    return Scaffold(
      appBar: AppBar(title: const Text('مدیریت افراد و رابطه‌ها')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            const HelpBox(text: 'برای هر شخص می‌توانی پروفایل را ببینی، ویرایش کنی، رابطه‌ها را اصلاح کنی، فرزند اضافه کنی یا شخص را حذف کنی.'),
            const SizedBox(height: 10),
            TextField(controller: q, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'جستجو در افراد')),
          ]),
        ),
        Expanded(
          child: people.isEmpty
              ? const Center(child: Text('شخصی پیدا نشد.'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: people.length,
                  itemBuilder: (_, i) {
                    final p = people[i];
                    return PremiumCard(
                      padding: const EdgeInsets.all(10),
                      child: Row(children: [
                        CircleAvatar(backgroundColor: p.gender == 'زن' ? const Color(0xFFFFEFF4) : C.sky, child: Icon(p.gender == 'زن' ? Icons.female : p.gender == 'مرد' ? Icons.male : Icons.person, color: p.gender == 'زن' ? const Color(0xFFE87095) : C.blue)),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(p.name, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
                          Text('${p.code} • ${p.fatherName.isEmpty ? 'بدون پدر' : 'فرزند ${p.fatherName}'}', style: const TextStyle(color: C.muted, fontSize: 12)),
                        ])),
                        PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'view') openPerson(context, p);
                            if (value == 'edit') push(context, AddPersonPage(editPerson: p));
                            if (value == 'relations') showEditRelationsSheet(context, p);
                            if (value == 'child') showAddChildSheet(context, p);
                            if (value == 'delete') confirmDeletePerson(context, p);
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'view', child: Text('پروفایل')),
                            PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                            PopupMenuItem(value: 'relations', child: Text('اصلاح رابطه‌ها')),
                            PopupMenuItem(value: 'child', child: Text('افزودن فرزند')),
                            PopupMenuItem(value: 'delete', child: Text('حذف')),
                          ],
                        ),
                      ]),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class MembersPage extends StatelessWidget {
  const MembersPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('اعضا و دسترسی')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final tree = store.current;
      if (tree == null) return const Center(child: Text('شجره‌ای وجود ندارد.'));
      return ListView(padding: const EdgeInsets.all(16), children: [
        FilledButton.icon(onPressed: () => showMemberDialog(context), icon: const Icon(Icons.person_add), label: const Text('افزودن عضو/ادمین')),
        const SizedBox(height: 12),
        const SectionTitle(title: 'اعضای تأییدشده'),
        ...tree.members.map((m) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.verified_user, color: C.green), title: Text(m.name), subtitle: Text('${m.role} • ${m.phone}')))),
        const SectionTitle(title: 'درخواست‌های عضویت'),
        FilledButton.tonalIcon(onPressed: () => showRequestDialog(context), icon: const Icon(Icons.add), label: const Text('ثبت درخواست آزمایشی')),
        const SizedBox(height: 8),
        ...tree.requests.map((r) => PremiumCard(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.name, style: const TextStyle(fontWeight: FontWeight.w900)), Text('${r.status} • ${r.phone}', style: const TextStyle(color: C.muted))])), if (r.status == 'در انتظار') TextButton(onPressed: () => store.approveRequest(r), child: const Text('تأیید'))]))),
      ]);
    }));
  }
}

Future<void> showMemberDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final name = TextEditingController();
  final phone = TextEditingController();
  var role = 'عضو';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'افزودن عضو', children: [
    AppField(controller: name, label: 'نام'),
    AppField(controller: phone, label: 'شماره'),
    DropdownButtonFormField<String>(value: role, decoration: const InputDecoration(labelText: 'نقش'), items: const ['ادمین اصلی', 'ادمین شاخه', 'عضو', 'فقط مشاهده'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => role = v ?? 'عضو')),
    FilledButton(onPressed: () async { await store.addMember(name.text, phone.text, role); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

Future<void> showRequestDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final name = TextEditingController();
  final phone = TextEditingController();
  final note = TextEditingController();
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => FormSheet(title: 'درخواست عضویت', children: [
    AppField(controller: name, label: 'نام'),
    AppField(controller: phone, label: 'شماره'),
    AppField(controller: note, label: 'توضیح', maxLines: 3),
    FilledButton(onPressed: () async { await store.addRequest(name.text, phone.text, note.text); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت درخواست')),
  ]));
}

class DuplicatesPage extends StatelessWidget {
  const DuplicatesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('افراد تکراری')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final groups = store.duplicateGroups();
      if (groups.isEmpty) return const Center(child: Text('فرد تکراری پیدا نشد.'));
      return ListView(padding: const EdgeInsets.all(16), children: groups.map((g) => PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('احتمال تکرار: ${g.first.name}', style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), ...g.map((p) => ListTile(title: Text(p.name), subtitle: Text(p.code))), if (g.length >= 2) FilledButton.tonal(onPressed: () => store.mergePersons(g[0], g[1]), child: Text('ادغام ${g[1].code} با ${g[0].code}'))]))).toList());
    }));
  }
}

class ItemsPage extends StatelessWidget {
  const ItemsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('گالری و اسناد')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showItemDialog(context), icon: const Icon(Icons.add), label: const Text('افزودن')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final items = store.current?.items ?? [];
      if (items.isEmpty) return const Center(child: Text('هنوز تصویر یا سندی ثبت نشده است.'));
      return ListView.builder(padding: const EdgeInsets.all(16), itemCount: items.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(leading: Icon(items[i].type == 'سند' ? Icons.description : Icons.photo, color: C.blue), title: Text(items[i].title), subtitle: Text(items[i].description))));
    }));
  }
}

Future<void> showItemDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final desc = TextEditingController();
  var type = 'عکس';
  String personId = '';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'افزودن عکس/سند', children: [
    AppField(controller: title, label: 'عنوان'),
    AppField(controller: desc, label: 'توضیحات', maxLines: 3),
    DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'نوع'), items: const ['عکس', 'سند'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => type = v ?? 'عکس')),
    DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'مرتبط با شخص'), items: (store.current?.people ?? []).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => personId = v ?? ''),
    FilledButton(onPressed: () async { await store.addItem(title.text, desc.text, type, personId); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

class EventsPage extends StatelessWidget {
  const EventsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('مناسبت‌ها و خط زمانی')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showEventDialog(context), icon: const Icon(Icons.add), label: const Text('رویداد')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final events = [...(store.current?.events ?? [])]..sort((a, b) => a.date.compareTo(b.date));
      if (events.isEmpty) return const Center(child: Text('رویدادی ثبت نشده است.'));
      return ListView.builder(padding: const EdgeInsets.all(16), itemCount: events.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(leading: const Icon(Icons.event, color: C.green), title: Text(events[i].title), subtitle: Text('${events[i].type} • ${events[i].date}\n${events[i].notes}'))));
    }));
  }
}

Future<void> showEventDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final date = TextEditingController();
  final notes = TextEditingController();
  var type = 'تولد';
  String personId = '';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'ثبت رویداد', children: [
    AppField(controller: title, label: 'عنوان'),
    AppField(controller: date, label: 'تاریخ', hint: 'مثلاً ۱۳۷۰/۰۲/۱۵'),
    DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'نوع'), items: const ['تولد', 'ازدواج', 'فوت', 'مهاجرت', 'یادبود', 'رویداد'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => type = v ?? 'رویداد')),
    DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'مرتبط با شخص'), items: (store.current?.people ?? []).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => personId = v ?? ''),
    AppField(controller: notes, label: 'توضیحات', maxLines: 3),
    FilledButton(onPressed: () async { await store.addEvent(title.text, date.text, type, notes.text, personId); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final msg = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('چت خانوادگی')), body: Column(children: [
      Expanded(child: AnimatedBuilder(animation: store, builder: (_, __) { final chats = store.current?.chats ?? []; return ListView.builder(padding: const EdgeInsets.all(16), itemCount: chats.length, itemBuilder: (_, i) => Align(alignment: Alignment.centerRight, child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: C.white, borderRadius: BorderRadius.circular(18)), child: Text('${chats[i].sender}: ${chats[i].text}')))); })),
      SafeArea(child: Padding(padding: EdgeInsets.only(left: 12, right: 12, bottom: MediaQuery.of(context).viewInsets.bottom + 8), child: Row(children: [Expanded(child: TextField(controller: msg, decoration: const InputDecoration(labelText: 'پیام'))), const SizedBox(width: 8), IconButton.filled(onPressed: () { if (msg.text.trim().isNotEmpty) { store.addChat('ادمین', msg.text.trim()); msg.clear(); } }, icon: const Icon(Icons.send))]))),
    ]));
  }
}

class PollsPage extends StatelessWidget {
  const PollsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('رأی‌گیری خانوادگی')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showPollDialog(context), icon: const Icon(Icons.add), label: const Text('نظرسنجی')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final polls = store.current?.polls ?? [];
      if (polls.isEmpty) return const Center(child: Text('نظرسنجی ثبت نشده است.'));
      return ListView(padding: const EdgeInsets.all(16), children: polls.map((poll) => PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(poll.question, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 8), ...poll.options.map((o) => ListTile(title: Text(o), trailing: Text('${poll.votes[o] ?? 0} رأی'), onTap: () => store.vote(poll, o)))]))).toList());
    }));
  }
}

Future<void> showPollDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final q = TextEditingController();
  final o1 = TextEditingController();
  final o2 = TextEditingController();
  final o3 = TextEditingController();
  var secret = false;
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'ایجاد رأی‌گیری', children: [
    AppField(controller: q, label: 'سؤال'),
    AppField(controller: o1, label: 'گزینه ۱'),
    AppField(controller: o2, label: 'گزینه ۲'),
    AppField(controller: o3, label: 'گزینه ۳ اختیاری'),
    SwitchListTile(contentPadding: EdgeInsets.zero, value: secret, onChanged: (v) => setModal(() => secret = v), title: const Text('رأی مخفی')),
    FilledButton(onPressed: () async { final opts = [o1.text, o2.text, o3.text].where((e) => e.trim().isNotEmpty).toList(); if (q.text.trim().isNotEmpty && opts.length >= 2) { await store.addPoll(q.text, opts, secret); if (context.mounted) Navigator.pop(context); } }, child: const Text('ثبت')),
  ])));
}


class CsvImportPage extends StatefulWidget {
  const CsvImportPage({super.key});
  @override
  State<CsvImportPage> createState() => _CsvImportPageState();
}

class _CsvImportPageState extends State<CsvImportPage> {
  final raw = TextEditingController();
  final title = TextEditingController(text: 'شجره واردشده از CSV');
  bool createNewTree = false;
  String preview = 'هنوز فایلی انتخاب نشده است.';

  void updatePreview() {
    final rows = parseCsvRows(raw.text);
    if (rows.length < 2) {
      setState(() => preview = 'CSV معتبر نیست یا ردیف اطلاعات ندارد.');
      return;
    }
    final headers = rows.first.join(' | ');
    setState(() => preview = 'ستون‌ها: $headers\nتعداد ردیف‌های قابل بررسی: ${rows.length - 1}');
  }

  Future<void> pickCsvFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv', 'txt']);
    final path = result?.files.single.path;
    if (path == null) return;
    try {
      raw.text = await File(path).readAsString();
      updatePreview();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فایل خوانده نشد. اگر فارسی خراب بود، فایل را با UTF-8 ذخیره کن.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('انتقال شجره از CSV')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const HelpBox(text: 'فایل CSV را از شجره‌ساز قبلی دانلود کن و اینجا وارد کن. اپ قبل از Import یک بکاپ امن داخل گوشی می‌گیرد تا اطلاعات قبلی گم نشود.'),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: pickCsvFile, icon: const Icon(Icons.upload_file), label: const Text('انتخاب فایل CSV از گوشی')),
          const SizedBox(height: 10),
          AppField(controller: raw, label: 'یا متن CSV را اینجا بچسبان', maxLines: 8),
          Row(children: [
            Expanded(child: SwitchListTile(contentPadding: EdgeInsets.zero, value: createNewTree, onChanged: (v) => setState(() => createNewTree = v), title: const Text('ساخت شجره جدید'))),
          ]),
          if (createNewTree) AppField(controller: title, label: 'نام شجره جدید'),
          FilledButton.tonalIcon(onPressed: updatePreview, icon: const Icon(Icons.visibility), label: const Text('پیش‌نمایش CSV')),
          const SizedBox(height: 12),
          PremiumCard(child: Text(preview, style: const TextStyle(height: 1.8, color: C.ink, fontWeight: FontWeight.w700))),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () async {
              final msg = await store.importCsvText(raw.text, createNewTree: createNewTree, newTreeTitle: title.text);
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
            },
            icon: const Icon(Icons.download_done),
            label: const Text('تأیید و وارد کردن CSV'),
          ),
          const SizedBox(height: 12),
          const HelpBox(text: 'ستون‌های قابل تشخیص: نام، نام پدر، نام پدربزرگ، نام مادر، نام همسر، جنسیت، تاریخ تولد، تاریخ فوت، شماره تماس، شهر، شاخه خانوادگی و توضیحات.'),
        ]),
      ),
    );
  }
}


class CsvRepairPage extends StatelessWidget {
  const CsvRepairPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('اصلاح شجره واردشده')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const HelpBox(text: 'اگر قبلاً CSV را وارد کردی و همه افراد یک‌ردیف شدند، این بخش تلاش می‌کند رابطه‌ها را با نام پدر، نام پدربزرگ و همسر بازسازی کند. برای فایل‌های دارای شناسه، بهتر است CSV را دوباره از صفحه انتقال CSV وارد کنی.'),
          const SizedBox(height: 12),
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('وضعیت فعلی', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: C.ink)),
            const SizedBox(height: 8),
            PreviewLine(label: 'افراد', value: '${store.current?.people.length ?? 0}'),
            PreviewLine(label: 'روابط ناقص', value: '${store.migrationStats()['missingFatherLinks'] ?? 0}'),
          ])),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () async {
              final tree = store.current;
              if (tree == null) return;
              await store.createSafetySnapshot(reason: 'before-repair');
              final linked = store.rebuildRelationshipsByNames(tree);
              final deduped = store.dedupeSmart(tree);
              tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'اصلاح خودکار شجره واردشده: $linked رابطه بازسازی شد، $deduped تکراری ادغام شد', actor: 'سیستم'));
              await store.save();
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$linked رابطه بازسازی شد و $deduped تکراری ادغام شد.')));
            },
            icon: const Icon(Icons.auto_fix_high),
            label: const Text('اصلاح خودکار روابط'),
          ),
          const SizedBox(height: 10),
          FilledButton.tonalIcon(
            onPressed: () => push(context, const CsvImportPage()),
            icon: const Icon(Icons.table_chart),
            label: const Text('وارد کردن دوباره CSV ساختاری'),
          ),
        ]),
      ),
    );
  }
}


class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController admin;
  late TextEditingController pin;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final store = StoreProvider.of(context);
    admin = TextEditingController(text: store.adminDisplayName);
    pin = TextEditingController(text: store.appPin);
  }

  Future<void> saveSettings() async {
    final store = StoreProvider.of(context);
    await store.updateSettings(adminName: admin.text, pin: pin.text.trim());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تنظیمات ذخیره شد.')));
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات و امنیت')),
      body: AnimatedBuilder(animation: store, builder: (_, __) => ListView(padding: const EdgeInsets.all(16), children: [
        const HelpBox(text: 'تنظیمات این صفحه فقط محلی است و همراه بکاپ JSON ذخیره می‌شود.'),
        const SizedBox(height: 12),
        PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('مشخصات و نمایش', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 18)),
          const SizedBox(height: 10),
          AppField(controller: admin, label: 'نام ادمین/کاربر'),
          SwitchListTile(value: store.showHelp, onChanged: (v) => store.updateSettings(help: v), title: const Text('نمایش راهنماهای داخل صفحه')),
          SwitchListTile(value: store.protectPhones, onChanged: (v) => store.updateSettings(phones: v), title: const Text('مخفی کردن شماره‌ها به صورت پیش‌فرض')),
          const SizedBox(height: 8),
          Text('اندازه کارت‌های شجره: ${(store.treeCardScale * 100).round()}٪', style: const TextStyle(fontWeight: FontWeight.w800, color: C.ink)),
          Slider(value: store.treeCardScale, min: .8, max: 1.35, divisions: 11, label: '${(store.treeCardScale * 100).round()}٪', onChanged: (v) => store.updateSettings(cardScale: v)),
          FilledButton.icon(onPressed: saveSettings, icon: const Icon(Icons.save), label: const Text('ذخیره تنظیمات')),
        ])),
        const SizedBox(height: 12),
        PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('قفل امنیتی محلی', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 18)),
          const SizedBox(height: 8),
          const Text('رمز داخل خود گوشی ذخیره می‌شود. قبل از فعال کردن قفل، بکاپ JSON بگیر.', style: TextStyle(color: C.muted, height: 1.6)),
          const SizedBox(height: 10),
          AppField(controller: pin, label: 'رمز ۴ یا ۶ رقمی', keyboard: TextInputType.number),
          SwitchListTile(value: store.appLockEnabled, onChanged: (v) async {
            if (v && pin.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اول رمز را وارد کن.')));
              return;
            }
            await store.updateSettings(lock: v, pin: pin.text.trim());
          }, title: const Text('فعال‌سازی قفل ورود اپ')),
          Row(children: [
            Expanded(child: FilledButton.tonalIcon(onPressed: saveSettings, icon: const Icon(Icons.lock), label: const Text('ذخیره رمز'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: () => store.updateSettings(lock: false, pin: ''), icon: const Icon(Icons.lock_open), label: const Text('حذف قفل'))),
          ]),
        ])),
        const SizedBox(height: 12),
        QuickSectionCard(
          title: 'داده‌ها و انتقال',
          subtitle: 'CSV، بکاپ و آماده‌سازی آنلاین به بخش تنظیمات/داده منتقل شدند.',
          children: [
            QuickMiniButton(title: 'انتقال CSV', icon: Icons.table_chart_rounded, color: C.green, onTap: () => push(context, const CsvImportPage())),
            QuickMiniButton(title: 'اصلاح واردشده', icon: Icons.account_tree_rounded, color: C.blue, onTap: () => push(context, const CsvRepairPage())),
            QuickMiniButton(title: 'بکاپ فایل', icon: Icons.backup, color: C.gold, onTap: () => push(context, const BackupPage())),
          ],
        ),
        const SizedBox(height: 12),
        PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('پاک‌سازی حساس', style: TextStyle(fontWeight: FontWeight.w900, color: C.red, fontSize: 18)),
          const SizedBox(height: 8),
          const Text('قبل از پاک‌سازی، اپ یک بکاپ امن داخلی می‌گیرد. با این حال بهتر است اول بکاپ فایل JSON هم بسازی.', style: TextStyle(color: C.muted, height: 1.6)),
          OutlinedButton.icon(onPressed: () => confirmClearAll(context), icon: const Icon(Icons.delete_forever), label: const Text('پاک‌سازی همه اطلاعات محلی')),
        ])),
      ])),
    );
  }
}

Future<void> confirmClearAll(BuildContext context) async {
  final store = StoreProvider.of(context);
  final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
    title: const Text('پاک‌سازی اطلاعات'),
    content: const Text('همه شجره‌ها و اطلاعات محلی پاک شود؟ قبل از این کار بهتر است بکاپ فایل JSON گرفته باشی.'),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
      FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('پاک‌سازی')),
    ],
  ));
  if (ok != true) return;
  final msg = await store.clearAllLocalData();
  if (context.mounted) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  final raw = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final stats = store.migrationStats();
    return Scaffold(
      appBar: AppBar(title: const Text('بکاپ فایل و بازیابی')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const HelpBox(text: 'اگر برنامه را حذف کنی، دیتای داخلی اندروید پاک می‌شود. برای ماندن اطلاعات، حتماً بکاپ فایل JSON بگیر و بعداً از همین فایل بازیابی کن.'),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            Chip(label: Text('شجره‌ها: ${stats['trees']}')),
            Chip(label: Text('افراد: ${stats['people']}')),
            Chip(label: Text('لاگ‌ها: ${stats['logs']}')),
            Chip(label: Text('رویدادها: ${stats['events']}')),
          ]),
          const SizedBox(height: 12),
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('بکاپ واقعی فایل', style: TextStyle(fontWeight: FontWeight.w900, color: C.ink, fontSize: 18)),
            const SizedBox(height: 8),
            Text(store.lastBackupAt.isEmpty ? 'آخرین بکاپ فایل: ثبت نشده' : 'آخرین بکاپ فایل: ${shortDate(store.lastBackupAt)}', style: const TextStyle(color: C.muted)),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: () async {
              final msg = await store.saveBackupToDownloads();
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
            }, icon: const Icon(Icons.file_download_done), label: const Text('ساخت فایل بکاپ در Downloads')),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(onPressed: () async {
              final msg = await store.restoreBackupFromFilePicker();
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
            }, icon: const Icon(Icons.folder_open), label: const Text('بازیابی از فایل JSON')),
          ])),
          const SizedBox(height: 12),
          QuickSectionCard(
            title: 'خروجی و انتقال',
            subtitle: 'خروجی متنی شجره از صفحه امکانات منتقل شد و کنار بکاپ قرار گرفت.',
            children: [
              QuickMiniButton(title: 'خروجی متنی', icon: Icons.article_rounded, color: C.gold, onTap: () => push(context, const TextExportPage())),
              QuickMiniButton(title: 'آماده آنلاین‌سازی', icon: Icons.cloud_upload_rounded, color: C.blue, onTap: () => push(context, const OnlinePrepPage())),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () async {
            final msg = await store.createSafetySnapshot(reason: 'manual');
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
          }, icon: const Icon(Icons.save), label: const Text('ذخیره بکاپ امن داخلی')),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: () => Share.share(store.backupJson(), subject: 'پشتیبان نسب‌نامه'), icon: const Icon(Icons.ios_share), label: const Text('اشتراک‌گذاری متن JSON')),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(onPressed: () async {
            final msg = await store.restoreSafetySnapshot();
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
          }, icon: const Icon(Icons.restore), label: const Text('بازیابی آخرین بکاپ امن داخلی')),
          const SizedBox(height: 16),
          AppField(controller: raw, label: 'متن بکاپ JSON را اینجا بچسبان', maxLines: 8),
          FilledButton.tonal(onPressed: () async {
            final msg = await store.importBackup(raw.text);
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
          }, child: const Text('بازیابی از متن JSON')),
        ]),
      ),
    );
  }
}

class OnlinePrepPage extends StatelessWidget {
  const OnlinePrepPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final stats = store.migrationStats();
    final warnings = store.onlineReadinessWarnings();
    return Scaffold(
      appBar: AppBar(title: const Text('آماده‌سازی آنلاین‌سازی')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const HelpBox(text: 'این بخش فعلاً به سرور وصل نیست. فقط اطلاعات را بررسی و یک بسته آماده انتقال می‌سازد تا بعداً با بک‌اند PHP/MySQL آنلاین شود.'),
          const SizedBox(height: 12),
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('آمار بسته انتقال', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: C.ink)),
            const SizedBox(height: 10),
            PreviewLine(label: 'شجره‌ها', value: '${stats['trees']}'),
            PreviewLine(label: 'افراد', value: '${stats['people']}'),
            PreviewLine(label: 'اسناد/عکس‌ها', value: '${stats['items']}'),
            PreviewLine(label: 'رویدادها', value: '${stats['events']}'),
            PreviewLine(label: 'روابط ناقص', value: '${(stats['missingFatherLinks'] ?? 0) + (stats['missingSpouseBackLinks'] ?? 0)}'),
          ])),
          const SizedBox(height: 12),
          ...warnings.map((w) => PremiumCard(padding: const EdgeInsets.all(12), child: Row(children: [Icon(w.contains('آماده') ? Icons.check_circle : Icons.info, color: w.contains('آماده') ? C.green : C.gold), const SizedBox(width: 8), Expanded(child: Text(w, style: const TextStyle(color: C.ink, height: 1.6)))]))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => Share.share(store.onlineMigrationJson(), subject: 'بسته انتقال آنلاین نسب‌نامه'), icon: const Icon(Icons.cloud_upload), label: const Text('ساخت و اشتراک بسته انتقال آنلاین')),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(onPressed: () async {
            final msg = await store.createSafetySnapshot(reason: 'before-online-migration');
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
          }, icon: const Icon(Icons.security), label: const Text('بکاپ قبل از آنلاین‌سازی')),
        ]),
      ),
    );
  }
}

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});
  @override
  Widget build(BuildContext context) {
    final tips = [
      'برای شروع، از صفحه خانه یک شجره بساز.',
      'برای ثبت سریع، از «افزودن خانواده کامل» استفاده کن و پدر، همسر، پسران و دختران را یک‌جا وارد کن.',
      'برای جایگذاری خودکار، نام شخص، نام پدر و نام پدربزرگ را وارد کن.',
      'اگر پدر یا پدربزرگ در شجره نباشند، اپ آن‌ها را خودکار به‌عنوان شاخه جدید می‌سازد.',
      'از صفحه جستجو می‌توانی با نام، نام پدر، پدربزرگ، کد شخص، شهر یا شماره جستجو کنی.',
      'در صفحه هر شخص، فرزندان، خواهر/برادر و نسبت با افراد دیگر نمایش داده می‌شود.',
      'برای دعوت، دکمه اشتراک را بزن؛ متن دعوت، لینک و کد دعوت آماده می‌شود و خودت واتساپ، تلگرام یا پیامک را انتخاب می‌کنی.',
      'برای امنیت، شماره تماس به‌صورت پیش‌فرض خصوصی است.',
      'قبل از اتصال بک‌اند، از بخش بکاپ خروجی JSON بگیر.',
    ];
    return Scaffold(appBar: AppBar(title: const Text('راهنمای کامل')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: tips.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(backgroundColor: C.sky, child: Text('${i + 1}', style: const TextStyle(color: C.blue, fontWeight: FontWeight.w900))), const SizedBox(width: 10), Expanded(child: Text(tips[i], style: const TextStyle(height: 1.8, color: C.ink)))]))));
  }
}
