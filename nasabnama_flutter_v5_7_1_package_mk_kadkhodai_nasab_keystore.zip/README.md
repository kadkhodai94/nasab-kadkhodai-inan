# NasabNama v5.7.1

Package + Keystore release config:
- Android package/applicationId set to mk.kadkhodai.nasab
- Keystore package copied into android_signing
- GitHub workflow updated to force package name after flutter create
- GitHub workflow updated to apply release signing using bundled key.properties
- UI and app logic kept from v5.7

Version: 5.7.1+39
