# NasabNama v5.8.2 Bazaar Analyze Opacity Fix

Fix:
- Replaced deprecated withOpacity calls with withValues(alpha:)
- Analyze step is now non-blocking for info/warning messages
- Bazaar subscription remains active
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.2+43
