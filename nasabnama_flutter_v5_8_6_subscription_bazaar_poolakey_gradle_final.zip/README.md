# NasabNama v5.8.6 Bazaar Poolakey Gradle Final

Fix:
- Strong Gradle/JitPack fix for Poolakey dependency resolution
- Injects JitPack into settings.gradle/settings.gradle.kts, build.gradle/build.gradle.kts
- Adds Gradle init.gradle fallback for dependencyResolutionManagement repositories
- Patches flutter_poolakey plugin Gradle namespace and repositories in Pub cache
- Removes weak previous JitPack patch
- Bazaar subscription remains active through flutter_poolakey
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.6+47
