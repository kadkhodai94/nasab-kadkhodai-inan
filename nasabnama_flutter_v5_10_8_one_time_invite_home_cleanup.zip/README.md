# NasabNama v5.10.8 One-time Invite + Home Cleanup

Base:
- v5.10.7 Local Auth Access

Changes:
- Moves Home icon to the center of bottom navigation
- Reorders bottom navigation:
  - Tree
  - Add
  - Home
  - Search
  - More
- Home page opens on the center Home tab by default
- Makes Home page action cards horizontal and scrollable
- Makes Home page cleaner and less crowded
- Simplifies registration page:
  - username
  - password
- Removes display name from registration UI
- Removes repeat-password from registration UI
- Keeps invite code separate from registration
- Adds one-time invite codes
- Adds invite creation with access level:
  - view
  - edit
  - admin
- Adds invite redemption screen
- Consumes invite after first use
- Prevents second user from using the same invite code
- Shows recent invite codes and used/unused status in access management page
- Updates share invite to create a one-time invite code
- Keeps access permission checks
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.8+64
