# NasabNama v5.10.11 Tree Layout Children Fix

Base:
- v5.10.10 No Auto Detect / Manual Links

Fixes:
- Children in lower generations are now rendered in a fixed visible child row
- Child row gets enough height so cards are not clipped under connector lines
- Board height is calculated with ancestor column + family card + connector + child cards
- Upper generations / ancestors are shown as one centered vertical column
- Ancestors no longer wrap into a second row or second column
- Initial zoom considers board width and height so lower children are easier to see
- Tree rendering still uses direct fatherId / motherId / spouseId only
- No automatic name detection is restored
- No fuzzy name matching is restored in the tree renderer
- autoPlace remains disabled
- dedupeSmart remains disabled
- Keeps main card UI style unchanged
- Keeps one-time invite system
- Keeps local auth/access system
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.11+67
