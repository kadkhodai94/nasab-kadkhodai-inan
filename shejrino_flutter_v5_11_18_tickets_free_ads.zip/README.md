# Shejrino v5.11.18+86

Flutter source for GitHub Actions build.

Changes:
- Added in-app support tickets.
- Added admin ticket management from the admin panel.
- Added Adivery ads for free users only.
- Users with active subscriptions do not load or see banner, native, interstitial, or exit-dialog ads.
- The family tree page remains ad-free.

Build:
Upload this ZIP to the GitHub repository root and run the existing workflow.
