import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() => runApp(const NasabNamaApp());

const _uuid = Uuid();

class Person {
  String id;
  String code;
  String fullName;
  String fatherName;
  String grandfatherName;
  String? fatherId;
  String? motherId;
  List<String> spouseIds;
  String phone;
  String branch;
  String birthPlace;
  String birthYear;
  String notes;
  DateTime createdAt;

  Person({
    required this.id,
    required this.code,
    required this.fullName,
    required this.fatherName,
    required this.grandfatherName,
    this.fatherId,
    this.motherId,
    List<String>? spouseIds,
    this.phone = '',
    this.branch = '',
    this.birthPlace = '',
    this.birthYear = '',
    this.notes = '',
    DateTime? createdAt,
  })  : spouseIds = spouseIds ?? [],
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'fullName': fullName,
        'fatherName': fatherName,
        'grandfatherName': grandfatherName,
        'fatherId': fatherId,
        'motherId': motherId,
        'spouseIds': spouseIds,
        'phone': phone,
        'branch': branch,
        'birthPlace': birthPlace,
        'birthYear': birthYear,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Person.fromJson(Map<String, dynamic> j) => Person(
        id: j['id'],
        code: j['code'],
        fullName: j['fullName'],
        fatherName: j['fatherName'] ?? '',
        grandfatherName: j['grandfatherName'] ?? '',
        fatherId: j['fatherId'],
        motherId: j['motherId'],
        spouseIds: List<String>.from(j['spouseIds'] ?? []),
        phone: j['phone'] ?? '',
        branch: j['branch'] ?? '',
        birthPlace: j['birthPlace'] ?? '',
        birthYear: j['birthYear'] ?? '',
        notes: j['notes'] ?? '',
        createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
      );
}

class TreeMember {
  String id;
  String name;
  String phone;
  String role;
  bool approved;
  DateTime createdAt;
  TreeMember({required this.id, required this.name, this.phone = '', this.role = 'viewer', this.approved = false, DateTime? createdAt}) : createdAt = createdAt ?? DateTime.now();
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'role': role, 'approved': approved, 'createdAt': createdAt.toIso8601String()};
  factory TreeMember.fromJson(Map<String, dynamic> j) => TreeMember(id: j['id'], name: j['name'], phone: j['phone'] ?? '', role: j['role'] ?? 'viewer', approved: j['approved'] ?? false, createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now());
}

class JoinRequest {
  String id;
  String name;
  String phone;
  String relationHint;
  DateTime createdAt;
  JoinRequest({required this.id, required this.name, this.phone = '', this.relationHint = '', DateTime? createdAt}) : createdAt = createdAt ?? DateTime.now();
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'relationHint': relationHint, 'createdAt': createdAt.toIso8601String()};
  factory JoinRequest.fromJson(Map<String, dynamic> j) => JoinRequest(id: j['id'], name: j['name'], phone: j['phone'] ?? '', relationHint: j['relationHint'] ?? '', createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now());
}

class FamilyTree {
  String id;
  String title;
  String clan;
  String ownerName;
  List<Person> people;
  List<TreeMember> members;
  List<JoinRequest> requests;
  List<String> smsLog;
  FamilyTree({required this.id, required this.title, this.clan = '', required this.ownerName, List<Person>? people, List<TreeMember>? members, List<JoinRequest>? requests, List<String>? smsLog})
      : people = people ?? [], members = members ?? [], requests = requests ?? [], smsLog = smsLog ?? [];
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'clan': clan, 'ownerName': ownerName, 'people': people.map((e) => e.toJson()).toList(), 'members': members.map((e) => e.toJson()).toList(), 'requests': requests.map((e) => e.toJson()).toList(), 'smsLog': smsLog};
  factory FamilyTree.fromJson(Map<String, dynamic> j) => FamilyTree(id: j['id'], title: j['title'], clan: j['clan'] ?? '', ownerName: j['ownerName'] ?? '', people: (j['people'] as List? ?? []).map((e) => Person.fromJson(Map<String, dynamic>.from(e))).toList(), members: (j['members'] as List? ?? []).map((e) => TreeMember.fromJson(Map<String, dynamic>.from(e))).toList(), requests: (j['requests'] as List? ?? []).map((e) => JoinRequest.fromJson(Map<String, dynamic>.from(e))).toList(), smsLog: List<String>.from(j['smsLog'] ?? []));
}

class AppStore extends ChangeNotifier {
  List<FamilyTree> trees = [];
  int selectedIndex = 0;
  FamilyTree? get current => trees.isEmpty ? null : trees[min(selectedIndex, trees.length - 1)];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('trees_v1');
    if (raw == null) {
      _seed();
    } else {
      trees = (jsonDecode(raw) as List).map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('trees_v1', jsonEncode(trees.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void _seed() {
    final tree = FamilyTree(id: _uuid.v4(), title: 'شجره‌نامه نمونه', clan: 'خانواده اصلی', ownerName: 'ادمین');
    final grand = Person(id: _uuid.v4(), code: 'FAM-000001', fullName: 'رحمان محمدی', fatherName: '', grandfatherName: '', branch: 'شاخه اصلی');
    final father = Person(id: _uuid.v4(), code: 'FAM-000002', fullName: 'کاوه رحمانی', fatherName: 'رحمان', grandfatherName: '', fatherId: grand.id, branch: 'شاخه اصلی');
    final child = Person(id: _uuid.v4(), code: 'FAM-000003', fullName: 'آراس کاوهی', fatherName: 'کاوه', grandfatherName: 'رحمان', fatherId: father.id, branch: 'شاخه اصلی', phone: '09xxxxxxxxx');
    tree.people.addAll([grand, father, child]);
    tree.members.add(TreeMember(id: _uuid.v4(), name: 'ادمین اصلی', role: 'owner', approved: true));
    trees = [tree];
    save();
  }

  String nextCode(FamilyTree t) => 'FAM-${(t.people.length + 1).toString().padLeft(6, '0')}';

  Future<String> addPersonSmart(Person p) async {
    final t = current!;
    final normalizedFather = norm(p.fatherName);
    final normalizedGrand = norm(p.grandfatherName);
    Person? father;
    if (normalizedFather.isNotEmpty) {
      final candidates = t.people.where((x) => norm(x.fullName).contains(normalizedFather) || norm(x.fullName.split(' ').first) == normalizedFather).toList();
      for (final c in candidates) {
        final parent = c.fatherId == null ? null : t.people.where((z) => z.id == c.fatherId).cast<Person?>().firstOrNull;
        if (normalizedGrand.isEmpty || norm(c.fatherName) == normalizedGrand || (parent != null && norm(parent.fullName).contains(normalizedGrand))) {
          father = c;
          break;
        }
      }
    }
    var message = 'شخص افزوده شد، اما جایگاه دقیق نیازمند بررسی ادمین است.';
    if (father != null) {
      p.fatherId = father.id;
      p.branch = p.branch.isEmpty ? father.branch : p.branch;
      message = 'جایگاه خودکار پیدا شد: ${p.fullName} زیرمجموعه ${father.fullName} ثبت شد.';
    } else if (normalizedFather.isNotEmpty) {
      final grand = t.people.where((x) => norm(x.fullName).contains(normalizedGrand) || norm(x.fullName.split(' ').first) == normalizedGrand).firstOrNull;
      if (grand != null) {
        father = Person(id: _uuid.v4(), code: nextCode(t), fullName: p.fatherName, fatherName: p.grandfatherName, grandfatherName: '', fatherId: grand.id, branch: grand.branch);
        t.people.add(father);
        p.fatherId = father.id;
        p.branch = p.branch.isEmpty ? father.branch : p.branch;
        message = 'پدر ساخته شد و شخص در جایگاه پیشنهادی زیر ${father.fullName} قرار گرفت.';
      }
    }
    t.people.add(p);
    await save();
    if (p.phone.trim().isNotEmpty) inviteSms(p);
    return message;
  }

  void inviteSms(Person p) {
    final t = current!;
    final msg = 'پیامک به ${p.phone}: شما به عنوان عضوی از شجره‌نامه ${t.title} ثبت شده‌اید. برای تکمیل اطلاعات خانواده وارد اپ نسب‌نامه شوید. کد شما: ${p.code}';
    t.smsLog.insert(0, msg);
    save();
  }

  Future<File> exportZip() async {
    final t = current!;
    final archive = Archive();
    final jsonBytes = utf8.encode(const JsonEncoder.withIndent('  ').convert(t.toJson()));
    archive.addFile(ArchiveFile('nasabnama_${t.id}.json', jsonBytes.length, jsonBytes));
    final encoder = ZipEncoder();
    final bytes = encoder.encode(archive)!;
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/nasabnama_${DateTime.now().millisecondsSinceEpoch}.zip');
    await f.writeAsBytes(bytes);
    return f;
  }

  Future<void> importBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip', 'json']);
    if (result == null || result.files.single.path == null) return;
    final file = File(result.files.single.path!);
    String raw;
    if (file.path.endsWith('.zip')) {
      final archive = ZipDecoder().decodeBytes(await file.readAsBytes());
      final jsonFile = archive.files.firstWhere((f) => f.name.endsWith('.json'));
      raw = utf8.decode(jsonFile.content as List<int>);
    } else {
      raw = await file.readAsString();
    }
    final tree = FamilyTree.fromJson(Map<String, dynamic>.from(jsonDecode(raw)));
    trees.add(tree);
    selectedIndex = trees.length - 1;
    await save();
  }
}

String norm(String v) => v.trim().replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll(RegExp(r'\s+'), ' ').toLowerCase();

extension FirstOrNull<T> on Iterable<T> { T? get firstOrNull => isEmpty ? null : first; }

class NasabNamaApp extends StatefulWidget { const NasabNamaApp({super.key}); @override State<NasabNamaApp> createState() => _NasabNamaAppState(); }
class _NasabNamaAppState extends State<NasabNamaApp> {
  final store = AppStore();
  @override void initState() { super.initState(); store.load(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'نسب‌نامه',
    theme: ThemeData(fontFamily: 'sans', useMaterial3: true, colorSchemeSeed: const Color(0xff6d5dfc), scaffoldBackgroundColor: const Color(0xfff6f4ff)),
    home: Directionality(textDirection: TextDirection.rtl, child: HomePage(store: store)),
  ));
}

class HomePage extends StatefulWidget { final AppStore store; const HomePage({super.key, required this.store}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab = 0;
  @override Widget build(BuildContext context) {
    final s = widget.store;
    final t = s.current;
    final pages = [Dashboard(store: s), TreeViewPage(store: s), SearchPage(store: s), AdminPage(store: s), GuidePage()];
    return Scaffold(
      body: t == null ? Center(child: ElevatedButton(onPressed: () => createTree(context), child: const Text('ساخت اولین شجره‌نامه'))) : pages[tab],
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_rounded), label: 'خانه'),
        NavigationDestination(icon: Icon(Icons.account_tree_rounded), label: 'درخت'),
        NavigationDestination(icon: Icon(Icons.search_rounded), label: 'جستجو'),
        NavigationDestination(icon: Icon(Icons.admin_panel_settings_rounded), label: 'مدیریت'),
        NavigationDestination(icon: Icon(Icons.help_rounded), label: 'راهنما'),
      ]),
      floatingActionButton: tab == 0 || tab == 1 ? FloatingActionButton.extended(onPressed: () => addPerson(context), icon: const Icon(Icons.person_add_alt_1), label: const Text('افزودن شخص')) : null,
    );
  }
  void createTree(BuildContext context) { showTreeDialog(context, widget.store); }
  void addPerson(BuildContext context) { showPersonDialog(context, widget.store); }
}

class Dashboard extends StatelessWidget { final AppStore store; const Dashboard({super.key, required this.store}); @override Widget build(BuildContext context) { final t=store.current!; return SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
  Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('نسب‌نامه', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)), Text(t.title, style: const TextStyle(color: Colors.black54))])), IconButton(onPressed: () => showTreeDialog(context, store), icon: const Icon(Icons.add_circle_outline))]),
  const SizedBox(height: 16),
  Container(padding: const EdgeInsets.all(18), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('داشبورد شجره', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)), const SizedBox(height: 12), Wrap(spacing: 10, runSpacing: 10, children: [stat('افراد', t.people.length), stat('اعضا', t.members.length), stat('درخواست‌ها', t.requests.length), stat('پیامک‌ها', t.smsLog.length)]), const SizedBox(height: 12), Text('ادمین اصلی: ${t.ownerName}  |  طایفه/شاخه: ${t.clan}') ])),
  const SizedBox(height: 14),
  Row(children: [Expanded(child: action(context, Icons.person_add, 'افزودن هوشمند', () => showPersonDialog(context, store))), const SizedBox(width: 10), Expanded(child: action(context, Icons.ios_share, 'خروجی ZIP', () async { final f=await store.exportZip(); Share.shareXFiles([XFile(f.path)], text: 'خروجی شجره‌نامه ${t.title}'); }))]),
  const SizedBox(height: 10),
  Row(children: [Expanded(child: action(context, Icons.folder_zip, 'خواندن ZIP/JSON', () => store.importBackup())), const SizedBox(width: 10), Expanded(child: action(context, Icons.sms, 'لاگ دعوت‌ها', () => showList(context, 'پیامک‌های دعوت', t.smsLog)))]),
  const SizedBox(height: 18),
  const Text('آخرین افراد ثبت‌شده', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
  ...t.people.reversed.take(5).map((p) => personTile(context, store, p)),
])); }}

Widget stat(String title, int value) => Container(width: 94, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xffeeeaff), borderRadius: BorderRadius.circular(18)), child: Column(children: [Text('$value', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22)), Text(title, style: const TextStyle(fontSize: 12))]));
Widget action(BuildContext c, IconData icon, String title, VoidCallback cb) => InkWell(onTap: cb, borderRadius: BorderRadius.circular(20), child: Container(padding: const EdgeInsets.all(14), decoration: box(), child: Column(children: [Icon(icon, size: 30, color: const Color(0xff6d5dfc)), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))])));
BoxDecoration box() => BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 20, offset: const Offset(0, 10))]);

class TreeViewPage extends StatelessWidget { final AppStore store; const TreeViewPage({super.key, required this.store}); @override Widget build(BuildContext context) { final t=store.current!; final roots=t.people.where((p)=>p.fatherId==null).toList(); return SafeArea(child: Column(children: [header('نمای شجره', 'زوم و اسکرول برای دیدن شاخه‌ها'), Expanded(child: InteractiveViewer(minScale: .35, maxScale: 2.5, boundaryMargin: const EdgeInsets.all(500), child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: SingleChildScrollView(child: Padding(padding: const EdgeInsets.all(24), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: roots.map((r)=>treeNode(context,t,r)).toList()))))))])); }
  Widget treeNode(BuildContext context, FamilyTree t, Person p) { final children=t.people.where((x)=>x.fatherId==p.id).toList(); return Container(margin: const EdgeInsets.all(8), child: Column(children: [Container(width: 170, padding: const EdgeInsets.all(12), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xff6d5dfc), Color(0xff9c6bff)]), borderRadius: BorderRadius.circular(18)), child: Column(children: [const Icon(Icons.person, color: Colors.white), Text(p.fullName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold), textAlign: TextAlign.center), Text(p.code, style: const TextStyle(color: Colors.white70, fontSize: 11))])), if(children.isNotEmpty) Container(width: 2, height: 22, color: const Color(0xff6d5dfc)), if(children.isNotEmpty) Row(crossAxisAlignment: CrossAxisAlignment.start, children: children.map((c)=>treeNode(context,t,c)).toList())])); }
}

class SearchPage extends StatefulWidget { final AppStore store; const SearchPage({super.key, required this.store}); @override State<SearchPage> createState()=>_SearchPageState(); }
class _SearchPageState extends State<SearchPage> { String q=''; @override Widget build(BuildContext context) { final t=widget.store.current!; final res=t.people.where((p){ final x=norm('${p.fullName} ${p.fatherName} ${p.grandfatherName} ${p.code} ${p.phone}'); return norm(q).isEmpty || x.contains(norm(q)); }).toList(); return SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [header('جستجوی شجره', 'نام، نام پدر، پدربزرگ، کد یا شماره را بنویس'), TextField(decoration: input('جستجو...'), onChanged: (v)=>setState(()=>q=v)), const SizedBox(height: 12), ...res.map((p)=>personTile(context, widget.store, p))])); }}

class AdminPage extends StatelessWidget { final AppStore store; const AdminPage({super.key, required this.store}); @override Widget build(BuildContext context) { final t=store.current!; return SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [header('مدیریت و امنیت', 'دسترسی فقط بعد از تأیید ادمین'), action(context, Icons.group_add, 'افزودن عضو/ادمین', ()=>showMemberDialog(context, store)), const SizedBox(height: 12), action(context, Icons.how_to_reg, 'ثبت درخواست عضویت تستی', ()=>showRequestDialog(context, store)), const SizedBox(height: 18), const Text('درخواست‌های در انتظار تأیید', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), ...t.requests.map((r)=>Container(margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14), decoration: box(), child: Row(children: [Expanded(child: Text('${r.name}\n${r.phone}\n${r.relationHint}')), ElevatedButton(onPressed: () { t.members.add(TreeMember(id: _uuid.v4(), name: r.name, phone: r.phone, role: 'member', approved: true)); t.requests.remove(r); store.save(); }, child: const Text('تأیید'))]))), const SizedBox(height: 18), const Text('اعضا و نقش‌ها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), ...t.members.map((m)=>ListTile(title: Text(m.name), subtitle: Text('${m.role} | ${m.approved ? 'تأیید شده' : 'در انتظار'}'), leading: const CircleAvatar(child: Icon(Icons.verified_user)))), const SizedBox(height: 18), const Text('لاگ دعوت پیامکی', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), ...t.smsLog.take(10).map((e)=>Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(12), decoration: box(), child: Text(e))), ])); }}

class GuidePage extends StatelessWidget { @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [header('راهنمای اپ', 'برای اینکه کاربر گیج نشود'), guide('ثبت‌نام و امنیت', 'ابتدا درخواست عضویت ارسال می‌شود. فقط بعد از تأیید ادمین امکان دیدن شجره وجود دارد.'), guide('تشخیص جایگاه خودکار', 'نام شخص، نام پدر و نام پدربزرگ وارد می‌شود. اپ پدر را پیدا می‌کند و شخص را در جای مناسب می‌گذارد. اگر مطمئن نبود، نیاز به بررسی ادمین دارد.'), guide('جستجو', 'با نام، نام پدر، پدربزرگ، کد اختصاصی یا شماره می‌توان شخص را پیدا کرد.'), guide('دعوت پیامکی', 'وقتی شماره شخص ثبت شود، متن دعوت آماده و در لاگ ثبت می‌شود. برای ارسال واقعی باید API پنل پیامک وصل شود.'), guide('خروجی', 'خروجی ZIP شامل JSON کامل شجره است. همین فایل دوباره قابل خواندن است.'), guide('نقش‌ها', 'Owner، Admin، Branch Manager، Member و Viewer برای کنترل دسترسی استفاده می‌شود.') ])); }
Widget guide(String t, String d)=>Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16), decoration: box(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), const SizedBox(height: 6), Text(d)]));

Widget header(String title, String sub)=>Padding(padding: const EdgeInsets.only(bottom: 16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 26)), Text(sub, style: const TextStyle(color: Colors.black54))]));
InputDecoration input(String label)=>InputDecoration(labelText: label, filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none));
Widget personTile(BuildContext context, AppStore store, Person p)=>Container(margin: const EdgeInsets.only(top: 10), decoration: box(), child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xffeeeaff), child: Text(p.fullName.isEmpty?'؟':p.fullName.characters.first)), title: Text(p.fullName, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('کد: ${p.code} | پدر: ${p.fatherName.isEmpty ? '-' : p.fatherName} | پدربزرگ: ${p.grandfatherName.isEmpty ? '-' : p.grandfatherName}'), trailing: const Icon(Icons.chevron_left), onTap: ()=>showPersonInfo(context, store, p)));

void showPersonInfo(BuildContext context, AppStore store, Person p) { final t=store.current!; final father=p.fatherId==null?null:t.people.where((x)=>x.id==p.fatherId).firstOrNull; final children=t.people.where((x)=>x.fatherId==p.id).toList(); showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.all(20), child: Wrap(runSpacing: 10, children: [Center(child: Container(width: 50, height: 5, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(99)))), ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(p.fullName, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(p.code)), Text('پدر: ${father?.fullName ?? p.fatherName}'), Text('پدربزرگ: ${p.grandfatherName}'), Text('شاخه: ${p.branch}'), Text('محل تولد/زندگی: ${p.birthPlace}'), Text('سال تولد: ${p.birthYear}'), Text('شماره: ${p.phone}'), Text('توضیحات: ${p.notes}'), Text('فرزندان: ${children.map((e)=>e.fullName).join('، ')}'), ElevatedButton.icon(onPressed: p.phone.isEmpty ? null : () { store.inviteSms(p); Navigator.pop(context); }, icon: const Icon(Icons.sms), label: const Text('ارسال دعوت پیامکی Mock'))])))); }

void showTreeDialog(BuildContext context, AppStore store) { final title=TextEditingController(); final clan=TextEditingController(); final owner=TextEditingController(); showDialog(context: context, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: const Text('ساخت شجره‌نامه جدید'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller:title, decoration: input('نام شجره')), const SizedBox(height:8), TextField(controller:clan, decoration: input('طایفه/شاخه')), const SizedBox(height:8), TextField(controller:owner, decoration: input('نام ادمین'))]), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('لغو')), ElevatedButton(onPressed: () { final t=FamilyTree(id:_uuid.v4(), title:title.text.trim().isEmpty?'شجره جدید':title.text.trim(), clan:clan.text.trim(), ownerName: owner.text.trim().isEmpty?'ادمین':owner.text.trim()); t.members.add(TreeMember(id:_uuid.v4(), name:t.ownerName, role:'owner', approved:true)); store.trees.add(t); store.selectedIndex=store.trees.length-1; store.save(); Navigator.pop(context); }, child: const Text('ساخت'))] ))); }

void showPersonDialog(BuildContext context, AppStore store) { final name=TextEditingController(); final father=TextEditingController(); final grand=TextEditingController(); final phone=TextEditingController(); final branch=TextEditingController(); final place=TextEditingController(); final year=TextEditingController(); final notes=TextEditingController(); showModalBottomSheet(context: context, isScrollControlled:true, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: EdgeInsets.only(left:18,right:18,top:18,bottom:MediaQuery.of(context).viewInsets.bottom+18), child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [header('افزودن شخص', 'با نام پدر و پدربزرگ، جایگاه خودکار تشخیص داده می‌شود'), TextField(controller:name, decoration: input('نام کامل *')), const SizedBox(height:8), TextField(controller:father, decoration: input('نام پدر')), const SizedBox(height:8), TextField(controller:grand, decoration: input('نام پدربزرگ')), const SizedBox(height:8), TextField(controller:phone, decoration: input('شماره موبایل برای دعوت')), const SizedBox(height:8), TextField(controller:branch, decoration: input('شاخه خانوادگی')), const SizedBox(height:8), TextField(controller:place, decoration: input('محل تولد/زندگی')), const SizedBox(height:8), TextField(controller:year, decoration: input('سال تولد تقریبی')), const SizedBox(height:8), TextField(controller:notes, decoration: input('توضیحات')), const SizedBox(height:14), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () async { if(name.text.trim().isEmpty) return; final p=Person(id:_uuid.v4(), code:store.nextCode(store.current!), fullName:name.text.trim(), fatherName:father.text.trim(), grandfatherName:grand.text.trim(), phone:phone.text.trim(), branch:branch.text.trim(), birthPlace:place.text.trim(), birthYear:year.text.trim(), notes:notes.text.trim()); final msg=await store.addPersonSmart(p); if(context.mounted){ Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg))); } }, child: const Text('ثبت و تشخیص جایگاه')))]))))); }

void showMemberDialog(BuildContext context, AppStore store) { final name=TextEditingController(); final phone=TextEditingController(); String role='admin'; showDialog(context: context, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: StatefulBuilder(builder: (context,setState)=>AlertDialog(title: const Text('افزودن عضو/ادمین'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller:name, decoration: input('نام')), const SizedBox(height:8), TextField(controller:phone, decoration: input('شماره')), const SizedBox(height:8), DropdownButtonFormField(value:role, decoration: input('نقش'), items: const [DropdownMenuItem(value:'admin', child: Text('ادمین')), DropdownMenuItem(value:'branch_manager', child: Text('مدیر شاخه')), DropdownMenuItem(value:'member', child: Text('عضو')), DropdownMenuItem(value:'viewer', child: Text('فقط مشاهده'))], onChanged:(v)=>setState(()=>role=v!))]), actions: [TextButton(onPressed:()=>Navigator.pop(context), child: const Text('لغو')), ElevatedButton(onPressed:(){ store.current!.members.add(TreeMember(id:_uuid.v4(), name:name.text.trim(), phone:phone.text.trim(), role:role, approved:true)); store.save(); Navigator.pop(context); }, child: const Text('ثبت'))])))); }

void showRequestDialog(BuildContext context, AppStore store) { final name=TextEditingController(); final phone=TextEditingController(); final rel=TextEditingController(); showDialog(context: context, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(title: const Text('درخواست عضویت'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller:name, decoration: input('نام')), const SizedBox(height:8), TextField(controller:phone, decoration: input('شماره')), const SizedBox(height:8), TextField(controller:rel, decoration: input('نسبت/توضیح'))]), actions: [TextButton(onPressed:()=>Navigator.pop(context), child: const Text('لغو')), ElevatedButton(onPressed:(){ store.current!.requests.add(JoinRequest(id:_uuid.v4(), name:name.text.trim(), phone:phone.text.trim(), relationHint:rel.text.trim())); store.save(); Navigator.pop(context); }, child: const Text('ارسال'))]))); }
void showList(BuildContext context, String title, List<String> items) => showModalBottomSheet(context: context, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: ListView(padding: const EdgeInsets.all(18), children: [header(title, '${items.length} مورد'), ...items.map((e)=>Container(margin: const EdgeInsets.only(bottom:8), padding: const EdgeInsets.all(12), decoration: box(), child: Text(e)))])));
