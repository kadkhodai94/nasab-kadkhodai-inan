# NasabNama v5.8.8 Safe No-Crash Subscription UI

Critical fix:
- Removed local native Bazaar plugin that caused app launch crash
- Removed bazaar_iab dependency and plugin folder
- Removed Poolakey/cafebazaar external dependencies
- Subscription UI and free limits remain
- Bazaar Product IDs remain visible
- Direct Bazaar purchase is temporarily disabled to guarantee stable app launch
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.8+49
