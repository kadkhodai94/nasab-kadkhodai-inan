# NasabNama v5.10.0 Bazaar Subscription Safe

Base:
- v5.9.4 stable with correct package, keystore and uploaded icon

Changes:
- Adds subscription page
- Adds free limits:
  - 1 family tree
  - 25 people
- Adds Bazaar subscription product IDs:
  - nasab_monthly_100
  - nasab_3month_250
  - nasab_6month_560
  - nasab_yearly_1000
- Adds local Bazaar IAB plugin:
  plugins/bazaar_iab
- No Poolakey dependency
- No cafebazaar_flutter dependency
- No JitPack dependency
- Payment code runs only when user taps purchase/restore buttons
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and uploaded launcher icon remain

Version: 5.10.0+56
