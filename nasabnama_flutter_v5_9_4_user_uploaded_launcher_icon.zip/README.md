# NasabNama v5.9.4 User Uploaded Launcher Icon

Base:
- v5.9.3 force launcher icon workflow

Changes:
- Replaces launcher icon with the exact user-uploaded family tree icon
- Keeps stable package/MainActivity fix
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Payment/subscription remains removed
- Workflow unchanged from v5.9.3

Version: 5.9.4+55
