# NasabNama v5.10.13 Jalali Dates + Home Text Fix

Base:
- v5.10.12 Horizontal Ancestors Row

Changes:
- Fixes broken/overwrapped text in Home page cards
- Subscription card on Home is now compact and readable
- Backup card on Home is now compact and readable
- Stat cards now use safer RTL alignment, max lines, ellipsis and FittedBox
- Horizontal action strip width/height adjusted for cleaner Home layout
- Adds built-in Jalali date conversion without external package
- shortDate now displays Jalali date with Persian digits
- shortDateTime now displays Jalali date + time with Persian digits
- Subscription expiration date is displayed Jalali
- Backup dates are displayed Jalali
- Logs are displayed Jalali
- Event dates are displayed Jalali
- Chat message dates are displayed Jalali
- Invite created/used dates are displayed Jalali
- About page version updated
- Manual/no-auto-detect logic is preserved
- Generation 7 children layout fix is preserved
- Horizontal ancestors row is preserved
- Keeps one-time invite system
- Keeps local auth/access system
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.13+69
