# NasabNama v5.10.12 Horizontal Ancestors Row

Base:
- v5.10.11 Tree Layout Children Fix

Fixes:
- Upper generations / ancestors are no longer shown as a vertical column
- Ancestors are shown in one horizontal centered row
- Ancestor row does not wrap into a second row
- If ancestors are more than the visible width, the same row scrolls horizontally
- Children generation 7 rendering fix from v5.10.11 is preserved
- Child row height and visibility remain fixed
- Tree rendering still uses direct fatherId / motherId / spouseId only
- No automatic name detection is restored
- autoPlace remains disabled
- dedupeSmart remains disabled
- Keeps main card UI style unchanged
- Keeps one-time invite system
- Keeps local auth/access system
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.12+68
