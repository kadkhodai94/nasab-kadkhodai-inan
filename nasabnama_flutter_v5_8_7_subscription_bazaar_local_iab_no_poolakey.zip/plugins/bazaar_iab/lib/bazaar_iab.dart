
import 'dart:async';

import 'package:flutter/services.dart';

class BazaarPurchase {
  final String productId;
  final String orderId;
  final String purchaseToken;
  final String purchaseData;
  final String signature;

  const BazaarPurchase({
    required this.productId,
    this.orderId = '',
    this.purchaseToken = '',
    this.purchaseData = '',
    this.signature = '',
  });

  factory BazaarPurchase.fromMap(Map<dynamic, dynamic> map) {
    return BazaarPurchase(
      productId: (map['productId'] ?? map['product_id'] ?? '').toString(),
      orderId: (map['orderId'] ?? map['order_id'] ?? '').toString(),
      purchaseToken: (map['purchaseToken'] ?? map['purchase_token'] ?? map['token'] ?? '').toString(),
      purchaseData: (map['purchaseData'] ?? '').toString(),
      signature: (map['signature'] ?? '').toString(),
    );
  }
}

class BazaarIab {
  BazaarIab._();
  static final BazaarIab instance = BazaarIab._();

  static const MethodChannel _channel = MethodChannel('mk.kadkhodai.bazaar_iab');

  Future<BazaarPurchase?> purchaseSubscription(String productId, {String payload = ''}) async {
    final result = await _channel.invokeMethod<dynamic>('purchaseSubscription', <String, dynamic>{
      'productId': productId,
      'payload': payload,
    });
    if (result is Map) return BazaarPurchase.fromMap(result);
    return null;
  }

  Future<List<BazaarPurchase>> restoreSubscriptions() async {
    final result = await _channel.invokeMethod<dynamic>('restoreSubscriptions');
    if (result is Iterable) {
      return result.whereType<Map>().map(BazaarPurchase.fromMap).toList();
    }
    return <BazaarPurchase>[];
  }

  Future<bool> isAvailable() async {
    final result = await _channel.invokeMethod<dynamic>('isAvailable');
    return result == true;
  }
}
