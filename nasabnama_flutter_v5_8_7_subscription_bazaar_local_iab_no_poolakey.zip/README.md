# NasabNama v5.8.7 Local Bazaar IAB

Final build-root fix:
- Removed flutter_poolakey completely
- Removed cafebazaar_flutter completely
- Added local plugin: plugins/bazaar_iab
- No JitPack dependency
- No com.github.cafebazaar.Poolakey dependency
- No external Gradle repository required for Bazaar billing bridge
- Uses legacy Cafe Bazaar IAB service binding:
  ir.cafebazaar.pardakht.InAppBillingService.BIND
  package com.farsitel.bazaar
- Product IDs remain the same:
  nasab_monthly_100
  nasab_3month_250
  nasab_6month_560
  nasab_yearly_1000
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.7+48
