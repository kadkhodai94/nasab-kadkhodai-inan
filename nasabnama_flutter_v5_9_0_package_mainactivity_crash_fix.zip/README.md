# NasabNama v5.9.0 Package/MainActivity Crash Fix

Purpose:
- Built from stable v5.7.0 UI/logic base
- Removes subscription/payment changes
- Removes custom launcher icon patch
- Keeps package mk.kadkhodai.nasab but fixes MainActivity/namespace/applicationId consistently
- Manifest uses absolute MainActivity name: mk.kadkhodai.nasab.MainActivity
- Workflow recreates clean Android folder every build
- Keystore is kept if android_signing exists
- StoreFile path is normalized to avoid signing path mistakes

Version: 5.9.0+51
