# NasabNama v5.10.4 Compile Fix Export

Base:
- v5.10.3 Clean Export Layout

Fixes:
- Adds missing PDF imports:
  - package:pdf/pdf.dart
  - package:pdf/widgets.dart as pw
- Adds missing rendering/storage imports:
  - dart:typed_data
  - dart:ui as ui
  - package:flutter/rendering.dart
  - package:path_provider/path_provider.dart
- Fixes sheetContext inside export bottom sheet
- Keeps compact export button
- Keeps PNG export
- Keeps PDF export
- Keeps centered upper-generation layout
- Keeps generic sample names
- Keeps Bazaar payment and public key
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.4+60
