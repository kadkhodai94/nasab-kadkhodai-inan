# NasabNama v5.10.10 No Auto Detect / Manual Links

Base:
- v5.10.9 Safe Full Family Entry

Main fix:
- Removes automatic name detection and guessed family linking from registration paths.

Changes:
- addOrUpdatePerson no longer calls autoPlace
- addFullFamily is fully manual
- Full family entry no longer searches for similar existing persons
- Full family entry no longer suggests/chooses similar family heads
- Full family entry no longer runs automatic dedupe
- Full family entry creates a new father and optional spouse
- Children are linked only through direct fatherId/motherId to the newly created father/spouse
- Head father/grandfather names are saved as text only
- Add person page text changed to manual mode
- Tree rendering uses direct IDs only for parent/child/spouse display
- Text-only fatherName/motherName is not used for automatic tree connections
- autoPlace is disabled as a no-op
- dedupeSmart is disabled as a no-op to avoid wrong merges
- Add spouse and add parent helper actions create direct manual records, not guessed matches
- Keeps home cleanup
- Keeps one-time invite system
- Keeps local auth/access system
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.10+66
