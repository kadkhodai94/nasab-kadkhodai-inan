# NasabNama v5.11.4 Auto Login + Auto Sync

Base:
- nasabnama_flutter_v5_11_3_auto_api_clean_release.zip

Changes:
- Local app login and online login are unified
- The app no longer asks for separate online username/password
- The app automatically creates/logs into the online account using the local app account
- Online token is stored in app settings
- If offline, data is saved locally
- When online, pending local changes are uploaded automatically
- Auto sync runs after saves and periodically while the app is open
- Online Sync page now shows real sync state instead of a login form
- Removed misleading "بدون ورود آنلاین" state
- Manual sync/download buttons remain only for emergency control
- API remains hardcoded:
  https://podtman.anony.ir/nasab
- Backend v5.11.4 includes auto_login endpoint
- Keeps Jalali dates, Bazaar payment, tree layout, export, icon, keystore and package name
- Workflow unchanged

Version: 5.11.4+72
