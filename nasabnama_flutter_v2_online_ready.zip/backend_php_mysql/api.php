<?php
header('Content-Type: application/json; charset=utf-8');
$pdo = new PDO('mysql:host=localhost;dbname=nasabnama;charset=utf8mb4', 'DB_USER', 'DB_PASS', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$action = $_GET['action'] ?? '';
function out($data){ echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
if ($action === 'health') out(['success'=>true,'message'=>'NasabNama API is ready']);
if ($action === 'trees') { $rows=$pdo->query('SELECT * FROM family_trees ORDER BY id DESC LIMIT 50')->fetchAll(PDO::FETCH_ASSOC); out(['success'=>true,'trees'=>$rows]); }
if ($action === 'persons') { $treeId=(int)($_GET['tree_id']??0); $st=$pdo->prepare('SELECT * FROM persons WHERE tree_id=? ORDER BY id ASC'); $st->execute([$treeId]); out(['success'=>true,'persons'=>$st->fetchAll(PDO::FETCH_ASSOC)]); }
out(['success'=>false,'error'=>'unknown_action']);
