# NasabNama Backend PHP/MySQL

این پوشه قالب اولیه بک‌اند آنلاین است.

1. دیتابیس MySQL بسازید.
2. فایل `schema.sql` را import کنید.
3. در `api.php` مقدار `DB_USER` و `DB_PASS` را تنظیم کنید.
4. تست سلامت:
`https://yourdomain.com/api.php?action=health`

این نسخه قالب آنلاین است؛ اتصال کامل اپ به API در فاز بعد تکمیل می‌شود.
