CREATE TABLE users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(30) UNIQUE,
  password_hash VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE family_trees (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  owner_user_id BIGINT NOT NULL,
  invite_code VARCHAR(80) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE persons (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tree_id BIGINT NOT NULL,
  code VARCHAR(50) NOT NULL,
  full_name VARCHAR(180) NOT NULL,
  father_name VARCHAR(180),
  grandfather_name VARCHAR(180),
  father_id BIGINT NULL,
  mother_id BIGINT NULL,
  phone VARCHAR(30),
  gender VARCHAR(20),
  branch VARCHAR(120),
  birth_date VARCHAR(40),
  death_date VARCHAR(40),
  city VARCHAR(120),
  country VARCHAR(120),
  notes TEXT,
  is_featured TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE tree_members (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tree_id BIGINT NOT NULL,
  user_id BIGINT NULL,
  name VARCHAR(150),
  phone VARCHAR(30),
  role ENUM('owner','admin','branch_admin','member','viewer') DEFAULT 'member',
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE invitations (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tree_id BIGINT NOT NULL,
  person_id BIGINT NULL,
  code VARCHAR(80) NOT NULL,
  phone VARCHAR(30),
  status ENUM('created','sent','accepted','expired') DEFAULT 'created',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE activity_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tree_id BIGINT NOT NULL,
  user_id BIGINT NULL,
  title VARCHAR(255) NOT NULL,
  details JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE photos (id BIGINT AUTO_INCREMENT PRIMARY KEY, tree_id BIGINT, person_id BIGINT, file_url TEXT, caption VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE documents (id BIGINT AUTO_INCREMENT PRIMARY KEY, tree_id BIGINT, person_id BIGINT, file_url TEXT, title VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE notifications (id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT, tree_id BIGINT, title VARCHAR(255), body TEXT, is_read TINYINT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
