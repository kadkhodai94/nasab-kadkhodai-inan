import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NasabNamaApp());
}

const _uuid = Uuid();

class AppColors {
  static const bg = Color(0xFFF7F0E6);
  static const cream = Color(0xFFFFF8EE);
  static const card = Color(0xFFFFFFFF);
  static const ink = Color(0xFF192033);
  static const muted = Color(0xFF6F7280);
  static const blue = Color(0xFF2F80ED);
  static const green = Color(0xFF20B486);
  static const softBlue = Color(0xFFE8F2FF);
  static const softGreen = Color(0xFFE7F8F2);
  static const shadow = Color(0x1A1C274C);
}

String clean(String value) => value.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();

class Person {
  String id;
  String code;
  String name;
  String fatherName;
  String grandfatherName;
  String? fatherId;
  String phone;
  String branch;
  String birthYear;
  String birthPlace;
  String notes;

  Person({
    required this.id,
    required this.code,
    required this.name,
    this.fatherName = '',
    this.grandfatherName = '',
    this.fatherId,
    this.phone = '',
    this.branch = '',
    this.birthYear = '',
    this.birthPlace = '',
    this.notes = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'name': name,
        'fatherName': fatherName,
        'grandfatherName': grandfatherName,
        'fatherId': fatherId,
        'phone': phone,
        'branch': branch,
        'birthYear': birthYear,
        'birthPlace': birthPlace,
        'notes': notes,
      };

  factory Person.fromJson(Map<String, dynamic> j) => Person(
        id: j['id'] ?? _uuid.v4(),
        code: j['code'] ?? 'FAM-000000',
        name: j['name'] ?? j['fullName'] ?? '',
        fatherName: j['fatherName'] ?? '',
        grandfatherName: j['grandfatherName'] ?? '',
        fatherId: j['fatherId'],
        phone: j['phone'] ?? '',
        branch: j['branch'] ?? '',
        birthYear: j['birthYear'] ?? '',
        birthPlace: j['birthPlace'] ?? '',
        notes: j['notes'] ?? '',
      );
}

class TreeMember {
  String id;
  String name;
  String role;
  bool approved;

  TreeMember({required this.id, required this.name, this.role = 'viewer', this.approved = true});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'role': role, 'approved': approved};
  factory TreeMember.fromJson(Map<String, dynamic> j) => TreeMember(id: j['id'] ?? _uuid.v4(), name: j['name'] ?? '', role: j['role'] ?? 'viewer', approved: j['approved'] ?? true);
}

class FamilyTree {
  String id;
  String title;
  String ownerName;
  String branch;
  List<Person> people;
  List<TreeMember> members;
  List<String> smsLog;

  FamilyTree({
    required this.id,
    required this.title,
    required this.ownerName,
    this.branch = '',
    List<Person>? people,
    List<TreeMember>? members,
    List<String>? smsLog,
  })  : people = people ?? [],
        members = members ?? [],
        smsLog = smsLog ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'ownerName': ownerName,
        'branch': branch,
        'people': people.map((e) => e.toJson()).toList(),
        'members': members.map((e) => e.toJson()).toList(),
        'smsLog': smsLog,
      };

  factory FamilyTree.fromJson(Map<String, dynamic> j) => FamilyTree(
        id: j['id'] ?? _uuid.v4(),
        title: j['title'] ?? 'شجره‌نامه',
        ownerName: j['ownerName'] ?? 'ادمین',
        branch: j['branch'] ?? j['clan'] ?? '',
        people: (j['people'] as List? ?? []).map((e) => Person.fromJson(Map<String, dynamic>.from(e))).toList(),
        members: (j['members'] as List? ?? []).map((e) => TreeMember.fromJson(Map<String, dynamic>.from(e))).toList(),
        smsLog: List<String>.from(j['smsLog'] ?? []),
      );
}

class AppStore extends ChangeNotifier {
  static const key = 'nasabnama_v13';
  List<FamilyTree> trees = [];
  int selectedTree = 0;

  FamilyTree? get current => trees.isEmpty ? null : trees[min(selectedTree, trees.length - 1)];

  Future<void> load() async {
    final pref = await SharedPreferences.getInstance();
    final raw = pref.getString(key);
    if (raw == null) {
      trees = [_sampleTree()];
      await save();
    } else {
      trees = (jsonDecode(raw) as List).map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    notifyListeners();
  }

  Future<void> save() async {
    final pref = await SharedPreferences.getInstance();
    await pref.setString(key, jsonEncode(trees.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  FamilyTree _sampleTree() {
    final tree = FamilyTree(id: _uuid.v4(), title: 'شجره‌نامه نمونه', ownerName: 'ادمین اصلی', branch: 'شاخه اصلی');
    final grand = Person(id: _uuid.v4(), code: 'FAM-000001', name: 'ملا عمر', branch: 'شاخه اصلی');
    final father = Person(id: _uuid.v4(), code: 'FAM-000002', name: 'عبدالواحد', fatherName: 'ملا عمر', fatherId: grand.id, branch: 'شاخه اصلی');
    final child = Person(id: _uuid.v4(), code: 'FAM-000003', name: 'محمد', fatherName: 'عبدالواحد', grandfatherName: 'ملا عمر', fatherId: father.id, branch: 'شاخه اصلی');
    tree.people.addAll([grand, father, child]);
    tree.members.add(TreeMember(id: _uuid.v4(), name: 'ادمین اصلی', role: 'owner'));
    return tree;
  }

  String nextCode(FamilyTree tree) => 'FAM-${(tree.people.length + 1).toString().padLeft(6, '0')}';

  Future<void> createTree(String title, String owner, String branch) async {
    final tree = FamilyTree(id: _uuid.v4(), title: title, ownerName: owner, branch: branch);
    tree.members.add(TreeMember(id: _uuid.v4(), name: owner, role: 'owner'));
    trees.insert(0, tree);
    selectedTree = 0;
    await save();
  }

  Future<String> addPersonSmart(Person p) async {
    final tree = current;
    if (tree == null) return 'هیچ شجره‌نامه‌ای انتخاب نشده است.';
    String result = 'شخص ثبت شد. اگر رابطه دقیق نبود، از مدیریت اصلاح کن.';
    final fatherKey = clean(p.fatherName);
    final grandKey = clean(p.grandfatherName);

    Person? foundFather;
    for (final candidate in tree.people) {
      final candName = clean(candidate.name);
      final candFirst = clean(candidate.name.split(' ').first);
      if (fatherKey.isNotEmpty && (candName == fatherKey || candFirst == fatherKey || candName.contains(fatherKey))) {
        if (grandKey.isEmpty || clean(candidate.fatherName).contains(grandKey)) {
          foundFather = candidate;
          break;
        }
        final parent = candidate.fatherId == null ? null : personById(candidate.fatherId!);
        if (parent != null && clean(parent.name).contains(grandKey)) {
          foundFather = candidate;
          break;
        }
      }
    }

    if (foundFather != null) {
      p.fatherId = foundFather.id;
      if (p.branch.isEmpty) p.branch = foundFather.branch;
      result = 'جایگاه خودکار پیدا شد و ${p.name} زیر ${foundFather.name} قرار گرفت.';
    } else if (fatherKey.isNotEmpty) {
      Person? foundGrand;
      for (final candidate in tree.people) {
        if (grandKey.isNotEmpty && clean(candidate.name).contains(grandKey)) {
          foundGrand = candidate;
          break;
        }
      }
      if (foundGrand != null) {
        final father = Person(
          id: _uuid.v4(),
          code: nextCode(tree),
          name: p.fatherName,
          fatherName: p.grandfatherName,
          fatherId: foundGrand.id,
          branch: foundGrand.branch,
        );
        tree.people.add(father);
        p.fatherId = father.id;
        if (p.branch.isEmpty) p.branch = father.branch;
        result = 'پدر ساخته شد و ${p.name} در جایگاه پیشنهادی قرار گرفت.';
      }
    }

    tree.people.add(p);
    if (p.phone.trim().isNotEmpty) {
      tree.smsLog.insert(0, 'دعوت پیامکی برای ${p.name} (${p.phone}) آماده شد: شما به عنوان عضوی از ${tree.title} ثبت شده‌اید و برای تکمیل شجره‌نامه دعوت می‌شوید. کد عضویت: ${p.code}');
    }
    await save();
    return result;
  }

  Person? personById(String id) {
    final tree = current;
    if (tree == null) return null;
    for (final p in tree.people) {
      if (p.id == id) return p;
    }
    return null;
  }

  List<Person> childrenOf(String? parentId) {
    final tree = current;
    if (tree == null) return [];
    return tree.people.where((p) => p.fatherId == parentId).toList();
  }

  List<Person> search(String q) {
    final tree = current;
    if (tree == null) return [];
    final key = clean(q);
    if (key.isEmpty) return [];
    return tree.people.where((p) {
      return clean(p.name).contains(key) || clean(p.fatherName).contains(key) || clean(p.grandfatherName).contains(key) || clean(p.code).contains(key);
    }).toList();
  }

  Future<File> exportZip() async {
    final tree = current!;
    final archive = Archive();
    final bytes = utf8.encode(const JsonEncoder.withIndent('  ').convert(tree.toJson()));
    archive.addFile(ArchiveFile('nasabnama_${tree.id}.json', bytes.length, bytes));
    final zip = ZipEncoder().encode(archive)!;
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/nasabnama_${DateTime.now().millisecondsSinceEpoch}.zip');
    await file.writeAsBytes(zip);
    return file;
  }

  Future<String> importZipOrJson() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip', 'json']);
    if (picked == null || picked.files.single.path == null) return 'فایلی انتخاب نشد.';
    final file = File(picked.files.single.path!);
    String raw;
    if (file.path.toLowerCase().endsWith('.zip')) {
      final archive = ZipDecoder().decodeBytes(await file.readAsBytes());
      final jsonFile = archive.files.where((f) => f.name.endsWith('.json')).first;
      raw = utf8.decode(jsonFile.content as List<int>);
    } else {
      raw = await file.readAsString();
    }
    final tree = FamilyTree.fromJson(Map<String, dynamic>.from(jsonDecode(raw)));
    trees.insert(0, tree);
    selectedTree = 0;
    await save();
    return 'شجره‌نامه ${tree.title} با موفقیت خوانده شد.';
  }
}

class NasabNamaApp extends StatefulWidget {
  const NasabNamaApp({super.key});

  @override
  State<NasabNamaApp> createState() => _NasabNamaAppState();
}

class _NasabNamaAppState extends State<NasabNamaApp> {
  final store = AppStore();
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    store.load().then((_) => setState(() => loaded = true));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'نسب‌نامه',
        theme: ThemeData(
          fontFamily: 'sans',
          useMaterial3: true,
          scaffoldBackgroundColor: AppColors.bg,
          colorScheme: ColorScheme.fromSeed(seedColor: AppColors.blue, brightness: Brightness.light),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          ),
        ),
        home: Directionality(textDirection: TextDirection.rtl, child: loaded ? HomeShell(store: store) : const Splash()),
      ),
    );
  }
}

class Splash extends StatelessWidget {
  const Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class HomeShell extends StatefulWidget {
  final AppStore store;
  const HomeShell({super.key, required this.store});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int page = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [Dashboard(store: widget.store), TreePage(store: widget.store), SearchPage(store: widget.store), ManagePage(store: widget.store), HelpPage(store: widget.store)];
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(child: pages[page]),
      floatingActionButton: page == 0 || page == 1
          ? FloatingActionButton.extended(
              backgroundColor: AppColors.blue,
              foregroundColor: Colors.white,
              onPressed: () => showPersonSheet(context, widget.store),
              icon: const Icon(Icons.person_add_alt_1),
              label: const Text('افزودن شخص'),
            )
          : null,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: AppColors.shadow, blurRadius: 18, offset: Offset(0, -6))]),
        child: NavigationBar(
          selectedIndex: page,
          backgroundColor: Colors.white,
          indicatorColor: AppColors.softBlue,
          onDestinationSelected: (i) => setState(() => page = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.account_tree_rounded), label: 'درخت'),
            NavigationDestination(icon: Icon(Icons.search_rounded), label: 'جستجو'),
            NavigationDestination(icon: Icon(Icons.admin_panel_settings_rounded), label: 'مدیریت'),
            NavigationDestination(icon: Icon(Icons.help_rounded), label: 'راهنما'),
          ],
        ),
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  const Dashboard({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final tree = store.current;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 110),
      children: [
        Row(
          children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('نسب‌نامه', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: AppColors.ink)),
              Text(tree == null ? 'شروع ساخت شجره' : tree.title, style: const TextStyle(fontSize: 15, color: AppColors.muted)),
            ])),
            IconButton.filledTonal(onPressed: () => showTreeSheet(context, store), icon: const Icon(Icons.add_circle_outline_rounded)),
          ],
        ),
        const SizedBox(height: 18),
        _HeroCard(tree: tree),
        const SizedBox(height: 18),
        if (tree == null) const EmptyState() else _StatsGrid(tree: tree),
        const SizedBox(height: 18),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          childAspectRatio: 1.35,
          children: [
            ActionCard(icon: Icons.person_add_alt_1, title: 'افزودن هوشمند', subtitle: 'با نام پدر و پدربزرگ', color: AppColors.blue, onTap: () => showPersonSheet(context, store)),
            ActionCard(icon: Icons.account_tree_rounded, title: 'نمای شجره', subtitle: 'زوم و جابه‌جایی', color: AppColors.green, onTap: () => DefaultTabController.of(context)),
            ActionCard(icon: Icons.file_upload_outlined, title: 'خروجی ZIP', subtitle: 'فایل پشتیبان', color: AppColors.blue, onTap: () async {
              final f = await store.exportZip();
              await Share.shareXFiles([XFile(f.path)], text: 'خروجی شجره‌نامه');
            }),
            ActionCard(icon: Icons.folder_zip_rounded, title: 'خواندن ZIP/JSON', subtitle: 'ورود اطلاعات', color: AppColors.green, onTap: () async {
              final msg = await store.importZipOrJson();
              if (context.mounted) showSnack(context, msg);
            }),
          ],
        ),
        const SizedBox(height: 22),
        const Text('آخرین افراد ثبت‌شده', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.ink)),
        const SizedBox(height: 12),
        ...((tree?.people.reversed.take(5) ?? <Person>[]).map((p) => PersonTile(person: p, store: store))),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final FamilyTree? tree;
  const _HeroCard({required this.tree});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: premiumDecoration(gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFEAF6FF)])),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.blue.withOpacity(.12), borderRadius: BorderRadius.circular(22)),
            child: const Icon(Icons.family_restroom_rounded, color: AppColors.blue, size: 34),
          ),
          const SizedBox(width: 14),
          Expanded(child: Text(tree == null ? 'هنوز شجره‌ای ساخته نشده' : tree!.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.ink))),
        ]),
        const SizedBox(height: 14),
        Text(tree == null ? 'از دکمه + یک شجره جدید بساز. بعد اعضا را با نام پدر و پدربزرگ اضافه کن.' : 'ادمین: ${tree!.ownerName}  |  شاخه: ${tree!.branch.isEmpty ? 'ثبت نشده' : tree!.branch}', style: const TextStyle(fontSize: 15, color: AppColors.muted, height: 1.7)),
      ]),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  final FamilyTree tree;
  const _StatsGrid({required this.tree});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: StatCard(title: 'افراد', value: tree.people.length.toString(), icon: Icons.groups_rounded)),
      const SizedBox(width: 12),
      Expanded(child: StatCard(title: 'اعضا', value: tree.members.length.toString(), icon: Icons.verified_user_rounded)),
      const SizedBox(width: 12),
      Expanded(child: StatCard(title: 'دعوت‌ها', value: tree.smsLog.length.toString(), icon: Icons.sms_rounded)),
    ]);
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: premiumDecoration(color: Colors.white),
      child: Column(children: [Icon(icon, color: AppColors.green), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.ink)), Text(title, style: const TextStyle(color: AppColors.muted))]),
    );
  }
}

class ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const ActionCard({super.key, required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: premiumDecoration(color: Colors.white),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 34),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.ink)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]),
      ),
    );
  }
}

class TreePage extends StatelessWidget {
  final AppStore store;
  const TreePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final tree = store.current;
    if (tree == null || tree.people.isEmpty) {
      return const EmptyState(message: 'هنوز فردی برای نمایش در شجره ثبت نشده است.');
    }
    final roots = tree.people.where((p) => p.fatherId == null || store.personById(p.fatherId!) == null).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('نمای شجره', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.ink)),
            SizedBox(height: 6),
            Text('با دو انگشت زوم کن؛ با دست صفحه را جابه‌جا کن. کارت‌ها دیگر بریده نمی‌شوند.', style: TextStyle(color: AppColors.muted)),
          ]),
        ),
        Expanded(
          child: Container(
            margin: const EdgeInsets.fromLTRB(14, 8, 14, 92),
            decoration: premiumDecoration(color: const Color(0xFFFFFCF7)),
            clipBehavior: Clip.antiAlias,
            child: InteractiveViewer(
              constrained: false,
              minScale: .35,
              maxScale: 2.6,
              boundaryMargin: const EdgeInsets.all(500),
              child: Padding(
                padding: const EdgeInsets.all(60),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: roots.map((r) => TreeNode(person: r, store: store)).toList()),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class TreeNode extends StatelessWidget {
  final Person person;
  final AppStore store;
  const TreeNode({super.key, required this.person, required this.store});

  @override
  Widget build(BuildContext context) {
    final children = store.childrenOf(person.id);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(children: [
        _TreePersonCard(person: person),
        if (children.isNotEmpty) ...[
          Container(width: 2, height: 26, color: AppColors.blue.withOpacity(.45)),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: children.map((c) => TreeNode(person: c, store: store)).toList()),
        ],
      ]),
    );
  }
}

class _TreePersonCard extends StatelessWidget {
  final Person person;
  const _TreePersonCard({required this.person});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF2F80ED), Color(0xFF20B486)]),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: Color(0x332F80ED), blurRadius: 18, offset: Offset(0, 10))],
      ),
      child: Column(children: [
        const Icon(Icons.person_rounded, color: Colors.white, size: 28),
        const SizedBox(height: 8),
        Text(person.name, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 4),
        Text(person.code, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        if (person.fatherName.isNotEmpty) Text('پدر: ${person.fatherName}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ]),
    );
  }
}

class SearchPage extends StatefulWidget {
  final AppStore store;
  const SearchPage({super.key, required this.store});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final controller = TextEditingController();
  List<Person> results = [];

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 110), children: [
      const Text('جستجوی اعضا', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.ink)),
      const SizedBox(height: 10),
      const Text('اسم خودت، اسم پدر، پدربزرگ یا کد شخص را بنویس تا اطلاعات کامل نمایش داده شود.', style: TextStyle(color: AppColors.muted)),
      const SizedBox(height: 18),
      TextField(
        controller: controller,
        textInputAction: TextInputAction.search,
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'مثلاً محمد، عبدالواحد یا FAM-000001'),
        onChanged: (v) => setState(() => results = widget.store.search(v)),
      ),
      const SizedBox(height: 18),
      if (controller.text.isEmpty) const HelpBox(text: 'برای جلوگیری از اشتباه، اگر چند نفر هم‌نام باشند همه نتیجه‌ها جدا نمایش داده می‌شوند.') else if (results.isEmpty) const EmptyState(message: 'نتیجه‌ای پیدا نشد.') else ...results.map((p) => PersonTile(person: p, store: widget.store, expanded: true)),
    ]);
  }
}

class ManagePage extends StatelessWidget {
  final AppStore store;
  const ManagePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final tree = store.current;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 110), children: [
      const Text('مدیریت', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.ink)),
      const SizedBox(height: 12),
      if (tree == null) const EmptyState() else ...[
        PremiumPanel(title: 'ادمین‌ها و اعضا', icon: Icons.admin_panel_settings_rounded, children: [
          ...tree.members.map((m) => ListTile(leading: const Icon(Icons.verified_user_rounded, color: AppColors.green), title: Text(m.name), subtitle: Text(roleLabel(m.role)), trailing: const Icon(Icons.check_circle, color: AppColors.green))),
          const Divider(),
          ElevatedButton.icon(onPressed: () => showMemberSheet(context, store), icon: const Icon(Icons.person_add), label: const Text('افزودن ادمین یا عضو')),
        ]),
        const SizedBox(height: 14),
        PremiumPanel(title: 'لاگ دعوت پیامکی', icon: Icons.sms_rounded, children: [
          if (tree.smsLog.isEmpty) const Text('هنوز دعوتی ثبت نشده است.', style: TextStyle(color: AppColors.muted)) else ...tree.smsLog.take(8).map((e) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(e, style: const TextStyle(height: 1.6)))),
        ]),
      ]
    ]);
  }
}

class HelpPage extends StatelessWidget {
  final AppStore store;
  const HelpPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 110), children: const [
      Text('راهنمای سریع', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.ink)),
      SizedBox(height: 14),
      HelpBox(text: '۱) اول یک شجره بساز یا از نمونه شروع کن. هر سازنده، ادمین همان شجره می‌شود.'),
      HelpBox(text: '۲) برای اضافه کردن شخص، نام، نام پدر و نام پدربزرگ را وارد کن. اپ خودش جایگاه را پیدا می‌کند.'),
      HelpBox(text: '۳) اگر شماره ثبت شود، یک متن دعوت پیامکی در لاگ دعوت‌ها ساخته می‌شود. برای پیامک واقعی بعداً API پنل پیامک وصل می‌شود.'),
      HelpBox(text: '۴) در صفحه درخت با دو انگشت زوم کن و با دست جابه‌جا شو. خروجی ZIP از صفحه خانه گرفته می‌شود.'),
      HelpBox(text: '۵) دسترسی‌ها در نسخه آنلاین باید سروری و با تأیید ادمین باشد. نسخه فعلی لوکال/آفلاین است.'),
    ]);
  }
}

class PersonTile extends StatelessWidget {
  final Person person;
  final AppStore store;
  final bool expanded;
  const PersonTile({super.key, required this.person, required this.store, this.expanded = false});

  @override
  Widget build(BuildContext context) {
    final father = person.fatherId == null ? null : store.personById(person.fatherId!);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: premiumDecoration(color: Colors.white),
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        leading: CircleAvatar(backgroundColor: AppColors.softGreen, child: Text(person.name.isEmpty ? '?' : person.name.characters.first, style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w900))),
        title: Text(person.name, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)),
        subtitle: Text('کد: ${person.code}${person.fatherName.isNotEmpty ? ' | پدر: ${person.fatherName}' : ''}${person.grandfatherName.isNotEmpty ? ' | پدربزرگ: ${person.grandfatherName}' : ''}${father != null ? '\nجایگاه: زیرمجموعه ${father.name}' : ''}', style: const TextStyle(height: 1.6)),
      ),
    );
  }
}

class PremiumPanel extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  const PremiumPanel({super.key, required this.title, required this.icon, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: premiumDecoration(color: Colors.white),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(icon, color: AppColors.blue), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.ink))]),
        const SizedBox(height: 14),
        ...children,
      ]),
    );
  }
}

class HelpBox extends StatelessWidget {
  final String text;
  const HelpBox({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: premiumDecoration(color: AppColors.cream),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.lightbulb_rounded, color: AppColors.green), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(height: 1.7, color: AppColors.ink)))]),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String message;
  const EmptyState({super.key, this.message = 'اطلاعاتی برای نمایش وجود ندارد.'});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: premiumDecoration(color: Colors.white),
      child: Column(children: [const Icon(Icons.account_tree_outlined, size: 54, color: AppColors.blue), const SizedBox(height: 12), Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, height: 1.7))]),
    );
  }
}

BoxDecoration premiumDecoration({Color? color, Gradient? gradient}) {
  return BoxDecoration(
    color: color,
    gradient: gradient,
    borderRadius: BorderRadius.circular(30),
    border: Border.all(color: Colors.white.withOpacity(.9), width: 1.4),
    boxShadow: const [BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0, 12))],
  );
}

String roleLabel(String role) {
  switch (role) {
    case 'owner':
      return 'ادمین اصلی';
    case 'admin':
      return 'ادمین';
    case 'editor':
      return 'عضو قابل ویرایش';
    default:
      return 'فقط مشاهده';
  }
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}

void showTreeSheet(BuildContext context, AppStore store) {
  final title = TextEditingController();
  final owner = TextEditingController();
  final branch = TextEditingController();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => FormSheet(
      title: 'ساخت شجره جدید',
      subtitle: 'سازنده این شجره به عنوان ادمین اصلی ثبت می‌شود.',
      children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'نام شجره / خانواده')),
        const SizedBox(height: 10),
        TextField(controller: owner, decoration: const InputDecoration(labelText: 'نام ادمین اصلی')),
        const SizedBox(height: 10),
        TextField(controller: branch, decoration: const InputDecoration(labelText: 'طایفه / شاخه')),
      ],
      onSubmit: () async {
        if (title.text.trim().isEmpty || owner.text.trim().isEmpty) return;
        await store.createTree(title.text.trim(), owner.text.trim(), branch.text.trim());
        if (context.mounted) Navigator.pop(context);
      },
    ),
  );
}

void showMemberSheet(BuildContext context, AppStore store) {
  final name = TextEditingController();
  String role = 'viewer';
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => StatefulBuilder(builder: (context, setState) {
      return FormSheet(
        title: 'افزودن عضو/ادمین',
        subtitle: 'سطح دسترسی را مشخص کن. در نسخه آنلاین، ورود اعضا فقط بعد از تأیید ادمین انجام می‌شود.',
        children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام عضو')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: role,
            decoration: const InputDecoration(labelText: 'سطح دسترسی'),
            items: const [
              DropdownMenuItem(value: 'viewer', child: Text('فقط مشاهده')),
              DropdownMenuItem(value: 'editor', child: Text('مشاهده و پیشنهاد ویرایش')),
              DropdownMenuItem(value: 'admin', child: Text('ادمین')),
            ],
            onChanged: (v) => setState(() => role = v ?? 'viewer'),
          ),
        ],
        onSubmit: () async {
          final tree = store.current;
          if (tree == null || name.text.trim().isEmpty) return;
          tree.members.add(TreeMember(id: _uuid.v4(), name: name.text.trim(), role: role));
          await store.save();
          if (context.mounted) Navigator.pop(context);
        },
      );
    }),
  );
}

void showPersonSheet(BuildContext context, AppStore store) {
  final tree = store.current;
  if (tree == null) {
    showSnack(context, 'اول یک شجره‌نامه بساز.');
    return;
  }
  final name = TextEditingController();
  final father = TextEditingController();
  final grand = TextEditingController();
  final phone = TextEditingController();
  final branch = TextEditingController(text: tree.branch);
  final birthYear = TextEditingController();
  final birthPlace = TextEditingController();
  final notes = TextEditingController();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => FormSheet(
      title: 'افزودن شخص',
      subtitle: 'نام پدر و پدربزرگ را بنویس تا اپ جایگاه را خودکار تشخیص دهد. فرم با کیبورد جابه‌جا می‌شود و مزاحم نیست.',
      children: [
        TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'نام کامل *')),
        const SizedBox(height: 10),
        TextField(controller: father, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'نام پدر')),
        const SizedBox(height: 10),
        TextField(controller: grand, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'نام پدربزرگ')),
        const SizedBox(height: 10),
        TextField(controller: phone, keyboardType: TextInputType.phone, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'شماره موبایل برای دعوت')),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: TextField(controller: branch, decoration: const InputDecoration(labelText: 'شاخه'))), const SizedBox(width: 10), Expanded(child: TextField(controller: birthYear, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'سال تولد')))]),
        const SizedBox(height: 10),
        TextField(controller: birthPlace, decoration: const InputDecoration(labelText: 'محل تولد / زندگی')),
        const SizedBox(height: 10),
        TextField(controller: notes, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'توضیحات')),
      ],
      onSubmit: () async {
        if (name.text.trim().isEmpty) return;
        final person = Person(
          id: _uuid.v4(),
          code: store.nextCode(tree),
          name: name.text.trim(),
          fatherName: father.text.trim(),
          grandfatherName: grand.text.trim(),
          phone: phone.text.trim(),
          branch: branch.text.trim(),
          birthYear: birthYear.text.trim(),
          birthPlace: birthPlace.text.trim(),
          notes: notes.text.trim(),
        );
        final msg = await store.addPersonSmart(person);
        if (context.mounted) {
          Navigator.pop(context);
          showSnack(context, msg);
        }
      },
    ),
  );
}

class FormSheet extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Widget> children;
  final Future<void> Function() onSubmit;
  const FormSheet({super.key, required this.title, required this.subtitle, required this.children, required this.onSubmit});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AnimatedPadding(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: DraggableScrollableSheet(
          initialChildSize: .82,
          minChildSize: .45,
          maxChildSize: .95,
          expand: false,
          builder: (context, controller) => Container(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
            decoration: const BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.vertical(top: Radius.circular(34))),
            child: ListView(controller: controller, children: [
              Center(child: Container(width: 48, height: 5, decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(20)))),
              const SizedBox(height: 16),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.ink)),
              const SizedBox(height: 8),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, height: 1.6)),
              const SizedBox(height: 18),
              ...children,
              const SizedBox(height: 18),
              SizedBox(
                height: 56,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                  onPressed: onSubmit,
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('ثبت و نمایش در شجره', style: TextStyle(fontWeight: FontWeight.w900)),
                ),
              ),
              const SizedBox(height: 24),
            ]),
          ),
        ),
      ),
    );
  }
}
