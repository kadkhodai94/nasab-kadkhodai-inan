import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NasabNamaApp());
}

const _uuid = Uuid();

String cleanText(String value) => value
    .trim()
    .replaceAll('ي', 'ی')
    .replaceAll('ك', 'ک')
    .replaceAll('ة', 'ه')
    .replaceAll('ۀ', 'ه')
    .replaceAll(RegExp(r'[‌‏؜]'), '')
    .replaceAll(RegExp(r'\s+'), ' ')
    .toLowerCase();
String nowIso() => DateTime.now().toIso8601String();
String shortDate(String iso) => iso.isEmpty ? '-' : iso.split('T').first;

T? firstWhereOrNull<T>(Iterable<T> items, bool Function(T) test) {
  for (final item in items) {
    if (test(item)) return item;
  }
  return null;
}

class C {
  static const bg = Color(0xFFF6EFE3);
  static const cream = Color(0xFFFFF8EE);
  static const white = Color(0xFFFFFFFF);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF6C7280);
  static const blue = Color(0xFF1E6FD9);
  static const sky = Color(0xFFE7F1FF);
  static const green = Color(0xFF18A978);
  static const mint = Color(0xFFE6F7EF);
  static const gold = Color(0xFFE8B95E);
  static const red = Color(0xFFE45757);
  static const shadow = Color(0x1F18213A);
}

class Person {
  String id;
  String code;
  String name;
  String fatherName;
  String grandfatherName;
  String motherName;
  String? fatherId;
  String? motherId;
  String? spouseId;
  String spouseName;
  String phone;
  String gender;
  String branch;
  String birthDate;
  String deathDate;
  String birthPlace;
  String livingPlace;
  String notes;
  String specialTag;
  bool phonePrivate;
  String createdBy;
  String createdAt;

  Person({
    required this.id,
    required this.code,
    required this.name,
    this.fatherName = '',
    this.grandfatherName = '',
    this.motherName = '',
    this.fatherId,
    this.motherId,
    this.spouseId,
    this.spouseName = '',
    this.phone = '',
    this.gender = 'نامشخص',
    this.branch = '',
    this.birthDate = '',
    this.deathDate = '',
    this.birthPlace = '',
    this.livingPlace = '',
    this.notes = '',
    this.specialTag = '',
    this.phonePrivate = true,
    this.createdBy = 'ادمین',
    String? createdAt,
  }) : createdAt = createdAt ?? nowIso();

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'name': name,
        'fatherName': fatherName,
        'grandfatherName': grandfatherName,
        'motherName': motherName,
        'fatherId': fatherId,
        'motherId': motherId,
        'spouseId': spouseId,
        'spouseName': spouseName,
        'phone': phone,
        'gender': gender,
        'branch': branch,
        'birthDate': birthDate,
        'deathDate': deathDate,
        'birthPlace': birthPlace,
        'livingPlace': livingPlace,
        'notes': notes,
        'specialTag': specialTag,
        'phonePrivate': phonePrivate,
        'createdBy': createdBy,
        'createdAt': createdAt,
      };

  factory Person.fromJson(Map<String, dynamic> j) => Person(
        id: j['id'] ?? _uuid.v4(),
        code: j['code'] ?? 'FAM-000000',
        name: j['name'] ?? '',
        fatherName: j['fatherName'] ?? '',
        grandfatherName: j['grandfatherName'] ?? '',
        motherName: j['motherName'] ?? '',
        fatherId: j['fatherId'],
        motherId: j['motherId'],
        spouseId: j['spouseId'],
        spouseName: j['spouseName'] ?? '',
        phone: j['phone'] ?? '',
        gender: j['gender'] ?? 'نامشخص',
        branch: j['branch'] ?? '',
        birthDate: j['birthDate'] ?? '',
        deathDate: j['deathDate'] ?? '',
        birthPlace: j['birthPlace'] ?? '',
        livingPlace: j['livingPlace'] ?? '',
        notes: j['notes'] ?? '',
        specialTag: j['specialTag'] ?? '',
        phonePrivate: j['phonePrivate'] ?? true,
        createdBy: j['createdBy'] ?? 'ادمین',
        createdAt: j['createdAt'],
      );

  Person copy() => Person.fromJson(toJson());
}

class TreeMember {
  String id;
  String name;
  String phone;
  String role;
  bool approved;
  String joinedAt;

  TreeMember({required this.id, required this.name, this.phone = '', this.role = 'عضو', this.approved = true, String? joinedAt}) : joinedAt = joinedAt ?? nowIso();

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'role': role, 'approved': approved, 'joinedAt': joinedAt};
  factory TreeMember.fromJson(Map<String, dynamic> j) => TreeMember(id: j['id'] ?? _uuid.v4(), name: j['name'] ?? '', phone: j['phone'] ?? '', role: j['role'] ?? 'عضو', approved: j['approved'] ?? true, joinedAt: j['joinedAt']);
}

class AccessRequest {
  String id;
  String name;
  String phone;
  String note;
  String status;
  String createdAt;
  AccessRequest({required this.id, required this.name, this.phone = '', this.note = '', this.status = 'در انتظار', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'note': note, 'status': status, 'createdAt': createdAt};
  factory AccessRequest.fromJson(Map<String, dynamic> j) => AccessRequest(id: j['id'] ?? _uuid.v4(), name: j['name'] ?? '', phone: j['phone'] ?? '', note: j['note'] ?? '', status: j['status'] ?? 'در انتظار', createdAt: j['createdAt']);
}

class ActivityLog {
  String id;
  String text;
  String actor;
  String createdAt;
  ActivityLog({required this.id, required this.text, this.actor = 'ادمین', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'actor': actor, 'createdAt': createdAt};
  factory ActivityLog.fromJson(Map<String, dynamic> j) => ActivityLog(id: j['id'] ?? _uuid.v4(), text: j['text'] ?? '', actor: j['actor'] ?? 'ادمین', createdAt: j['createdAt']);
}

class FamilyItem {
  String id;
  String title;
  String description;
  String personId;
  String type;
  String createdAt;
  FamilyItem({required this.id, required this.title, this.description = '', this.personId = '', this.type = 'photo', String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'description': description, 'personId': personId, 'type': type, 'createdAt': createdAt};
  factory FamilyItem.fromJson(Map<String, dynamic> j) => FamilyItem(id: j['id'] ?? _uuid.v4(), title: j['title'] ?? '', description: j['description'] ?? '', personId: j['personId'] ?? '', type: j['type'] ?? 'photo', createdAt: j['createdAt']);
}

class FamilyEvent {
  String id;
  String title;
  String date;
  String personId;
  String type;
  String notes;
  FamilyEvent({required this.id, required this.title, this.date = '', this.personId = '', this.type = 'رویداد', this.notes = ''});
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'date': date, 'personId': personId, 'type': type, 'notes': notes};
  factory FamilyEvent.fromJson(Map<String, dynamic> j) => FamilyEvent(id: j['id'] ?? _uuid.v4(), title: j['title'] ?? '', date: j['date'] ?? '', personId: j['personId'] ?? '', type: j['type'] ?? 'رویداد', notes: j['notes'] ?? '');
}

class ChatMessage {
  String id;
  String sender;
  String text;
  String createdAt;
  ChatMessage({required this.id, this.sender = 'ادمین', required this.text, String? createdAt}) : createdAt = createdAt ?? nowIso();
  Map<String, dynamic> toJson() => {'id': id, 'sender': sender, 'text': text, 'createdAt': createdAt};
  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(id: j['id'] ?? _uuid.v4(), sender: j['sender'] ?? 'ادمین', text: j['text'] ?? '', createdAt: j['createdAt']);
}

class Poll {
  String id;
  String question;
  List<String> options;
  Map<String, int> votes;
  bool secret;
  Poll({required this.id, required this.question, required this.options, Map<String, int>? votes, this.secret = false}) : votes = votes ?? {for (final o in options) o: 0};
  Map<String, dynamic> toJson() => {'id': id, 'question': question, 'options': options, 'votes': votes, 'secret': secret};
  factory Poll.fromJson(Map<String, dynamic> j) => Poll(id: j['id'] ?? _uuid.v4(), question: j['question'] ?? '', options: List<String>.from(j['options'] ?? []), votes: Map<String, int>.from(j['votes'] ?? {}), secret: j['secret'] ?? false);
}

class FamilyTree {
  String id;
  String code;
  String title;
  String ownerName;
  String ownerPhone;
  String branch;
  String createdAt;
  List<Person> people;
  List<TreeMember> members;
  List<AccessRequest> requests;
  List<ActivityLog> logs;
  List<FamilyItem> items;
  List<FamilyEvent> events;
  List<ChatMessage> chats;
  List<Poll> polls;

  FamilyTree({
    required this.id,
    required this.code,
    required this.title,
    required this.ownerName,
    this.ownerPhone = '',
    this.branch = '',
    String? createdAt,
    List<Person>? people,
    List<TreeMember>? members,
    List<AccessRequest>? requests,
    List<ActivityLog>? logs,
    List<FamilyItem>? items,
    List<FamilyEvent>? events,
    List<ChatMessage>? chats,
    List<Poll>? polls,
  })  : createdAt = createdAt ?? nowIso(),
        people = people ?? [],
        members = members ?? [],
        requests = requests ?? [],
        logs = logs ?? [],
        items = items ?? [],
        events = events ?? [],
        chats = chats ?? [],
        polls = polls ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'title': title,
        'ownerName': ownerName,
        'ownerPhone': ownerPhone,
        'branch': branch,
        'createdAt': createdAt,
        'people': people.map((e) => e.toJson()).toList(),
        'members': members.map((e) => e.toJson()).toList(),
        'requests': requests.map((e) => e.toJson()).toList(),
        'logs': logs.map((e) => e.toJson()).toList(),
        'items': items.map((e) => e.toJson()).toList(),
        'events': events.map((e) => e.toJson()).toList(),
        'chats': chats.map((e) => e.toJson()).toList(),
        'polls': polls.map((e) => e.toJson()).toList(),
      };

  factory FamilyTree.fromJson(Map<String, dynamic> j) => FamilyTree(
        id: j['id'] ?? _uuid.v4(),
        code: j['code'] ?? 'TREE-0000',
        title: j['title'] ?? 'شجره‌نامه',
        ownerName: j['ownerName'] ?? 'ادمین',
        ownerPhone: j['ownerPhone'] ?? '',
        branch: j['branch'] ?? '',
        createdAt: j['createdAt'],
        people: (j['people'] as List? ?? []).map((e) => Person.fromJson(Map<String, dynamic>.from(e))).toList(),
        members: (j['members'] as List? ?? []).map((e) => TreeMember.fromJson(Map<String, dynamic>.from(e))).toList(),
        requests: (j['requests'] as List? ?? []).map((e) => AccessRequest.fromJson(Map<String, dynamic>.from(e))).toList(),
        logs: (j['logs'] as List? ?? []).map((e) => ActivityLog.fromJson(Map<String, dynamic>.from(e))).toList(),
        items: (j['items'] as List? ?? []).map((e) => FamilyItem.fromJson(Map<String, dynamic>.from(e))).toList(),
        events: (j['events'] as List? ?? []).map((e) => FamilyEvent.fromJson(Map<String, dynamic>.from(e))).toList(),
        chats: (j['chats'] as List? ?? []).map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e))).toList(),
        polls: (j['polls'] as List? ?? []).map((e) => Poll.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class AppStore extends ChangeNotifier {
  static const storageKey = 'nasabnama_v3_full_local';
  List<FamilyTree> trees = [];
  String? activeTreeId;
  bool loaded = false;

  FamilyTree? get current {
    if (trees.isEmpty) return null;
    if (activeTreeId == null) return trees.first;
    return trees.firstWhere((e) => e.id == activeTreeId, orElse: () => trees.first);
  }

  Future<void> load() async {
    final pref = await SharedPreferences.getInstance();
    final raw = pref.getString(storageKey);
    if (raw != null && raw.trim().isNotEmpty) {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      activeTreeId = data['activeTreeId'];
      trees = (data['trees'] as List? ?? []).map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final pref = await SharedPreferences.getInstance();
    await pref.setString(storageKey, jsonEncode({'activeTreeId': activeTreeId, 'trees': trees.map((e) => e.toJson()).toList()}));
    notifyListeners();
  }

  String nextPersonCode(FamilyTree tree) {
    var maxNumber = 0;
    for (final person in tree.people) {
      final match = RegExp(r'FAM-(\d+)').firstMatch(person.code);
      if (match != null) {
        maxNumber = max(maxNumber, int.tryParse(match.group(1) ?? '0') ?? 0);
      }
    }
    return 'FAM-${(maxNumber + 1).toString().padLeft(6, '0')}';
  }
  String nextTreeCode() => 'TREE-${(trees.length + 1).toString().padLeft(4, '0')}';

  Future<void> createTree({required String title, required String owner, String phone = '', String branch = ''}) async {
    final tree = FamilyTree(id: _uuid.v4(), code: nextTreeCode(), title: title, ownerName: owner, ownerPhone: phone, branch: branch);
    tree.members.add(TreeMember(id: _uuid.v4(), name: owner, phone: phone, role: 'ادمین اصلی'));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'شجره ساخته شد', actor: owner));
    trees.add(tree);
    activeTreeId = tree.id;
    await save();
  }

  Future<void> selectTree(String id) async {
    activeTreeId = id;
    await save();
  }

  Future<String> addOrUpdatePerson(Person person, {String actor = 'ادمین'}) async {
    final tree = current;
    if (tree == null) return 'اول یک شجره بساز.';
    if (person.name.trim().isEmpty) return 'نام شخص خالی است.';
    final existingIndex = tree.people.indexWhere((e) => e.id == person.id);

    if (existingIndex == -1) {
      autoPlace(tree, person);
      person.code = nextPersonCode(tree);
      tree.people.add(person);
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'شخص ${person.name} اضافه شد', actor: actor));
      if (person.phone.trim().isNotEmpty) {
        tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'دعوت برای ${person.name} آماده است', actor: actor));
      }
    } else {
      autoPlace(tree, person);
      tree.people[existingIndex] = person;
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'اطلاعات ${person.name} ویرایش شد', actor: actor));
    }
    await save();
    return 'ثبت شد و در شجره نمایش داده می‌شود.';
  }

  void autoPlace(FamilyTree tree, Person person) {
    final fatherName = cleanText(person.fatherName);
    final grandName = cleanText(person.grandfatherName);
    if (fatherName.isEmpty) return;

    Person? grand;
    if (grandName.isNotEmpty) {
      grand = _findByNameAndFather(tree, person.grandfatherName, '');
      grand ??= _firstByName(tree, person.grandfatherName);
      if (grand == null) {
        grand = Person(
          id: _uuid.v4(),
          code: nextPersonCode(tree),
          name: person.grandfatherName.trim(),
          branch: person.branch,
          livingPlace: person.livingPlace,
          createdBy: 'سیستم',
        );
        tree.people.add(grand);
        tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'پدربزرگ ${grand.name} خودکار ساخته شد', actor: 'سیستم'));
      }
    }

    Person? father;
    if (person.fatherId != null) {
      father = tree.people.where((p) => p.id == person.fatherId).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);
      if (father != null && cleanText(father.name) != fatherName) father = null;
    }

    father ??= _findByNameAndFather(tree, person.fatherName, person.grandfatherName);
    father ??= tree.people.where((p) {
      if (cleanText(p.name) != fatherName) return false;
      if (grand == null) return true;
      return p.fatherId == grand.id || cleanText(p.fatherName) == grandName;
    }).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);

    if (father == null) {
      father = Person(
        id: _uuid.v4(),
        code: nextPersonCode(tree),
        name: person.fatherName.trim(),
        fatherName: grand?.name ?? person.grandfatherName.trim(),
        fatherId: grand?.id,
        branch: person.branch,
        livingPlace: person.livingPlace,
        createdBy: 'سیستم',
      );
      tree.people.add(father);
      tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'پدر ${father.name} خودکار ساخته شد', actor: 'سیستم'));
    } else if (grand != null) {
      father.fatherId ??= grand.id;
      father.fatherName = grand.name;
      if (father.branch.trim().isEmpty && person.branch.trim().isNotEmpty) father.branch = person.branch;
    }

    person.fatherId = father.id;
    person.fatherName = father.name;
    if (grand != null) person.grandfatherName = grand.name;
  }



  List<String> splitFamilyNames(String raw) {
    return raw
        .replaceAll('\n', '،')
        .replaceAll(',', '،')
        .split(RegExp(r'\s*،\s*|\s+و\s*'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  List<Person> findFamilyHeadCandidates(String headName, String headFatherName, {String headGrandfatherName = ''}) {
    final tree = current;
    if (tree == null) return [];
    final n = cleanText(headName);
    final f = cleanText(headFatherName);
    final g = cleanText(headGrandfatherName);
    if (n.isEmpty) return [];
    return tree.people.where((p) {
      if (cleanText(p.name) != n) return false;
      if (f.isEmpty) return true;
      final father = personById(p.fatherId);
      final fatherOk = cleanText(p.fatherName) == f || cleanText(father?.name ?? '') == f;
      if (!fatherOk) return false;
      if (g.isEmpty) return true;
      final grand = personById(father?.fatherId);
      return cleanText(p.grandfatherName) == g || cleanText(father?.fatherName ?? '') == g || cleanText(grand?.name ?? '') == g;
    }).toList();
  }

  Person? _firstByName(FamilyTree tree, String name) {
    final n = cleanText(name);
    if (n.isEmpty) return null;
    for (final p in tree.people) {
      if (cleanText(p.name) == n) return p;
    }
    return null;
  }

  Person? _findByNameAndFather(FamilyTree tree, String name, String fatherName, {String grandfatherName = ''}) {
    final n = cleanText(name);
    final f = cleanText(fatherName);
    final g = cleanText(grandfatherName);
    if (n.isEmpty) return null;
    for (final p in tree.people) {
      if (cleanText(p.name) != n) continue;
      if (f.isEmpty) return p;
      final father = tree.people.where((x) => x.id == p.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
      final fatherOk = cleanText(p.fatherName) == f || cleanText(father?.name ?? '') == f;
      if (!fatherOk) continue;
      if (g.isEmpty) return p;
      final grand = tree.people.where((x) => x.id == father?.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
      if (cleanText(p.grandfatherName) == g || cleanText(father?.fatherName ?? '') == g || cleanText(grand?.name ?? '') == g) return p;
    }
    return null;
  }

  Person? _findExistingChild(FamilyTree tree, String childName, Person father) {
    final childClean = cleanText(childName);
    for (final p in tree.people) {
      final sameName = cleanText(p.name) == childClean;
      final sameFather = p.fatherId == father.id || cleanText(p.fatherName) == cleanText(father.name);
      if (sameName && sameFather) return p;
    }
    return null;
  }

  Person? _findExistingSpouse(FamilyTree tree, String spouseName, Person head, String spouseFatherName) {
    final spouseClean = cleanText(spouseName);
    final spouseFatherClean = cleanText(spouseFatherName);
    for (final p in tree.people) {
      if (cleanText(p.name) != spouseClean) continue;
      final alreadyLinked = p.spouseId == head.id || head.spouseId == p.id || cleanText(p.spouseName) == cleanText(head.name);
      final fatherMatches = spouseFatherClean.isEmpty || cleanText(p.fatherName) == spouseFatherClean;
      if (alreadyLinked || fatherMatches) return p;
    }
    return null;
  }

  void _mergeInto(FamilyTree tree, Person keep, Person remove) {
    if (keep.id == remove.id) return;
    if (keep.phone.trim().isEmpty) keep.phone = remove.phone;
    if (keep.fatherName.trim().isEmpty) keep.fatherName = remove.fatherName;
    if (keep.grandfatherName.trim().isEmpty) keep.grandfatherName = remove.grandfatherName;
    if (keep.motherName.trim().isEmpty) keep.motherName = remove.motherName;
    if (keep.fatherId == null) keep.fatherId = remove.fatherId;
    if (keep.motherId == null) keep.motherId = remove.motherId;
    if (keep.spouseId == null) keep.spouseId = remove.spouseId;
    if (keep.spouseName.trim().isEmpty) keep.spouseName = remove.spouseName;
    if (keep.branch.trim().isEmpty) keep.branch = remove.branch;
    if (keep.livingPlace.trim().isEmpty) keep.livingPlace = remove.livingPlace;
    if (keep.notes.trim().isEmpty) keep.notes = remove.notes;
    for (final p in tree.people) {
      if (p.fatherId == remove.id) p.fatherId = keep.id;
      if (p.motherId == remove.id) p.motherId = keep.id;
      if (p.spouseId == remove.id) p.spouseId = keep.id;
      if (cleanText(p.fatherName) == cleanText(remove.name) && p.fatherId == keep.id) p.fatherName = keep.name;
      if (cleanText(p.motherName) == cleanText(remove.name) && p.motherId == keep.id) p.motherName = keep.name;
      if (cleanText(p.spouseName) == cleanText(remove.name) && p.spouseId == keep.id) p.spouseName = keep.name;
    }
    tree.people.removeWhere((p) => p.id == remove.id);
  }

  int dedupeSmart(FamilyTree tree) {
    var removed = 0;
    var changed = true;
    while (changed) {
      changed = false;
      outer:
      for (var i = 0; i < tree.people.length; i++) {
        for (var j = i + 1; j < tree.people.length; j++) {
          final a = tree.people[i];
          final b = tree.people[j];
          if (cleanText(a.name) != cleanText(b.name)) continue;
          final sameFatherId = a.fatherId != null && a.fatherId == b.fatherId;
          final sameFatherName = cleanText(a.fatherName) == cleanText(b.fatherName) && cleanText(a.grandfatherName) == cleanText(b.grandfatherName);
          final bothRootSame = (a.fatherId == null && b.fatherId == null && cleanText(a.fatherName).isEmpty && cleanText(b.fatherName).isEmpty);
          if (sameFatherId || sameFatherName || bothRootSame) {
            final keep = a.code.compareTo(b.code) <= 0 ? a : b;
            final remove = keep.id == a.id ? b : a;
            _mergeInto(tree, keep, remove);
            removed++;
            changed = true;
            break outer;
          }
        }
      }
    }
    if (removed > 0) tree.logs.add(ActivityLog(id: _uuid.v4(), text: '$removed شخص تکراری خودکار ادغام شد', actor: 'سیستم'));
    return removed;
  }

  Future<String> addFullFamily({
    required String headName,
    required String headFatherName,
    String headGrandfatherName = '',
    String headPhone = '',
    required String spouseName,
    String spouseFatherName = '',
    String spousePhone = '',
    String sonsRaw = '',
    String daughtersRaw = '',
    String branch = '',
    String livingPlace = '',
    String notes = '',
    String? selectedHeadId,
    String actor = 'ادمین',
  }) async {
    final tree = current;
    if (tree == null) return 'اول یک شجره بساز.';
    if (headName.trim().isEmpty) return 'نام پدر خانواده خالی است.';

    final candidates = findFamilyHeadCandidates(headName, headFatherName, headGrandfatherName: headGrandfatherName);
    Person? head;
    if (selectedHeadId != null && selectedHeadId.isNotEmpty) {
      head = tree.people.where((p) => p.id == selectedHeadId).cast<Person?>().firstWhere((p) => p != null, orElse: () => null);
    } else if (candidates.length == 1) {
      head = candidates.first;
    } else if (candidates.length > 1) {
      return 'چند شخص مشابه پیدا شد. قبل از ثبت، جایگاه دقیق پدر خانواده را انتخاب کن.';
    }

    var createdCount = 0;
    var updatedCount = 0;
    if (head == null) {
      head = Person(
        id: _uuid.v4(),
        code: '',
        name: headName.trim(),
        fatherName: headFatherName.trim(),
        grandfatherName: headGrandfatherName.trim(),
        phone: headPhone.trim(),
        gender: 'مرد',
        branch: branch.trim(),
        livingPlace: livingPlace.trim(),
        notes: notes.trim(),
        createdBy: actor,
      );
      autoPlace(tree, head);
      head.code = nextPersonCode(tree);
      tree.people.add(head);
      createdCount++;
    } else {
      if (headFatherName.trim().isNotEmpty) head.fatherName = headFatherName.trim();
      if (headGrandfatherName.trim().isNotEmpty) head.grandfatherName = headGrandfatherName.trim();
      if (headPhone.trim().isNotEmpty) head.phone = headPhone.trim();
      if (branch.trim().isNotEmpty) head.branch = branch.trim();
      if (livingPlace.trim().isNotEmpty) head.livingPlace = livingPlace.trim();
      if (notes.trim().isNotEmpty) head.notes = notes.trim();
      autoPlace(tree, head);
      updatedCount++;
    }

    final Person headPerson = head!;
    Person? spouse;
    if (spouseName.trim().isNotEmpty) {
      spouse = _findExistingSpouse(tree, spouseName, headPerson, spouseFatherName);
      if (spouse == null) {
        spouse = Person(
          id: _uuid.v4(),
          code: '',
          name: spouseName.trim(),
          fatherName: spouseFatherName.trim(),
          phone: spousePhone.trim(),
          gender: 'زن',
          branch: branch.trim(),
          livingPlace: livingPlace.trim(),
          createdBy: actor,
        );
        autoPlace(tree, spouse);
        spouse.code = nextPersonCode(tree);
        tree.people.add(spouse);
        createdCount++;
      } else {
        if (spouseFatherName.trim().isNotEmpty) spouse.fatherName = spouseFatherName.trim();
        if (spousePhone.trim().isNotEmpty) spouse.phone = spousePhone.trim();
        if (branch.trim().isNotEmpty) spouse.branch = branch.trim();
        if (livingPlace.trim().isNotEmpty) spouse.livingPlace = livingPlace.trim();
        autoPlace(tree, spouse);
        updatedCount++;
      }
      headPerson.spouseId = spouse.id;
      headPerson.spouseName = spouse.name;
      spouse.spouseId = headPerson.id;
      spouse.spouseName = headPerson.name;
    }

    void addChildren(List<String> names, String gender) {
      for (final childName in names) {
        final existing = _findExistingChild(tree, childName, headPerson);
        if (existing == null) {
          final child = Person(
            id: _uuid.v4(),
            code: nextPersonCode(tree),
            name: childName,
            fatherName: headPerson.name,
            grandfatherName: headPerson.fatherName,
            motherName: spouse?.name ?? '',
            fatherId: headPerson.id,
            motherId: spouse?.id,
            gender: gender,
            branch: branch.trim().isNotEmpty ? branch.trim() : headPerson.branch,
            livingPlace: livingPlace.trim(),
            createdBy: actor,
          );
          tree.people.add(child);
          createdCount++;
        } else {
          existing.fatherId = headPerson.id;
          existing.fatherName = headPerson.name;
          existing.grandfatherName = headPerson.fatherName;
          existing.motherId = spouse?.id ?? existing.motherId;
          existing.motherName = spouse?.name ?? existing.motherName;
          existing.gender = gender;
          if (branch.trim().isNotEmpty) existing.branch = branch.trim();
          if (livingPlace.trim().isNotEmpty) existing.livingPlace = livingPlace.trim();
          updatedCount++;
        }
      }
    }

    addChildren(splitFamilyNames(sonsRaw), 'مرد');
    addChildren(splitFamilyNames(daughtersRaw), 'زن');

    final deduped = dedupeSmart(tree);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'خانواده ${headPerson.name}${spouse == null ? '' : ' و ${spouse.name}'} یک‌جا ثبت شد؛ $createdCount مورد جدید، $updatedCount مورد به‌روزرسانی، $deduped تکراری ادغام شد', actor: actor));
    await save();
    return 'خانواده ثبت شد؛ $createdCount شخص جدید، $updatedCount به‌روزرسانی و $deduped تکراری ادغام شد.';
  }

  Person? _findByName(FamilyTree tree, String cleanedName) {
    for (final p in tree.people) {
      if (cleanText(p.name) == cleanedName) return p;
    }
    return null;
  }

  List<Person> searchPeople(String q) {
    final tree = current;
    if (tree == null) return [];
    final c = cleanText(q);
    if (c.isEmpty) return tree.people;
    return tree.people.where((p) {
      return cleanText(p.name).contains(c) || cleanText(p.fatherName).contains(c) || cleanText(p.grandfatherName).contains(c) || cleanText(p.code).contains(c) || cleanText(p.branch).contains(c) || cleanText(p.phone).contains(c) || cleanText(p.livingPlace).contains(c);
    }).toList();
  }

  Person? personById(String? id) {
    final tree = current;
    if (tree == null || id == null) return null;
    for (final p in tree.people) {
      if (p.id == id) return p;
    }
    return null;
  }

  List<Person> childrenOf(String id) => current?.people.where((p) => p.fatherId == id || p.motherId == id).toList() ?? [];

  List<Person> siblingsOf(Person p) {
    final tree = current;
    if (tree == null || p.fatherId == null) return [];
    return tree.people.where((x) => x.id != p.id && x.fatherId == p.fatherId).toList();
  }

  List<String> ancestorPath(String personId) {
    final path = <String>[];
    var currentId = personId;
    final seen = <String>{};
    while (true) {
      if (seen.contains(currentId)) break;
      seen.add(currentId);
      final p = personById(currentId);
      if (p == null) break;
      path.add(p.id);
      if (p.fatherId == null || p.fatherId!.isEmpty) break;
      currentId = p.fatherId!;
    }
    return path;
  }

  String relationBetween(Person a, Person b) {
    if (a.id == b.id) return 'همان شخص است.';
    final pathA = ancestorPath(a.id);
    final pathB = ancestorPath(b.id);
    final indexAtoB = pathA.indexOf(b.id);
    if (indexAtoB == 1) return '${b.name} پدر ${a.name} است.';
    if (indexAtoB == 2) return '${b.name} پدربزرگ ${a.name} است.';
    if (indexAtoB > 2) return '${b.name} از اجداد ${a.name} است.';
    final indexBtoA = pathB.indexOf(a.id);
    if (indexBtoA == 1) return '${a.name} پدر ${b.name} است.';
    if (indexBtoA == 2) return '${a.name} پدربزرگ ${b.name} است.';
    if (indexBtoA > 2) return '${a.name} از اجداد ${b.name} است.';
    for (final x in pathA) {
      if (pathB.contains(x)) {
        final da = pathA.indexOf(x);
        final db = pathB.indexOf(x);
        if (da == 1 && db == 1) return '${a.name} و ${b.name} خواهر/برادر یا هم‌نسل از یک پدر هستند.';
        if (da == 2 && db == 2) return '${a.name} و ${b.name} پسرعمو/دخترعمو یا هم‌نسل از یک پدربزرگ هستند.';
        return 'نسبت از طریق جد مشترک پیدا شد. فاصله نسل‌ها: $da و $db';
      }
    }
    return 'نسبت مستقیم پیدا نشد.';
  }

  List<List<Person>> duplicateGroups() {
    final tree = current;
    if (tree == null) return [];
    final map = <String, List<Person>>{};
    for (final p in tree.people) {
      final key = '${cleanText(p.name)}|${cleanText(p.fatherName)}|${cleanText(p.grandfatherName)}';
      map.putIfAbsent(key, () => []).add(p);
    }
    return map.values.where((g) => g.length > 1).toList();
  }

  Future<void> mergePersons(Person keep, Person remove) async {
    final tree = current;
    if (tree == null) return;
    for (final p in tree.people) {
      if (p.fatherId == remove.id) p.fatherId = keep.id;
      if (p.motherId == remove.id) p.motherId = keep.id;
    }
    tree.people.removeWhere((p) => p.id == remove.id);
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '${remove.name} با ${keep.name} ادغام شد', actor: 'ادمین'));
    await save();
  }

  Future<void> addMember(String name, String phone, String role, {bool approved = true}) async {
    final tree = current;
    if (tree == null) return;
    tree.members.add(TreeMember(id: _uuid.v4(), name: name, phone: phone, role: role, approved: approved));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'عضو $name با نقش $role اضافه شد'));
    await save();
  }

  Future<void> addRequest(String name, String phone, String note) async {
    final tree = current;
    if (tree == null) return;
    tree.requests.add(AccessRequest(id: _uuid.v4(), name: name, phone: phone, note: note));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'درخواست عضویت $name ثبت شد'));
    await save();
  }

  Future<void> approveRequest(AccessRequest r) async {
    final tree = current;
    if (tree == null) return;
    r.status = 'تأیید شده';
    tree.members.add(TreeMember(id: _uuid.v4(), name: r.name, phone: r.phone, role: 'عضو', approved: true));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'درخواست ${r.name} تأیید شد'));
    await save();
  }

  Future<void> addItem(String title, String description, String type, String personId) async {
    final tree = current;
    if (tree == null) return;
    tree.items.add(FamilyItem(id: _uuid.v4(), title: title, description: description, type: type, personId: personId));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: '$type جدید ثبت شد: $title'));
    await save();
  }

  Future<void> addEvent(String title, String date, String type, String notes, String personId) async {
    final tree = current;
    if (tree == null) return;
    tree.events.add(FamilyEvent(id: _uuid.v4(), title: title, date: date, type: type, notes: notes, personId: personId));
    tree.logs.add(ActivityLog(id: _uuid.v4(), text: 'رویداد جدید: $title'));
    await save();
  }

  Future<void> addChat(String sender, String text) async {
    final tree = current;
    if (tree == null) return;
    tree.chats.add(ChatMessage(id: _uuid.v4(), sender: sender, text: text));
    await save();
  }

  Future<void> addPoll(String question, List<String> options, bool secret) async {
    final tree = current;
    if (tree == null) return;
    tree.polls.add(Poll(id: _uuid.v4(), question: question, options: options, secret: secret));
    await save();
  }

  Future<void> vote(Poll poll, String option) async {
    poll.votes[option] = (poll.votes[option] ?? 0) + 1;
    await save();
  }

  String backupJson() => jsonEncode({'activeTreeId': activeTreeId, 'trees': trees.map((e) => e.toJson()).toList()});

  Future<String> importBackup(String raw) async {
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      trees = (data['trees'] as List? ?? []).map((e) => FamilyTree.fromJson(Map<String, dynamic>.from(e))).toList();
      activeTreeId = data['activeTreeId'];
      await save();
      return 'بازیابی انجام شد.';
    } catch (e) {
      return 'فایل/متن پشتیبان معتبر نیست.';
    }
  }

  Future<void> deleteAll() async {
    trees.clear();
    activeTreeId = null;
    await save();
  }
}

class NasabNamaApp extends StatefulWidget {
  const NasabNamaApp({super.key});
  @override
  State<NasabNamaApp> createState() => _NasabNamaAppState();
}

class _NasabNamaAppState extends State<NasabNamaApp> {
  final store = AppStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return StoreProvider(
      store: store,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'نسب‌نامه',
        theme: ThemeData(
          useMaterial3: true,
          fontFamily: 'sans',
          scaffoldBackgroundColor: C.bg,
          colorScheme: ColorScheme.fromSeed(seedColor: C.blue, brightness: Brightness.light),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: C.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: C.blue, width: 1.4)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const AppShell(),
      ),
    );
  }
}

class StoreProvider extends InheritedNotifier<AppStore> {
  const StoreProvider({super.key, required AppStore store, required Widget child}) : super(notifier: store, child: child);
  static AppStore of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<StoreProvider>()!.notifier!;
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          HomePage(onNavigate: (i) => setState(() => index = i)),
          const TreePage(),
          const AddPersonPage(),
          const SearchPage(),
          const MorePage(),
        ];
        return Scaffold(
          resizeToAvoidBottomInset: true,
          body: pages[index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (i) => setState(() => index = i),
            backgroundColor: C.white,
            indicatorColor: C.mint,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
              NavigationDestination(icon: Icon(Icons.account_tree_outlined), selectedIcon: Icon(Icons.account_tree), label: 'شجره'),
              NavigationDestination(icon: Icon(Icons.person_add_alt_1_outlined), selectedIcon: Icon(Icons.person_add_alt_1), label: 'افزودن'),
              NavigationDestination(icon: Icon(Icons.search), label: 'جستجو'),
              NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'امکانات'),
            ],
          ),
        );
      },
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const AppHeader(title: 'نسب‌نامه', subtitle: 'مدیریت هوشمند شجره‌نامه خانوادگی'),
            const SizedBox(height: 14),
            if (tree == null) EmptyState(onCreate: () => showTreeDialog(context)) else ...[
              TreeSwitcher(store: store),
              const SizedBox(height: 12),
              HeroCard(tree: tree),
              const SizedBox(height: 12),
              StatsGrid(tree: tree),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: QuickButton(title: 'دیدن شجره', icon: Icons.account_tree, color: C.blue, onTap: () => onNavigate(1))),
                const SizedBox(width: 10),
                Expanded(child: QuickButton(title: 'افزودن شخص', icon: Icons.person_add, color: C.green, onTap: () => onNavigate(2))),
              ]),
              const SizedBox(height: 10),
              QuickButton(title: 'افزودن خانواده کامل', icon: Icons.group_add_rounded, color: C.green, onTap: () => push(context, const FullFamilyEntryPage())),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: QuickButton(title: 'جستجو', icon: Icons.search, color: C.gold, onTap: () => onNavigate(3))),
                const SizedBox(width: 10),
                Expanded(child: QuickButton(title: 'دعوت عضو', icon: Icons.ios_share, color: C.red, onTap: () => shareTreeInvite(context, tree))),
              ]),
              const SizedBox(height: 16),
              SectionTitle(title: 'آخرین تغییرات', action: 'همه امکانات'),
              ...tree.logs.reversed.take(5).map((e) => LogTile(log: e)),
            ],
          ],
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final VoidCallback onCreate;
  const EmptyState({super.key, required this.onCreate});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      child: Column(
        children: [
          const Icon(Icons.family_restroom, size: 72, color: C.green),
          const SizedBox(height: 12),
          const Text('هنوز شجره‌ای ساخته نشده', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 8),
          const Text('اول یک شجره بساز. بعد افراد را با نام پدر و پدربزرگ اضافه کن تا اپ جایگاهشان را خودش تشخیص دهد.', textAlign: TextAlign.center, style: TextStyle(color: C.muted, height: 1.8)),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: onCreate, icon: const Icon(Icons.add), label: const Text('ساخت شجره جدید')),
        ],
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const AppHeader({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.green, C.blue]), borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 18, offset: Offset(0, 8))]),
          child: const Icon(Icons.account_tree_rounded, color: Colors.white),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.ink)), Text(subtitle, style: const TextStyle(color: C.muted))])),
      ],
    );
  }
}

class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const PremiumCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(26),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            color: C.white,
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: Colors.white.withOpacity(.8)),
            boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 24, offset: Offset(0, 12))],
          ),
          child: child,
        ),
      ),
    );
  }
}

class TreeSwitcher extends StatelessWidget {
  final AppStore store;
  const TreeSwitcher({super.key, required this.store});
  @override
  Widget build(BuildContext context) {
    final current = store.current;
    return Row(
      children: [
        Expanded(
          child: PremiumCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: current?.id,
                isExpanded: true,
                icon: const Icon(Icons.keyboard_arrow_down),
                items: store.trees.map((e) => DropdownMenuItem(value: e.id, child: Text(e.title, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (v) => v == null ? null : store.selectTree(v),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        IconButton.filledTonal(onPressed: () => showTreeDialog(context), icon: const Icon(Icons.add)),
      ],
    );
  }
}

class HeroCard extends StatelessWidget {
  final FamilyTree tree;
  const HeroCard({super.key, required this.tree});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [C.cream, C.sky, C.mint]),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 28, offset: Offset(0, 14))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(radius: 28, backgroundColor: C.white, child: Icon(Icons.family_restroom, color: C.green, size: 32)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tree.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)), Text('ادمین اصلی: ${tree.ownerName}', style: const TextStyle(color: C.muted))])),
          Chip(label: Text(tree.code), backgroundColor: C.white),
        ]),
        const SizedBox(height: 14),
        Text(tree.branch.isEmpty ? 'شاخه خانوادگی ثبت نشده' : 'شاخه: ${tree.branch}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        LinearProgressIndicator(value: min(1, tree.people.length / 30), minHeight: 8, borderRadius: BorderRadius.circular(10), backgroundColor: Colors.white, color: C.green),
        const SizedBox(height: 8),
        Text('${tree.people.length} نفر ثبت شده؛ برای کامل شدن شجره، اعضا را دعوت کن.', style: const TextStyle(color: C.muted)),
      ]),
    );
  }
}

class StatsGrid extends StatelessWidget {
  final FamilyTree tree;
  const StatsGrid({super.key, required this.tree});
  int generations() {
    var maxDepth = 0;
    final byId = {for (final p in tree.people) p.id: p};
    for (final p in tree.people) {
      var depth = 1;
      var f = p.fatherId;
      final seen = <String>{};
      while (f != null && byId.containsKey(f) && !seen.contains(f)) {
        seen.add(f);
        depth++;
        f = byId[f]!.fatherId;
      }
      maxDepth = max(maxDepth, depth);
    }
    return maxDepth;
  }

  @override
  Widget build(BuildContext context) {
    final male = tree.people.where((p) => p.gender == 'مرد').length;
    final female = tree.people.where((p) => p.gender == 'زن').length;
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.95,
      children: [
        StatTile(label: 'افراد', value: '${tree.people.length}', icon: Icons.groups, color: C.blue),
        StatTile(label: 'نسل‌ها', value: '${generations()}', icon: Icons.account_tree, color: C.green),
        StatTile(label: 'اعضا', value: '${tree.members.length}', icon: Icons.verified_user, color: C.gold),
        StatTile(label: 'زن / مرد', value: '$female / $male', icon: Icons.pie_chart, color: C.red),
      ],
    );
  }
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const StatTile({super.key, required this.label, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(13),
      child: Row(children: [
        CircleAvatar(backgroundColor: color.withOpacity(.14), child: Icon(icon, color: color)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: C.ink)), Text(label, style: const TextStyle(color: C.muted))])),
      ]),
    );
  }
}

class QuickButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const QuickButton({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.13), child: Icon(icon, color: color)), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: C.ink)))]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? action;
  const SectionTitle({super.key, required this.title, this.action});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: C.ink))), if (action != null) Text(action!, style: const TextStyle(color: C.blue, fontWeight: FontWeight.w700))]));
}

class LogTile extends StatelessWidget {
  final ActivityLog log;
  const LogTile({super.key, required this.log});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 8), child: PremiumCard(padding: const EdgeInsets.all(12), child: Row(children: [const Icon(Icons.history, color: C.green), const SizedBox(width: 10), Expanded(child: Text(log.text, style: const TextStyle(fontWeight: FontWeight.w700))), Text(shortDate(log.createdAt), style: const TextStyle(color: C.muted, fontSize: 12))])));
}

Future<void> showTreeDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final owner = TextEditingController();
  final phone = TextEditingController();
  final branch = TextEditingController();
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => FormSheet(
      title: 'ساخت شجره جدید',
      children: [
        AppField(controller: title, label: 'نام شجره', hint: 'مثلاً خانواده کدخدایی'),
        AppField(controller: owner, label: 'نام ادمین اصلی', hint: 'نام شما'),
        AppField(controller: phone, label: 'شماره ادمین', keyboard: TextInputType.phone),
        AppField(controller: branch, label: 'شاخه / طایفه', hint: 'اختیاری'),
        FilledButton.icon(
          onPressed: () async {
            if (title.text.trim().isEmpty || owner.text.trim().isEmpty) return;
            await store.createTree(title: title.text, owner: owner.text, phone: phone.text, branch: branch.text);
            if (context.mounted) Navigator.pop(context);
          },
          icon: const Icon(Icons.check),
          label: const Text('ثبت شجره'),
        ),
      ],
    ),
  );
}

class FormSheet extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const FormSheet({super.key, required this.title, required this.children});
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .9),
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      decoration: const BoxDecoration(color: C.bg, borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: C.muted.withOpacity(.25), borderRadius: BorderRadius.circular(9)))),
          const SizedBox(height: 14),
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 12),
          ...children.map((e) => Padding(padding: const EdgeInsets.only(bottom: 10), child: e)),
        ]),
      ),
    );
  }
}

class AppField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final TextInputType? keyboard;
  final int maxLines;
  const AppField({super.key, required this.controller, required this.label, this.hint, this.keyboard, this.maxLines = 1});
  @override
  Widget build(BuildContext context) => TextField(controller: controller, keyboardType: keyboard, maxLines: maxLines, decoration: InputDecoration(labelText: label, hintText: hint));
}

void shareTreeInvite(BuildContext context, FamilyTree tree) {
  final link = 'https://nasabnama.local/invite/${tree.code}';
  final text = '''سلام 🌿
شما برای مشاهده و تکمیل شجره‌نامه «${tree.title}» دعوت شده‌اید.

لینک دعوت:
$link

کد دعوت:
${tree.code}

لطفاً اطلاعاتی که از خانواده می‌دانید را ثبت کنید تا شجره‌نامه کامل‌تر شود.''';
  Share.share(text, subject: 'دعوت به شجره‌نامه ${tree.title}');
}

class AddPersonPage extends StatefulWidget {
  final Person? editPerson;
  const AddPersonPage({super.key, this.editPerson});
  @override
  State<AddPersonPage> createState() => _AddPersonPageState();
}

class _AddPersonPageState extends State<AddPersonPage> {
  final name = TextEditingController();
  final father = TextEditingController();
  final grand = TextEditingController();
  final mother = TextEditingController();
  final phone = TextEditingController();
  final branch = TextEditingController();
  final birth = TextEditingController();
  final death = TextEditingController();
  final birthPlace = TextEditingController();
  final livingPlace = TextEditingController();
  final notes = TextEditingController();
  final special = TextEditingController();
  String gender = 'نامشخص';
  bool phonePrivate = true;

  @override
  void initState() {
    super.initState();
    final p = widget.editPerson;
    if (p != null) {
      name.text = p.name;
      father.text = p.fatherName;
      grand.text = p.grandfatherName;
      mother.text = p.motherName;
      phone.text = p.phone;
      branch.text = p.branch;
      birth.text = p.birthDate;
      death.text = p.deathDate;
      birthPlace.text = p.birthPlace;
      livingPlace.text = p.livingPlace;
      notes.text = p.notes;
      special.text = p.specialTag;
      gender = p.gender;
      phonePrivate = p.phonePrivate;
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final hasTree = store.current != null;
    return SafeArea(
      child: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 28),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          AppHeader(title: widget.editPerson == null ? 'افزودن شخص' : 'ویرایش شخص', subtitle: 'با نام پدر و پدربزرگ، جایگاه فرد خودکار پیدا می‌شود'),
          const SizedBox(height: 12),
          if (!hasTree) EmptyState(onCreate: () => showTreeDialog(context)) else PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const HelpBox(text: 'حداقل نام شخص را وارد کن. اگر نام پدر و پدربزرگ را بنویسی، اپ پدر/پدربزرگ را پیدا می‌کند یا در صورت نبود، شاخه را خودکار می‌سازد.'),
            const SizedBox(height: 12),
            AppField(controller: name, label: 'نام شخص *'),
            AppField(controller: father, label: 'نام پدر'),
            AppField(controller: grand, label: 'نام پدربزرگ'),
            AppField(controller: mother, label: 'نام مادر'),
            DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'جنسیت'), items: const ['نامشخص', 'مرد', 'زن'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => gender = v ?? 'نامشخص')),
            const SizedBox(height: 10),
            AppField(controller: phone, label: 'شماره تماس', keyboard: TextInputType.phone),
            SwitchListTile(contentPadding: EdgeInsets.zero, value: phonePrivate, onChanged: (v) => setState(() => phonePrivate = v), title: const Text('شماره تماس خصوصی باشد'), subtitle: const Text('فقط ادمین‌ها ببینند')),
            AppField(controller: branch, label: 'شاخه خانوادگی'),
            Row(children: [Expanded(child: AppField(controller: birth, label: 'تاریخ تولد')), const SizedBox(width: 8), Expanded(child: AppField(controller: death, label: 'تاریخ فوت'))]),
            AppField(controller: birthPlace, label: 'محل تولد'),
            AppField(controller: livingPlace, label: 'محل زندگی'),
            AppField(controller: special, label: 'عنوان ویژه', hint: 'ریش‌سفید، استاد، شهید، پزشک و...'),
            AppField(controller: notes, label: 'توضیحات', maxLines: 4),
            const SizedBox(height: 8),
            FilledButton.icon(onPressed: () async {
              final base = widget.editPerson?.copy();
              final p = base ?? Person(id: _uuid.v4(), code: '', name: '');
              p.name = name.text.trim();
              p.fatherName = father.text.trim();
              p.grandfatherName = grand.text.trim();
              p.motherName = mother.text.trim();
              p.phone = phone.text.trim();
              p.gender = gender;
              p.branch = branch.text.trim();
              p.birthDate = birth.text.trim();
              p.deathDate = death.text.trim();
              p.birthPlace = birthPlace.text.trim();
              p.livingPlace = livingPlace.text.trim();
              p.notes = notes.text.trim();
              p.specialTag = special.text.trim();
              p.phonePrivate = phonePrivate;
              final msg = await store.addOrUpdatePerson(p);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
                if (widget.editPerson != null) Navigator.pop(context);
                if (widget.editPerson == null && msg.startsWith('ثبت')) {
                  name.clear(); father.clear(); grand.clear(); mother.clear(); phone.clear(); branch.clear(); birth.clear(); death.clear(); birthPlace.clear(); livingPlace.clear(); notes.clear(); special.clear();
                }
              }
            }, icon: const Icon(Icons.save), label: const Text('ذخیره شخص')),
          ])),
        ]),
      ),
    );
  }
}

class HelpBox extends StatelessWidget {
  final String text;
  const HelpBox({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: C.sky, borderRadius: BorderRadius.circular(18)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.help_outline, color: C.blue), const SizedBox(width: 8), Expanded(child: Text(text, style: const TextStyle(color: C.ink, height: 1.7)))]));
}

class TreePage extends StatelessWidget {
  const TreePage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    return SafeArea(
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: AppHeader(title: 'نمای شجره', subtitle: 'با دو انگشت زوم کن و صفحه را جابه‌جا کن')),
        if (tree == null) Expanded(child: Center(child: EmptyState(onCreate: () => showTreeDialog(context)))) else Expanded(child: tree.people.isEmpty ? const Center(child: Text('هنوز شخصی ثبت نشده است.')) : FamilyTreeCanvas(tree: tree, store: store)),
      ]),
    );
  }
}

String? effectiveFatherIdInTree(FamilyTree tree, Person person) {
  final ids = tree.people.map((e) => e.id).toSet();
  if (person.fatherId != null && ids.contains(person.fatherId)) return person.fatherId;
  final f = cleanText(person.fatherName);
  if (f.isEmpty) return null;
  final g = cleanText(person.grandfatherName);
  for (final candidate in tree.people) {
    if (candidate.id == person.id) continue;
    if (cleanText(candidate.name) != f) continue;
    if (g.isEmpty || cleanText(candidate.fatherName) == g) return candidate.id;
    final grand = tree.people.where((x) => x.id == candidate.fatherId).cast<Person?>().firstWhere((x) => x != null, orElse: () => null);
    if (cleanText(grand?.name ?? '') == g) return candidate.id;
  }
  return null;
}

class FamilyTreeCanvas extends StatelessWidget {
  final FamilyTree tree;
  final AppStore store;
  const FamilyTreeCanvas({super.key, required this.tree, required this.store});

  @override
  Widget build(BuildContext context) {
    final levels = buildLevels(tree);
    final positions = <String, Offset>{};
    const cardW = 146.0;
    const cardH = 92.0;
    const pairGap = 20.0;
    const groupGap = 44.0;
    const yGap = 150.0;

    final groupedLevels = levels.map((level) => groupLevel(level)).toList();
    double maxWidth = 900.0;
    for (final groups in groupedLevels) {
      double w = 80;
      for (var i = 0; i < groups.length; i++) {
        w += groups[i].length == 2 ? (cardW * 2 + pairGap) : cardW;
        if (i != groups.length - 1) w += groupGap;
      }
      if (w > maxWidth) maxWidth = w + 80;
    }
    final width = maxWidth;
    final height = max(700.0, levels.length * yGap + 220);

    for (var y = 0; y < groupedLevels.length; y++) {
      final groups = groupedLevels[y];
      double totalWidth = 0;
      for (var i = 0; i < groups.length; i++) {
        totalWidth += groups[i].length == 2 ? (cardW * 2 + pairGap) : cardW;
        if (i != groups.length - 1) totalWidth += groupGap;
      }
      var cursor = (width - totalWidth) / 2;
      for (final group in groups) {
        if (group.length == 2) {
          positions[group[0].id] = Offset(cursor, 60 + y * yGap);
          positions[group[1].id] = Offset(cursor + cardW + pairGap, 60 + y * yGap);
          cursor += cardW * 2 + pairGap + groupGap;
        } else {
          positions[group[0].id] = Offset(cursor, 60 + y * yGap);
          cursor += cardW + groupGap;
        }
      }
    }

    return Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: C.cream, borderRadius: BorderRadius.circular(26), border: Border.all(color: Colors.white, width: 2)),
      child: InteractiveViewer(
        constrained: false,
        minScale: .25,
        maxScale: 3.0,
        boundaryMargin: const EdgeInsets.all(600),
        child: SizedBox(
          width: width,
          height: height,
          child: Stack(children: [
            CustomPaint(size: Size(width, height), painter: TreeLinePainter(tree: tree, positions: positions, cardW: cardW, cardH: cardH)),
            ...tree.people.where((p) => positions.containsKey(p.id)).map((p) {
              final pos = positions[p.id]!;
              return Positioned(left: pos.dx, top: pos.dy, width: cardW, height: cardH, child: TreePersonCard(person: p, onTap: () => openPerson(context, p)));
            }),
          ]),
        ),
      ),
    );
  }

  List<List<Person>> groupLevel(List<Person> level) {
    final grouped = <List<Person>>[];
    final done = <String>{};
    for (final p in level) {
      if (done.contains(p.id)) continue;
      final spouse = firstWhereOrNull<Person>(tree.people, (e) => e.id == p.spouseId);
      final spouseInLevel = spouse != null && level.any((e) => e.id == spouse.id) && !done.contains(spouse.id);
      if (spouseInLevel) {
        final male = p.gender == 'مرد' ? p : spouse.gender == 'مرد' ? spouse : p;
        final female = male.id == p.id ? spouse : p;
        grouped.add([male, female]);
        done.add(male.id);
        done.add(female.id);
      } else {
        grouped.add([p]);
        done.add(p.id);
      }
    }
    return grouped;
  }

  List<List<Person>> buildLevels(FamilyTree tree) {
    final ids = tree.people.map((e) => e.id).toSet();
    var roots = tree.people.where((p) {
      final f = effectiveFatherIdInTree(tree, p);
      return f == null || !ids.contains(f);
    }).toList();
    if (roots.isEmpty) roots = [tree.people.first];
    final levels = <List<Person>>[];
    final visited = <String>{};
    var current = roots;
    while (current.isNotEmpty && levels.length < 20) {
      levels.add(current);
      visited.addAll(current.map((e) => e.id));
      final next = <Person>[];
      for (final p in current) {
        next.addAll(tree.people.where((c) => effectiveFatherIdInTree(tree, c) == p.id && !visited.contains(c.id)));
      }
      current = next;
    }
    final missing = tree.people.where((p) => !visited.contains(p.id)).toList();
    if (missing.isNotEmpty) levels.add(missing);
    return levels;
  }
}

class TreeLinePainter extends CustomPainter {
  final FamilyTree tree;
  final Map<String, Offset> positions;
  final double cardW;
  final double cardH;
  TreeLinePainter({required this.tree, required this.positions, required this.cardW, required this.cardH});
  @override
  void paint(Canvas canvas, Size size) {
    final relationPaint = Paint()..color = C.green.withOpacity(.60)..strokeWidth = 2.8..style = PaintingStyle.stroke;
    final spousePaint = Paint()..color = C.gold.withOpacity(.85)..strokeWidth = 2.8..style = PaintingStyle.stroke;

    final drawnSpouses = <String>{};
    for (final p in tree.people) {
      if (p.spouseId == null) continue;
      final spouse = firstWhereOrNull<Person>(tree.people, (e) => e.id == p.spouseId);
      if (spouse == null) continue;
      final key = [p.id, spouse.id]..sort();
      final pairKey = key.join('_');
      if (drawnSpouses.contains(pairKey)) continue;
      final a = positions[p.id];
      final b = positions[spouse.id];
      if (a == null || b == null) continue;
      final y = a.dy + cardH / 2;
      final start = Offset(min(a.dx, b.dx) + cardW, y);
      final end = Offset(max(a.dx, b.dx), y);
      canvas.drawLine(start, end, spousePaint);

      final labelText = TextPainter(
        text: const TextSpan(text: 'همسر', style: TextStyle(color: C.gold, fontSize: 11, fontWeight: FontWeight.w800)),
        textDirection: TextDirection.rtl,
      )..layout();
      final labelOffset = Offset((start.dx + end.dx) / 2 - labelText.width / 2, y - labelText.height - 4);
      final labelBg = RRect.fromRectAndRadius(Rect.fromLTWH(labelOffset.dx - 6, labelOffset.dy - 2, labelText.width + 12, labelText.height + 4), const Radius.circular(10));
      canvas.drawRRect(labelBg, Paint()..color = Colors.white.withOpacity(.92));
      labelText.paint(canvas, labelOffset);
      drawnSpouses.add(pairKey);
    }

    for (final p in tree.people) {
      final fatherId = effectiveFatherIdInTree(tree, p);
      if (fatherId == null) continue;
      final child = positions[p.id];
      final father = positions[fatherId];
      if (child == null || father == null) continue;

      Offset start = Offset(father.dx + cardW / 2, father.dy + cardH);
      final fatherPerson = firstWhereOrNull<Person>(tree.people, (e) => e.id == fatherId);
      if (fatherPerson != null && fatherPerson.spouseId != null) {
        final spousePos = positions[fatherPerson.spouseId!];
        if (spousePos != null) {
          final midX = (father.dx + spousePos.dx) / 2 + cardW / 2;
          start = Offset(midX, father.dy + cardH / 2);
        }
      }
      final end = Offset(child.dx + cardW / 2, child.dy);
      final midY = (start.dy + end.dy) / 2;
      final path = Path()
        ..moveTo(start.dx, start.dy)
        ..lineTo(start.dx, midY)
        ..lineTo(end.dx, midY)
        ..lineTo(end.dx, end.dy);
      canvas.drawPath(path, relationPaint);
    }
  }
  @override
  bool shouldRepaint(covariant TreeLinePainter oldDelegate) => true;
}

class TreePersonCard extends StatelessWidget {
  final Person person;
  final VoidCallback onTap;
  const TreePersonCard({super.key, required this.person, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final isFemale = person.gender == 'زن';
    final isMale = person.gender == 'مرد';
    final color = isFemale ? const Color(0xFFE87095) : isMale ? C.blue : C.green;
    final bg = isFemale ? const Color(0xFFFFEFF4) : isMale ? const Color(0xFFEFF6FF) : const Color(0xFFEFFAF5);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 14, offset: Offset(0, 7))],
            border: Border.all(color: color.withOpacity(.35)),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            CircleAvatar(radius: 15, backgroundColor: Colors.white.withOpacity(.8), child: Icon(isFemale ? Icons.female : isMale ? Icons.male : Icons.person, color: color, size: 18)),
            const SizedBox(height: 4),
            Text(person.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
            Text(person.fatherName.isEmpty ? person.code : 'فرزند ${person.fatherName}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: C.muted)),
          ]),
        ),
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final q = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final result = store.searchPeople(q.text);
    return SafeArea(
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Column(children: [const AppHeader(title: 'جستجوی هوشمند', subtitle: 'نام، نام پدر، پدربزرگ، کد شخص، شهر یا شماره'), const SizedBox(height: 12), TextField(controller: q, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'جستجو'))])),
        Expanded(child: result.isEmpty ? const Center(child: Text('نتیجه‌ای پیدا نشد.')) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: result.length, itemBuilder: (_, i) => PersonListTile(person: result[i]))),
      ]),
    );
  }
}

class PersonListTile extends StatelessWidget {
  final Person person;
  const PersonListTile({super.key, required this.person});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: PremiumCard(
        onTap: () => openPerson(context, person),
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          CircleAvatar(backgroundColor: C.mint, child: Text(person.name.isEmpty ? '?' : person.name.characters.first, style: const TextStyle(color: C.green, fontWeight: FontWeight.w900))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(person.name, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)), Text(person.fatherName.isEmpty ? person.code : 'فرزند ${person.fatherName} • ${person.code}', style: const TextStyle(color: C.muted, fontSize: 12))])),
          const Icon(Icons.chevron_left, color: C.muted),
        ]),
      ),
    );
  }
}

void openPerson(BuildContext context, Person p) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => PersonDetailsPage(personId: p.id)));
}

class PersonDetailsPage extends StatelessWidget {
  final String personId;
  const PersonDetailsPage({super.key, required this.personId});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return AnimatedBuilder(animation: store, builder: (_, __) {
      final p = store.personById(personId);
      if (p == null) return const Scaffold(body: Center(child: Text('شخص پیدا نشد.')));
      final father = store.personById(p.fatherId);
      final spouse = store.personById(p.spouseId);
      final children = store.childrenOf(p.id);
      final siblings = store.siblingsOf(p);
      final tree = store.current!;
      return Scaffold(
        appBar: AppBar(title: Text(p.name), actions: [IconButton(onPressed: () => sharePersonInvite(context, tree, p), icon: const Icon(Icons.ios_share)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddPersonPage(editPerson: p))), icon: const Icon(Icons.edit))]),
        body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.sky, C.cream, C.mint]), borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: C.shadow, blurRadius: 24, offset: Offset(0, 12))]),
            child: Column(children: [
              const CircleAvatar(radius: 42, backgroundColor: C.white, child: Icon(Icons.person, size: 48, color: C.green)),
              const SizedBox(height: 10),
              Text(p.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.ink)),
              Text(p.code, style: const TextStyle(color: C.muted)),
              if (p.specialTag.isNotEmpty) Chip(label: Text(p.specialTag), backgroundColor: C.white),
            ]),
          ),
          const SizedBox(height: 12),
          InfoGrid(items: {
            'پدر': father?.name ?? p.fatherName,
            'پدربزرگ': p.grandfatherName,
            'مادر': p.motherName,
            'همسر': spouse?.name ?? p.spouseName,
            'جنسیت': p.gender,
            'تولد': p.birthDate,
            'فوت': p.deathDate,
            'محل تولد': p.birthPlace,
            'محل زندگی': p.livingPlace,
            'شاخه': p.branch,
            'شماره': p.phonePrivate ? 'خصوصی' : p.phone,
          }),
          if (p.notes.isNotEmpty) ...[const SizedBox(height: 12), PremiumCard(child: Text(p.notes, style: const TextStyle(height: 1.8, color: C.ink)))],
          const SizedBox(height: 12),
          SectionTitle(title: 'روابط خانوادگی'),
          RelationWrap(title: 'فرزندان', people: children),
          RelationWrap(title: 'خواهر/برادر', people: siblings),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => showRelationDialog(context, p), icon: const Icon(Icons.compare_arrows), label: const Text('جستجوی نسبت با شخص دیگر')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () => sharePersonInvite(context, tree, p), icon: const Icon(Icons.ios_share), label: const Text('ارسال دعوت برای تکمیل اطلاعات')),
        ])),
      );
    });
  }
}

class InfoGrid extends StatelessWidget {
  final Map<String, String> items;
  const InfoGrid({super.key, required this.items});
  @override
  Widget build(BuildContext context) {
    final entries = items.entries.where((e) => e.value.trim().isNotEmpty).toList();
    return PremiumCard(child: Column(children: entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [SizedBox(width: 86, child: Text(e.key, style: const TextStyle(color: C.muted))), Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800, color: C.ink)))]))).toList()));
  }
}

class RelationWrap extends StatelessWidget {
  final String title;
  final List<Person> people;
  const RelationWrap({super.key, required this.title, required this.people});
  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink)),
        const SizedBox(height: 8),
        if (people.isEmpty) const Text('ثبت نشده', style: TextStyle(color: C.muted)) else Wrap(spacing: 8, runSpacing: 8, children: people.map((p) => ActionChip(label: Text(p.name), onPressed: () => openPerson(context, p))).toList()),
      ]),
    );
  }
}

void sharePersonInvite(BuildContext context, FamilyTree tree, Person p) {
  final link = 'https://nasabnama.local/invite/${tree.code}/${p.code}';
  final text = '''سلام 🌿
شما به عنوان عضوی از شجره‌نامه «${tree.title}» ثبت شده‌اید.

نام ثبت‌شده: ${p.name}
کد شخص: ${p.code}
کد دعوت شجره: ${tree.code}

برای مشاهده و تکمیل اطلاعات خانوادگی از این لینک استفاده کنید:
$link''';
  Share.share(text, subject: 'دعوت شجره‌نامه');
}

Future<void> showRelationDialog(BuildContext context, Person base) async {
  final store = StoreProvider.of(context);
  Person? selected;
  String message = '';
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'جستجوی نسبت فامیلی', children: [
      DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'شخص دوم'), items: (store.current?.people ?? []).where((p) => p.id != base.id).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (id) => setModal(() => selected = store.personById(id))),
      FilledButton(onPressed: selected == null ? null : () => setModal(() => message = store.relationBetween(base, selected!)), child: const Text('محاسبه نسبت')),
      if (message.isNotEmpty) HelpBox(text: message),
    ])),
  );
}


class FullFamilyEntryPage extends StatefulWidget {
  const FullFamilyEntryPage({super.key});
  @override
  State<FullFamilyEntryPage> createState() => _FullFamilyEntryPageState();
}

class _FullFamilyEntryPageState extends State<FullFamilyEntryPage> {
  final headName = TextEditingController();
  final headFatherName = TextEditingController();
  final headGrandfatherName = TextEditingController();
  final headPhone = TextEditingController();
  final spouseName = TextEditingController();
  final spouseFatherName = TextEditingController();
  final spousePhone = TextEditingController();
  final sons = TextEditingController();
  final daughters = TextEditingController();
  final branch = TextEditingController();
  final livingPlace = TextEditingController();
  final notes = TextEditingController();

  String? selectedHeadId;

  @override
  void dispose() {
    headName.dispose();
    headFatherName.dispose();
    headGrandfatherName.dispose();
    headPhone.dispose();
    spouseName.dispose();
    spouseFatherName.dispose();
    spousePhone.dispose();
    sons.dispose();
    daughters.dispose();
    branch.dispose();
    livingPlace.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> _openPreview(BuildContext context, AppStore store) async {
    final sonList = store.splitFamilyNames(sons.text);
    final daughterList = store.splitFamilyNames(daughters.text);
    final candidates = store.findFamilyHeadCandidates(
      headName.text,
      headFatherName.text,
      headGrandfatherName: headGrandfatherName.text,
    );
    if (candidates.length == 1) selectedHeadId ??= candidates.first.id;
    if (selectedHeadId != null && !candidates.any((p) => p.id == selectedHeadId)) selectedHeadId = null;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .86),
                padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 18),
                decoration: const BoxDecoration(
                  color: C.bg,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                ),
                child: SingleChildScrollView(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Center(child: Container(width: 54, height: 5, decoration: BoxDecoration(color: C.muted.withOpacity(.35), borderRadius: BorderRadius.circular(99)))),
                    const SizedBox(height: 14),
                    const SectionTitle(title: 'پیش‌نمایش ثبت خانواده'),
                    PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      PreviewLine(label: 'پدر خانواده', value: headName.text.trim().isEmpty ? 'ثبت نشده' : '${headName.text.trim()}${headFatherName.text.trim().isEmpty ? '' : ' فرزند ${headFatherName.text.trim()}'}'),
                      PreviewLine(label: 'پدربزرگ پدر', value: headGrandfatherName.text.trim().isEmpty ? 'ثبت نشده' : headGrandfatherName.text.trim()),
                      PreviewLine(label: 'همسر', value: spouseName.text.trim().isEmpty ? 'ثبت نشده' : spouseName.text.trim()),
                      PreviewLine(label: 'پسران', value: sonList.isEmpty ? 'ثبت نشده' : sonList.join('، ')),
                      PreviewLine(label: 'دختران', value: daughterList.isEmpty ? 'ثبت نشده' : daughterList.join('، ')),
                      const SizedBox(height: 10),
                      if (candidates.isEmpty)
                        const HelpBox(text: 'شخص مشابهی برای پدر خانواده پیدا نشد. در صورت ثبت، پدر خانواده در جایگاه واردشده ساخته می‌شود و اگر پدر/پدربزرگش در شجره نبود، شاخه بالادستی هم خودکار ساخته می‌شود.'),
                      if (candidates.length == 1)
                        HelpBox(text: 'جایگاه پیشنهادی پیدا شد: ${candidates.first.name} • ${candidates.first.code}. اطلاعات جدید با همین شخص ادغام می‌شود و تکراری ساخته نمی‌شود.'),
                      if (candidates.length > 1) ...[
                        const HelpBox(text: 'چند شخص مشابه پیدا شد. مشخص کن این خانواده باید به کدام شخص وصل شود تا اسم تکراری ساخته نشود.'),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          value: selectedHeadId,
                          decoration: const InputDecoration(labelText: 'انتخاب جایگاه پدر خانواده'),
                          items: candidates.map((p) => DropdownMenuItem(value: p.id, child: Text('${p.name} • ${p.fatherName.isEmpty ? p.code : 'فرزند ${p.fatherName}'}'))).toList(),
                          onChanged: (v) {
                            selectedHeadId = v;
                            setSheetState(() {});
                            setState(() {});
                          },
                        ),
                      ],
                    ])),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.edit), label: const Text('ویرایش'))),
                      const SizedBox(width: 10),
                      Expanded(flex: 2, child: FilledButton.icon(
                        onPressed: headName.text.trim().isEmpty || (candidates.length > 1 && selectedHeadId == null) ? null : () async {
                          final msg = await store.addFullFamily(
                            headName: headName.text,
                            headFatherName: headFatherName.text,
                            headGrandfatherName: headGrandfatherName.text,
                            headPhone: headPhone.text,
                            spouseName: spouseName.text,
                            spouseFatherName: spouseFatherName.text,
                            spousePhone: spousePhone.text,
                            sonsRaw: sons.text,
                            daughtersRaw: daughters.text,
                            branch: branch.text,
                            livingPlace: livingPlace.text,
                            notes: notes.text,
                            selectedHeadId: selectedHeadId,
                          );
                          if (!mounted) return;
                          Navigator.pop(sheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
                          if (msg.startsWith('خانواده ثبت شد')) {
                            setState(() {
                              selectedHeadId = null;
                              headName.clear();
                              headFatherName.clear();
                              headGrandfatherName.clear();
                              headPhone.clear();
                              spouseName.clear();
                              spouseFatherName.clear();
                              spousePhone.clear();
                              sons.clear();
                              daughters.clear();
                              branch.clear();
                              livingPlace.clear();
                              notes.clear();
                            });
                          }
                        },
                        icon: const Icon(Icons.save),
                        label: const Text('تأیید و ثبت خانواده'),
                      )),
                    ]),
                  ]),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;

    return Scaffold(
      appBar: AppBar(title: const Text('افزودن خانواده کامل')),
      body: SafeArea(
        child: tree == null
            ? Center(child: Padding(padding: const EdgeInsets.all(16), child: EmptyState(onCreate: () => showTreeDialog(context))))
            : SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 24),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const AppHeader(title: 'ثبت یک‌جای خانواده', subtitle: 'پدر، مادر و فرزندان را یک‌جا وارد کن؛ پیش‌نمایش داخل پاپ‌آپ باز می‌شود'),
                  const SizedBox(height: 12),
                  PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const HelpBox(text: 'مثلاً: محمد فرزند عبدالواحد، پدربزرگ ملاعمر، همسر صدیقه، پسران سهیل و الیاس، دختران مریم و الینا. اپ قبل از ثبت، جایگاه و افراد تکراری را بررسی می‌کند.'),
                    const SizedBox(height: 12),
                    AppField(controller: headName, label: 'نام پدر خانواده *', hint: 'مثلاً محمد'),
                    AppField(controller: headFatherName, label: 'نام پدرِ پدر خانواده', hint: 'مثلاً عبدالواحد'),
                    AppField(controller: headGrandfatherName, label: 'نام پدربزرگِ پدر خانواده', hint: 'مثلاً ملاعمر'),
                    AppField(controller: headPhone, label: 'شماره پدر خانواده، اختیاری', keyboard: TextInputType.phone),
                    const Divider(height: 26),
                    AppField(controller: spouseName, label: 'نام همسر', hint: 'مثلاً صدیقه'),
                    AppField(controller: spouseFatherName, label: 'نام پدرِ همسر، اختیاری'),
                    AppField(controller: spousePhone, label: 'شماره همسر، اختیاری', keyboard: TextInputType.phone),
                    const Divider(height: 26),
                    AppField(controller: sons, label: 'پسران', hint: 'سهیل، الیاس یا سهیل و الیاس', maxLines: 2),
                    AppField(controller: daughters, label: 'دختران', hint: 'مریم، الینا یا مریم و الینا', maxLines: 2),
                    Row(children: [Expanded(child: AppField(controller: branch, label: 'شاخه خانوادگی')), const SizedBox(width: 8), Expanded(child: AppField(controller: livingPlace, label: 'محل زندگی'))]),
                    AppField(controller: notes, label: 'توضیحات مشترک خانواده', maxLines: 3),
                    const SizedBox(height: 8),
                    FilledButton.icon(onPressed: () => _openPreview(context, store), icon: const Icon(Icons.visibility), label: const Text('پیش‌نمایش قبل از ثبت')),
                  ])),
                ]),
              ),
      ),
    );
  }
}

class PreviewLine extends StatelessWidget {
  final String label;
  final String value;
  const PreviewLine({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 96, child: Text(label, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700))),
        Expanded(child: Text(value, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900))),
      ]),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    final tree = store.current;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const AppHeader(title: 'امکانات کامل', subtitle: 'مدیریت اعضا، بکاپ، اسناد، مناسبت‌ها، چت و رأی‌گیری'),
          const SizedBox(height: 12),
          if (tree == null) EmptyState(onCreate: () => showTreeDialog(context)) else GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.18,
            children: [
              FeatureTile(title: 'افزودن خانواده کامل', icon: Icons.group_add_rounded, color: C.green, onTap: () => push(context, const FullFamilyEntryPage())),
              FeatureTile(title: 'اعضا و دسترسی', icon: Icons.admin_panel_settings, color: C.blue, onTap: () => push(context, const MembersPage())),
              FeatureTile(title: 'افراد تکراری', icon: Icons.merge_type, color: C.green, onTap: () => push(context, const DuplicatesPage())),
              FeatureTile(title: 'گالری و اسناد', icon: Icons.photo_library, color: C.gold, onTap: () => push(context, const ItemsPage())),
              FeatureTile(title: 'مناسبت‌ها', icon: Icons.event, color: C.red, onTap: () => push(context, const EventsPage())),
              FeatureTile(title: 'چت خانوادگی', icon: Icons.chat_bubble, color: C.green, onTap: () => push(context, const ChatPage())),
              FeatureTile(title: 'رأی‌گیری', icon: Icons.how_to_vote, color: C.blue, onTap: () => push(context, const PollsPage())),
              FeatureTile(title: 'بکاپ/بازیابی', icon: Icons.backup, color: C.gold, onTap: () => push(context, const BackupPage())),
              FeatureTile(title: 'راهنما', icon: Icons.help, color: C.red, onTap: () => push(context, const HelpPage())),
            ],
          ),
        ]),
      ),
    );
  }
}

void push(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

class FeatureTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const FeatureTile({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => PremiumCard(onTap: onTap, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [CircleAvatar(radius: 26, backgroundColor: color.withOpacity(.13), child: Icon(icon, color: color)), const SizedBox(height: 10), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink))]));
}

class MembersPage extends StatelessWidget {
  const MembersPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('اعضا و دسترسی')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final tree = store.current;
      if (tree == null) return const Center(child: Text('شجره‌ای وجود ندارد.'));
      return ListView(padding: const EdgeInsets.all(16), children: [
        FilledButton.icon(onPressed: () => showMemberDialog(context), icon: const Icon(Icons.person_add), label: const Text('افزودن عضو/ادمین')),
        const SizedBox(height: 12),
        const SectionTitle(title: 'اعضای تأییدشده'),
        ...tree.members.map((m) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.verified_user, color: C.green), title: Text(m.name), subtitle: Text('${m.role} • ${m.phone}')))),
        const SectionTitle(title: 'درخواست‌های عضویت'),
        FilledButton.tonalIcon(onPressed: () => showRequestDialog(context), icon: const Icon(Icons.add), label: const Text('ثبت درخواست آزمایشی')),
        const SizedBox(height: 8),
        ...tree.requests.map((r) => PremiumCard(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.name, style: const TextStyle(fontWeight: FontWeight.w900)), Text('${r.status} • ${r.phone}', style: const TextStyle(color: C.muted))])), if (r.status == 'در انتظار') TextButton(onPressed: () => store.approveRequest(r), child: const Text('تأیید'))]))),
      ]);
    }));
  }
}

Future<void> showMemberDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final name = TextEditingController();
  final phone = TextEditingController();
  var role = 'عضو';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'افزودن عضو', children: [
    AppField(controller: name, label: 'نام'),
    AppField(controller: phone, label: 'شماره'),
    DropdownButtonFormField<String>(value: role, decoration: const InputDecoration(labelText: 'نقش'), items: const ['ادمین اصلی', 'ادمین شاخه', 'عضو', 'فقط مشاهده'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => role = v ?? 'عضو')),
    FilledButton(onPressed: () async { await store.addMember(name.text, phone.text, role); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

Future<void> showRequestDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final name = TextEditingController();
  final phone = TextEditingController();
  final note = TextEditingController();
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => FormSheet(title: 'درخواست عضویت', children: [
    AppField(controller: name, label: 'نام'),
    AppField(controller: phone, label: 'شماره'),
    AppField(controller: note, label: 'توضیح', maxLines: 3),
    FilledButton(onPressed: () async { await store.addRequest(name.text, phone.text, note.text); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت درخواست')),
  ]));
}

class DuplicatesPage extends StatelessWidget {
  const DuplicatesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('افراد تکراری')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final groups = store.duplicateGroups();
      if (groups.isEmpty) return const Center(child: Text('فرد تکراری پیدا نشد.'));
      return ListView(padding: const EdgeInsets.all(16), children: groups.map((g) => PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('احتمال تکرار: ${g.first.name}', style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), ...g.map((p) => ListTile(title: Text(p.name), subtitle: Text(p.code))), if (g.length >= 2) FilledButton.tonal(onPressed: () => store.mergePersons(g[0], g[1]), child: Text('ادغام ${g[1].code} با ${g[0].code}'))]))).toList());
    }));
  }
}

class ItemsPage extends StatelessWidget {
  const ItemsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('گالری و اسناد')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showItemDialog(context), icon: const Icon(Icons.add), label: const Text('افزودن')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final items = store.current?.items ?? [];
      if (items.isEmpty) return const Center(child: Text('هنوز تصویر یا سندی ثبت نشده است.'));
      return ListView.builder(padding: const EdgeInsets.all(16), itemCount: items.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(leading: Icon(items[i].type == 'سند' ? Icons.description : Icons.photo, color: C.blue), title: Text(items[i].title), subtitle: Text(items[i].description))));
    }));
  }
}

Future<void> showItemDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final desc = TextEditingController();
  var type = 'عکس';
  String personId = '';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'افزودن عکس/سند', children: [
    AppField(controller: title, label: 'عنوان'),
    AppField(controller: desc, label: 'توضیحات', maxLines: 3),
    DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'نوع'), items: const ['عکس', 'سند'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => type = v ?? 'عکس')),
    DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'مرتبط با شخص'), items: (store.current?.people ?? []).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => personId = v ?? ''),
    FilledButton(onPressed: () async { await store.addItem(title.text, desc.text, type, personId); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

class EventsPage extends StatelessWidget {
  const EventsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('مناسبت‌ها و خط زمانی')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showEventDialog(context), icon: const Icon(Icons.add), label: const Text('رویداد')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final events = [...(store.current?.events ?? [])]..sort((a, b) => a.date.compareTo(b.date));
      if (events.isEmpty) return const Center(child: Text('رویدادی ثبت نشده است.'));
      return ListView.builder(padding: const EdgeInsets.all(16), itemCount: events.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(12), child: ListTile(leading: const Icon(Icons.event, color: C.green), title: Text(events[i].title), subtitle: Text('${events[i].type} • ${events[i].date}\n${events[i].notes}'))));
    }));
  }
}

Future<void> showEventDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final title = TextEditingController();
  final date = TextEditingController();
  final notes = TextEditingController();
  var type = 'تولد';
  String personId = '';
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'ثبت رویداد', children: [
    AppField(controller: title, label: 'عنوان'),
    AppField(controller: date, label: 'تاریخ', hint: 'مثلاً ۱۳۷۰/۰۲/۱۵'),
    DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'نوع'), items: const ['تولد', 'ازدواج', 'فوت', 'مهاجرت', 'یادبود', 'رویداد'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setModal(() => type = v ?? 'رویداد')),
    DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'مرتبط با شخص'), items: (store.current?.people ?? []).map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => personId = v ?? ''),
    AppField(controller: notes, label: 'توضیحات', maxLines: 3),
    FilledButton(onPressed: () async { await store.addEvent(title.text, date.text, type, notes.text, personId); if (context.mounted) Navigator.pop(context); }, child: const Text('ثبت')),
  ])));
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final msg = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('چت خانوادگی')), body: Column(children: [
      Expanded(child: AnimatedBuilder(animation: store, builder: (_, __) { final chats = store.current?.chats ?? []; return ListView.builder(padding: const EdgeInsets.all(16), itemCount: chats.length, itemBuilder: (_, i) => Align(alignment: Alignment.centerRight, child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: C.white, borderRadius: BorderRadius.circular(18)), child: Text('${chats[i].sender}: ${chats[i].text}')))); })),
      SafeArea(child: Padding(padding: EdgeInsets.only(left: 12, right: 12, bottom: MediaQuery.of(context).viewInsets.bottom + 8), child: Row(children: [Expanded(child: TextField(controller: msg, decoration: const InputDecoration(labelText: 'پیام'))), const SizedBox(width: 8), IconButton.filled(onPressed: () { if (msg.text.trim().isNotEmpty) { store.addChat('ادمین', msg.text.trim()); msg.clear(); } }, icon: const Icon(Icons.send))]))),
    ]));
  }
}

class PollsPage extends StatelessWidget {
  const PollsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('رأی‌گیری خانوادگی')), floatingActionButton: FloatingActionButton.extended(onPressed: () => showPollDialog(context), icon: const Icon(Icons.add), label: const Text('نظرسنجی')), body: AnimatedBuilder(animation: store, builder: (_, __) {
      final polls = store.current?.polls ?? [];
      if (polls.isEmpty) return const Center(child: Text('نظرسنجی ثبت نشده است.'));
      return ListView(padding: const EdgeInsets.all(16), children: polls.map((poll) => PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(poll.question, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 8), ...poll.options.map((o) => ListTile(title: Text(o), trailing: Text('${poll.votes[o] ?? 0} رأی'), onTap: () => store.vote(poll, o)))]))).toList());
    }));
  }
}

Future<void> showPollDialog(BuildContext context) async {
  final store = StoreProvider.of(context);
  final q = TextEditingController();
  final o1 = TextEditingController();
  final o2 = TextEditingController();
  final o3 = TextEditingController();
  var secret = false;
  await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StatefulBuilder(builder: (context, setModal) => FormSheet(title: 'ایجاد رأی‌گیری', children: [
    AppField(controller: q, label: 'سؤال'),
    AppField(controller: o1, label: 'گزینه ۱'),
    AppField(controller: o2, label: 'گزینه ۲'),
    AppField(controller: o3, label: 'گزینه ۳ اختیاری'),
    SwitchListTile(contentPadding: EdgeInsets.zero, value: secret, onChanged: (v) => setModal(() => secret = v), title: const Text('رأی مخفی')),
    FilledButton(onPressed: () async { final opts = [o1.text, o2.text, o3.text].where((e) => e.trim().isNotEmpty).toList(); if (q.text.trim().isNotEmpty && opts.length >= 2) { await store.addPoll(q.text, opts, secret); if (context.mounted) Navigator.pop(context); } }, child: const Text('ثبت')),
  ])));
}

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  final raw = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final store = StoreProvider.of(context);
    return Scaffold(appBar: AppBar(title: const Text('بکاپ و بازیابی')), body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const HelpBox(text: 'فعلاً همه اطلاعات داخل گوشی ذخیره می‌شود. با خروجی JSON می‌توانی پشتیبان بگیری و بعداً برای اتصال سرور هم همین ساختار استفاده می‌شود.'),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => Share.share(store.backupJson(), subject: 'پشتیبان نسب‌نامه'), icon: const Icon(Icons.ios_share), label: const Text('اشتراک‌گذاری بکاپ JSON')),
      const SizedBox(height: 12),
      AppField(controller: raw, label: 'متن بکاپ JSON را اینجا بچسبان', maxLines: 8),
      FilledButton.tonal(onPressed: () async { final msg = await store.importBackup(raw.text); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg))); }, child: const Text('بازیابی')),
    ])));
  }
}

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});
  @override
  Widget build(BuildContext context) {
    final tips = [
      'برای شروع، از صفحه خانه یک شجره بساز.',
      'برای ثبت سریع، از «افزودن خانواده کامل» استفاده کن و پدر، همسر، پسران و دختران را یک‌جا وارد کن.',
      'برای جایگذاری خودکار، نام شخص، نام پدر و نام پدربزرگ را وارد کن.',
      'اگر پدر یا پدربزرگ در شجره نباشند، اپ آن‌ها را خودکار به‌عنوان شاخه جدید می‌سازد.',
      'از صفحه جستجو می‌توانی با نام، نام پدر، پدربزرگ، کد شخص، شهر یا شماره جستجو کنی.',
      'در صفحه هر شخص، فرزندان، خواهر/برادر و نسبت با افراد دیگر نمایش داده می‌شود.',
      'برای دعوت، دکمه اشتراک را بزن؛ متن دعوت، لینک و کد دعوت آماده می‌شود و خودت واتساپ، تلگرام یا پیامک را انتخاب می‌کنی.',
      'برای امنیت، شماره تماس به‌صورت پیش‌فرض خصوصی است.',
      'قبل از اتصال بک‌اند، از بخش بکاپ خروجی JSON بگیر.',
    ];
    return Scaffold(appBar: AppBar(title: const Text('راهنمای کامل')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: tips.length, itemBuilder: (_, i) => PremiumCard(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(backgroundColor: C.sky, child: Text('${i + 1}', style: const TextStyle(color: C.blue, fontWeight: FontWeight.w900))), const SizedBox(width: 10), Expanded(child: Text(tips[i], style: const TextStyle(height: 1.8, color: C.ink)))]))));
  }
}
