# Shejrino v5.11.10 EmptyState Compile Fix

Base:
- shejrino_flutter_v5_11_9_workflow_root_detect_fix.zip

Fix:
- EmptyState constructor now supports optional title, subtitle, actionLabel and nullable onCreate.
- This fixes the release compile error around:
  const EmptyState({super.key, required this.onCreate});
- Workflow is unchanged from v5.11.9 and still skips plugin pubspec.yaml roots.

Version:
- 5.11.10+78
