# NasabNama v5.10.6 Release Ready Info Pages

Base:
- v5.10.5 Tree Initial Zoom Fit

Changes:
- Removes the visible HTML wording from tree page subtitle
- Improves app guidance and subscription text
- Adds Quick Guide page
- Adds About page
- Adds Privacy page
- Adds Terms of Use page
- Shows information/legal pages even before a tree is created
- Improves help text without changing the main tree UI
- Keeps tree UI unchanged
- Keeps initial zoom fit
- Keeps PNG/PDF export
- Keeps Bazaar payment and public key
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.6+62
