# NasabNama v5.10.7 Local Auth Access

Base:
- v5.10.6 Release Ready Info Pages

Changes:
- Adds local registration page
- Adds local login page
- Uses username + password
- Stores local users on-device
- Stores password as SHA-256 hash, not raw text
- Adds logout
- Adds ownerUsername to each tree
- Adds accessByUsername to each tree
- Filters visible trees by current user access
- Adds access levels:
  - owner / admin / edit / view
- Adds local access management page
- Adds read-only mode for users without edit permission
- Keeps each tree tied to its owner and invited users
- Keeps each tree code
- Improves PDF export layout with landscape A4, border and warm background
- Does not add profile photos
- Keeps main tree UI unchanged
- Keeps PNG/PDF export
- Keeps Bazaar payment and public key
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.7+63
