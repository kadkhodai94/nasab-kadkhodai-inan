# NasabNama v5.8.1 Bazaar Subscription Analyze Fix

Fix:
- Removed unsupported margin parameter from PremiumCard in SubscriptionPlanCard
- Replaced it with Padding wrapper
- Bazaar subscription version remains active
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.1+42
