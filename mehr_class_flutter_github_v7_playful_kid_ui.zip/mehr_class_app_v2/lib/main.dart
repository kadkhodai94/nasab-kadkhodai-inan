import 'package:flutter/material.dart';

import 'data/offline_content.dart';
import 'models/lesson_models.dart';
import 'services/app_audio.dart';
import 'services/progress_store.dart';
import 'services/sync_service.dart';
import 'widgets/app_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MehrClassApp());
}

class MehrClassApp extends StatelessWidget {
  const MehrClassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس مهر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        scaffoldBackgroundColor: KidColors.pageBottom,
        colorScheme: ColorScheme.fromSeed(seedColor: KidColors.blue),
        textTheme: Theme.of(context).textTheme.apply(
              bodyColor: KidColors.ink,
              displayColor: KidColors.ink,
              fontFamily: 'sans',
            ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: KidColors.blue,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: KidColors.deepBlue,
            side: BorderSide(color: KidColors.blue.withOpacity(.25), width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ProgressModel progress = ProgressModel.empty();
  bool syncing = false;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await const SyncService().checkForContentUpdates();
    if (!mounted) return;
    setState(() => syncing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.message, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: KidScaffold(
        bottomNavigationBar: _KidBottomNav(
          selectedIndex: tabIndex,
          onChanged: (value) => setState(() => tabIndex = value),
        ),
        child: IndexedStack(
          index: tabIndex,
          children: [
            _HomeTab(progress: progress, syncing: syncing, onSync: _sync, onChanged: _load),
            _DiscoverTab(onChanged: _load),
            _RewardsTab(progress: progress),
            _SchoolBagTab(progress: progress),
            _AboutTab(progress: progress),
          ],
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final ProgressModel progress;
  final bool syncing;
  final VoidCallback onSync;
  final VoidCallback onChanged;

  const _HomeTab({required this.progress, required this.syncing, required this.onSync, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
      children: [
        _TopBanner(stars: progress.stars),
        const SizedBox(height: 18),
        _MascotHero(onPlay: () => AppAudio.playAsset(OfflineContent.commonWelcome.localAssetPath)),
        const SizedBox(height: 18),
        _TinySyncCard(syncing: syncing, onSync: onSync),
        const SizedBox(height: 24),
        const SectionTitle('امروز کجا بریم؟', emoji: '🧭'),
        const SizedBox(height: 12),
        _GradeWorlds(onChanged: onChanged),
        const SizedBox(height: 24),
        const SectionTitle('دنیای یادگیری', emoji: '🌈'),
        const SizedBox(height: 12),
        _AdventureGrid(onChanged: onChanged),
        const SizedBox(height: 24),
        _StarPathBoard(progress: progress),
      ],
    );
  }
}

class _TopBanner extends StatelessWidget {
  final int stars;
  const _TopBanner({required this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF14C4FF), Color(0xFF2D66FF)]),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(blurRadius: 24, offset: const Offset(0, 14), color: KidColors.blue.withOpacity(.22))],
                ),
                child: const Center(child: Text('🎒', style: TextStyle(fontSize: 38))),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('کلاس مهر', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: KidColors.ink)),
                    SizedBox(height: 4),
                    Text('یک دنیای شاد برای کلاس اولی‌ها و دومی‌ها', style: TextStyle(fontSize: 13.2, color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFF7CC), Color(0xFFFFE179)]),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white, width: 1.2),
            boxShadow: [BoxShadow(blurRadius: 15, offset: const Offset(0, 8), color: KidColors.yellow.withOpacity(.22))],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$stars', style: const TextStyle(color: KidColors.ink, fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(width: 8),
              const Text('⭐', style: TextStyle(fontSize: 24)),
            ],
          ),
        ),
      ],
    );
  }
}

class _MascotHero extends StatelessWidget {
  final VoidCallback onPlay;
  const _MascotHero({required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 36,
      strongShadow: true,
      padding: const EdgeInsets.all(0),
      gradient: const [Color(0xFF17A8FF), Color(0xFF49D0FF)],
      child: ClipRRect(
        borderRadius: BorderRadius.circular(36),
        child: Stack(
          children: [
            Positioned(right: -18, top: -20, child: Container(width: 110, height: 110, decoration: BoxDecoration(color: Colors.white.withOpacity(.13), shape: BoxShape.circle))),
            Positioned(left: -10, bottom: -26, child: Container(width: 120, height: 120, decoration: BoxDecoration(color: Colors.white.withOpacity(.10), shape: BoxShape.circle))),
            Positioned(left: 20, top: 16, child: Text('☁️', style: TextStyle(fontSize: 34, color: Colors.white.withOpacity(.9)))),
            Positioned(right: 18, top: 18, child: const Text('🦋', style: TextStyle(fontSize: 24))),
            Positioned(right: 64, top: 72, child: const Text('🌈', style: TextStyle(fontSize: 40))),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(.18),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('🎉', style: TextStyle(fontSize: 15)),
                                  SizedBox(width: 6),
                                  Flexible(child: Text('بیا با هم یاد بگیریم', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.3))),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            const Text('سلام قهرمان کوچولو!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 30, height: 1.25)),
                            const SizedBox(height: 10),
                            const Text(
                              'با دوستِ کوچولوی کلاس مهر برو\nبه باغ حروف، دنیای عددها، قصه‌خونه\nو شهرِ مهارت‌ها.',
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, height: 1.8, fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 124,
                        height: 142,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.15),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.white.withOpacity(.6), width: 1.2),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('🦁', style: TextStyle(fontSize: 76)),
                            SizedBox(height: 6),
                            Text('شیرِ دانا', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.14),
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: Colors.white.withOpacity(.30)),
                          ),
                          child: const Text('ویس‌ها فعلاً نمونه هستند و بعداً با صدای خودت جایگزین می‌شوند.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.4, height: 1.7)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton.icon(
                        onPressed: onPlay,
                        icon: const Icon(Icons.volume_up_rounded),
                        label: const Text('پخش ویس'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: KidColors.deepBlue,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TinySyncCard extends StatelessWidget {
  final bool syncing;
  final VoidCallback onSync;
  const _TinySyncCard({required this.syncing, required this.onSync});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      color: Colors.white,
      radius: 28,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const IconBubble(icon: Icons.cloud_done_rounded, color: KidColors.green, size: 58, iconSize: 28, backgroundColor: Color(0xFFEFFFF0)),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('بدون اینترنت هم کار می‌کند', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16.3, color: KidColors.ink)),
                SizedBox(height: 5),
                Text('وقتی خواستی، در نسخه بعدی می‌تونه به پنل وصل بشه و درس‌های تازه بگیره.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 12.8, height: 1.6)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              const Text('🍎', style: TextStyle(fontSize: 30)),
              TextButton(onPressed: syncing ? null : onSync, child: Text(syncing ? 'درحال بررسی' : 'بررسی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))),
            ],
          ),
        ],
      ),
    );
  }
}

class _GradeWorlds extends StatelessWidget {
  final VoidCallback onChanged;
  const _GradeWorlds({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _WorldCard(
            title: 'دنیای پایه اول',
            subtitle: 'شروع با حروف و عددها',
            emoji: '🌱',
            colors: const [Color(0xFFE4FFCC), Color(0xFFC4F4A9)],
            accent: const Color(0xFF1C8B44),
            lessons: OfflineContent.lessons.where((e) => e.grade == GradeLevel.gradeOne).toList(),
            onChanged: onChanged,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _WorldCard(
            title: 'دنیای پایه دوم',
            subtitle: 'تمرین‌های بزرگ‌تر',
            emoji: '🚀',
            colors: const [Color(0xFFDEF3FF), Color(0xFFBEE6FF)],
            accent: KidColors.deepBlue,
            lessons: OfflineContent.lessons.where((e) => e.grade == GradeLevel.gradeTwo).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

class _WorldCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String emoji;
  final List<Color> colors;
  final Color accent;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const _WorldCard({required this.title, required this.subtitle, required this.emoji, required this.colors, required this.accent, required this.lessons, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      minHeight: 210,
      radius: 30,
      gradient: colors,
      padding: const EdgeInsets.all(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LessonCollectionPage(
            title: title,
            subtitle: subtitle,
            lessons: lessons,
            onChanged: onChanged,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.68),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: Text(emoji, style: const TextStyle(fontSize: 30)),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.6), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} درس', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Text(title, style: TextStyle(color: accent, fontSize: 22, fontWeight: FontWeight.w900, height: 1.3)),
          const SizedBox(height: 8),
          Text(subtitle, style: TextStyle(color: accent.withOpacity(.82), fontWeight: FontWeight.w700, fontSize: 13.1, height: 1.65)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: Colors.white.withOpacity(.52), borderRadius: BorderRadius.circular(18)),
            child: Row(
              children: [
                Icon(Icons.arrow_back_rounded, color: accent, size: 20),
                const SizedBox(width: 6),
                Text('بزن بریم', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AdventureGrid extends StatelessWidget {
  final VoidCallback onChanged;
  const _AdventureGrid({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = <_AdventureItem>[
      _AdventureItem('باغ حروف', 'الفبا و کلمه‌ها', '🌳', KidColors.purple, const [Color(0xFFF6ECFF), Color(0xFFE9DAFF)], LessonType.letters),
      _AdventureItem('دنیای عددها', 'شمارش و جمع', '🍎', KidColors.orange, const [Color(0xFFFFF0E4), Color(0xFFFFD7C5)], LessonType.numbers),
      _AdventureItem('قصه‌خونه', 'داستان و خیال', '📚', const Color(0xFFE09B00), const [Color(0xFFFFF8D8), Color(0xFFFFE7A7)], LessonType.story),
      _AdventureItem('شهر مهارت‌ها', 'کارهای خوب روزانه', '🧼', KidColors.green, const [Color(0xFFE8FFE9), Color(0xFFD0F4D7)], LessonType.lifeSkill),
    ];

    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _AdventureCard(item: items[0], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _AdventureCard(item: items[1], onChanged: onChanged)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _AdventureCard(item: items[2], onChanged: onChanged)),
            const SizedBox(width: 12),
            Expanded(child: _AdventureCard(item: items[3], onChanged: onChanged)),
          ],
        ),
      ],
    );
  }
}

class _AdventureItem {
  final String title;
  final String subtitle;
  final String emoji;
  final Color accent;
  final List<Color> colors;
  final LessonType type;
  _AdventureItem(this.title, this.subtitle, this.emoji, this.accent, this.colors, this.type);
}

class _AdventureCard extends StatelessWidget {
  final _AdventureItem item;
  final VoidCallback onChanged;
  const _AdventureCard({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final lessons = OfflineContent.lessons.where((e) => e.type == item.type || (item.type == LessonType.numbers && e.type == LessonType.math)).toList();
    return KidCard(
      minHeight: 210,
      radius: 30,
      gradient: item.colors,
      padding: const EdgeInsets.all(15),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LessonCollectionPage(title: item.title, subtitle: item.subtitle, lessons: lessons, onChanged: onChanged),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.7),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: Text(item.emoji, style: const TextStyle(fontSize: 30)),
              ),
              const Spacer(),
              const Text('✨', style: TextStyle(fontSize: 20)),
            ],
          ),
          const SizedBox(height: 16),
          Text(item.title, style: TextStyle(color: item.accent, fontSize: 20, fontWeight: FontWeight.w900, height: 1.35)),
          const SizedBox(height: 8),
          Text(item.subtitle, style: TextStyle(color: item.accent.withOpacity(.82), fontSize: 13, fontWeight: FontWeight.w700, height: 1.6)),
          const Spacer(),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.64), borderRadius: BorderRadius.circular(999)),
                child: Text('${lessons.length} درس', style: TextStyle(color: item.accent, fontWeight: FontWeight.w900, fontSize: 12)),
              ),
              const Spacer(),
              Icon(Icons.arrow_back_rounded, color: item.accent),
            ],
          ),
        ],
      ),
    );
  }
}

class _StarPathBoard extends StatelessWidget {
  final ProgressModel progress;
  const _StarPathBoard({required this.progress});

  @override
  Widget build(BuildContext context) {
    final complete = progress.completedLessonIds.length;
    return KidCard(
      radius: 34,
      color: Colors.white,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('راهِ ستاره‌ها', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21, color: KidColors.ink))),
              SoftPill(color: KidColors.green, child: Text('$complete درس کامل شده', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12))),
            ],
          ),
          const SizedBox(height: 16),
          const _PathTile(index: 1, emoji: '🎧', title: 'گوش کن', subtitle: 'صدای درس را بشنو.', color: KidColors.blue),
          const SizedBox(height: 10),
          const _PathTile(index: 2, emoji: '👀', title: 'نگاه کن', subtitle: 'به تصویرها و مثال‌ها دقت کن.', color: KidColors.purple),
          const SizedBox(height: 10),
          const _PathTile(index: 3, emoji: '✍️', title: 'تمرین کن', subtitle: 'جواب بده و تمرین کن.', color: KidColors.orange),
          const SizedBox(height: 10),
          const _PathTile(index: 4, emoji: '⭐', title: 'جایزه بگیر', subtitle: 'ستاره جمع کن و جلو برو.', color: KidColors.green),
        ],
      ),
    );
  }
}

class _PathTile extends StatelessWidget {
  final int index;
  final String emoji;
  final String title;
  final String subtitle;
  final Color color;
  const _PathTile({required this.index, required this.emoji, required this.title, required this.subtitle, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withOpacity(.07), borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withOpacity(.15), borderRadius: BorderRadius.circular(12)),
            child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, color: KidColors.ink)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 12.5, height: 1.55)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 50,
            height: 50,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(blurRadius: 12, offset: const Offset(0, 6), color: color.withOpacity(.16))]),
            child: Text(emoji, style: const TextStyle(fontSize: 24)),
          ),
        ],
      ),
    );
  }
}

class LessonCollectionPage extends StatefulWidget {
  final String title;
  final String subtitle;
  final List<LessonModel> lessons;
  final VoidCallback onChanged;

  const LessonCollectionPage({super.key, required this.title, required this.subtitle, required this.lessons, required this.onChanged});

  @override
  State<LessonCollectionPage> createState() => _LessonCollectionPageState();
}

class _LessonCollectionPageState extends State<LessonCollectionPage> {
  ProgressModel progress = ProgressModel.empty();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    progress = await ProgressStore.load();
    if (mounted) setState(() {});
  }

  Future<void> _completeLesson(LessonModel lesson) async {
    progress = await ProgressStore.completeLesson(lesson.id);
    await AppAudio.playAsset('assets/audio/common/correct.mp3');
    widget.onChanged();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PageShell(
      title: widget.title,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 26),
        children: [
          KidCard(
            radius: 30,
            gradient: const [Color(0xFFEAF8FF), Color(0xFFFFF7E9)],
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                  child: const Text('🎈', style: TextStyle(fontSize: 30)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: KidColors.ink)),
                      const SizedBox(height: 4),
                      Text(widget.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 13, height: 1.55)),
                    ],
                  ),
                ),
                SoftPill(color: KidColors.green, child: Text('${widget.lessons.length} درس', style: const TextStyle(color: KidColors.green, fontWeight: FontWeight.w900, fontSize: 12))),
              ],
            ),
          ),
          const SizedBox(height: 14),
          for (final lesson in widget.lessons) ...[
            _LessonPlayCard(
              lesson: lesson,
              done: progress.completedLessonIds.contains(lesson.id),
              onPlay: lesson.audio == null ? null : () => AppAudio.playAsset(lesson.audio!.localAssetPath),
              onComplete: () => _completeLesson(lesson),
            ),
            const SizedBox(height: 14),
          ],
        ],
      ),
    );
  }
}

class _LessonPlayCard extends StatelessWidget {
  final LessonModel lesson;
  final bool done;
  final VoidCallback? onPlay;
  final VoidCallback onComplete;

  const _LessonPlayCard({required this.lesson, required this.done, required this.onPlay, required this.onComplete});

  _LessonLook _look() {
    switch (lesson.type) {
      case LessonType.letters:
        return const _LessonLook(KidColors.purple, [Color(0xFFF7EEFF), Color(0xFFE9DAFF)], '🔤');
      case LessonType.numbers:
      case LessonType.math:
        return const _LessonLook(KidColors.orange, [Color(0xFFFFF0E6), Color(0xFFFFDCC8)], '🍎');
      case LessonType.story:
        return const _LessonLook(Color(0xFFE09B00), [Color(0xFFFFF7DA), Color(0xFFFFE8AF)], '📚');
      case LessonType.lifeSkill:
        return const _LessonLook(KidColors.green, [Color(0xFFE8FFE9), Color(0xFFD0F4D7)], '🧼');
      case LessonType.writing:
        return const _LessonLook(KidColors.blue, [Color(0xFFE5F3FF), Color(0xFFD0E9FF)], '✍️');
    }
  }

  @override
  Widget build(BuildContext context) {
    final look = _look();
    return KidCard(
      radius: 32,
      gradient: look.colors,
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 66,
                height: 66,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.white.withOpacity(.76), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white, width: 1.2)),
                child: lesson.display.length <= 3
                    ? Text(lesson.display, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: look.accent))
                    : Text(look.emoji, style: const TextStyle(fontSize: 30)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: KidColors.ink))),
                        done
                            ? const Text('✅', style: TextStyle(fontSize: 24))
                            : const Icon(Icons.radio_button_unchecked_rounded, color: KidColors.muted, size: 26),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(lesson.subtitle, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, fontSize: 13.3, height: 1.6)),
                    if (lesson.examples.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: lesson.examples
                            .map((e) => SoftPill(color: look.accent, child: Text(e, style: TextStyle(color: look.accent, fontWeight: FontWeight.w900, fontSize: 12.1))))
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onComplete,
                  icon: const Icon(Icons.star_rounded),
                  label: Text(done ? 'بلدم' : 'یاد گرفتم'),
                  style: ElevatedButton.styleFrom(backgroundColor: KidColors.blue, foregroundColor: Colors.white),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onPlay,
                  icon: const Icon(Icons.volume_up_rounded),
                  label: const Text('پخش ویس'),
                  style: OutlinedButton.styleFrom(foregroundColor: look.accent, side: BorderSide(color: look.accent.withOpacity(.3), width: 1.5)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LessonLook {
  final Color accent;
  final List<Color> colors;
  final String emoji;
  const _LessonLook(this.accent, this.colors, this.emoji);
}

class _DiscoverTab extends StatelessWidget {
  final VoidCallback onChanged;
  const _DiscoverTab({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('بزن به دلِ ماجرا', emoji: '🗺️'),
        const SizedBox(height: 12),
        KidCard(
          radius: 30,
          gradient: const [Color(0xFFEAF8FF), Color(0xFFFFF5E7)],
          child: const Text('اینجا می‌تونی سریع وارد بخش‌های مختلف بشی و هر درسی را که دوست داری انتخاب کنی.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.7, fontSize: 13.2), textAlign: TextAlign.right),
        ),
        const SizedBox(height: 14),
        _AdventureGrid(onChanged: onChanged),
        const SizedBox(height: 14),
        _GradeWorlds(onChanged: onChanged),
      ],
    );
  }
}

class _RewardsTab extends StatelessWidget {
  final ProgressModel progress;
  const _RewardsTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('جایزه‌های من', emoji: '🎁'),
        const SizedBox(height: 14),
        KidCard(
          radius: 34,
          gradient: const [Color(0xFFFFF3B8), Color(0xFFFFD86F)],
          strongShadow: true,
          child: Column(
            children: [
              const Text('🏆', style: TextStyle(fontSize: 72)),
              const SizedBox(height: 8),
              const Text('تو یک قهرمانی!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: KidColors.ink)),
              const SizedBox(height: 8),
              Text('تا الان ${progress.stars} ستاره گرفتی و ${progress.completedLessonIds.length} درس را کامل کردی.', textAlign: TextAlign.center, style: const TextStyle(color: KidColors.ink, fontWeight: FontWeight.w800, height: 1.75)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _RewardBox(title: 'ستاره‌ها', value: '${progress.stars}', emoji: '⭐', color: KidColors.orange)),
            const SizedBox(width: 12),
            Expanded(child: _RewardBox(title: 'درس کامل', value: '${progress.completedLessonIds.length}', emoji: '📘', color: KidColors.green)),
          ],
        ),
      ],
    );
  }
}

class _RewardBox extends StatelessWidget {
  final String title;
  final String value;
  final String emoji;
  final Color color;
  const _RewardBox({required this.title, required this.value, required this.emoji, required this.color});

  @override
  Widget build(BuildContext context) {
    return KidCard(
      radius: 28,
      gradient: [Colors.white, color.withOpacity(.08)],
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 32)),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: color)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _SchoolBagTab extends StatelessWidget {
  final ProgressModel progress;
  const _SchoolBagTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('کیفِ من', emoji: '🎒'),
        const SizedBox(height: 14),
        KidCard(
          radius: 32,
          gradient: const [Color(0xFFF1F8FF), Color(0xFFFFF4E7)],
          child: Column(
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30)),
                child: const Center(child: Text('🧒', style: TextStyle(fontSize: 54))),
              ),
              const SizedBox(height: 12),
              const Text('دانش‌آموز کلاس مهر', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: KidColors.ink)),
              const SizedBox(height: 6),
              const Text('هر روز با بازی و شادی یاد می‌گیرم.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: _RewardBox(title: 'ستاره', value: '${progress.stars}', emoji: '⭐', color: KidColors.orange)),
                  const SizedBox(width: 12),
                  Expanded(child: _RewardBox(title: 'درس کامل', value: '${progress.completedLessonIds.length}', emoji: '✅', color: KidColors.green)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AboutTab extends StatelessWidget {
  final ProgressModel progress;
  const _AboutTab({required this.progress});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 110),
      children: [
        const SectionTitle('من و دوستم', emoji: '🌈'),
        const SizedBox(height: 14),
        KidCard(
          radius: 32,
          gradient: const [Color(0xFFE9FDFF), Color(0xFFEFFFEA)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 66,
                    height: 66,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                    child: const Text('🦁', style: TextStyle(fontSize: 40)),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('سلام دوست کوچولو!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KidColors.ink)),
                        SizedBox(height: 4),
                        Text('من دوستِ تو در کلاس مهر هستم.', style: TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text('تو الان ${progress.stars} ستاره داری. هر درس تازه یعنی یک قدم دیگر تا قهرمان شدن.', style: const TextStyle(color: KidColors.muted, fontWeight: FontWeight.w700, height: 1.8)),
              const SizedBox(height: 14),
              Row(
                children: const [
                  Expanded(child: _MiniTile(emoji: '🎧', label: 'گوش کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniTile(emoji: '✍️', label: 'تمرین کن')),
                  SizedBox(width: 10),
                  Expanded(child: _MiniTile(emoji: '⭐', label: 'جایزه بگیر')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MiniTile extends StatelessWidget {
  final String emoji;
  final String label;
  const _MiniTile({required this.emoji, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.88), borderRadius: BorderRadius.circular(20)),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: KidColors.ink, fontSize: 12.3)),
        ],
      ),
    );
  }
}

class _KidBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onChanged;
  const _KidBottomNav({required this.selectedIndex, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      _NavEntry('خانه', '🏠', KidColors.blue),
      _NavEntry('بازی‌ها', '🗺️', KidColors.deepBlue),
      _NavEntry('جایزه‌ها', '🎁', KidColors.purple),
      _NavEntry('کیف من', '🎒', KidColors.orange),
      _NavEntry('من', '🌈', KidColors.green),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Container(
        height: 84,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.97),
          borderRadius: BorderRadius.circular(34),
          border: Border.all(color: Colors.white, width: 1.4),
          boxShadow: [BoxShadow(blurRadius: 28, offset: const Offset(0, 14), color: Colors.black.withOpacity(.12))],
        ),
        child: Row(
          children: [
            for (int i = 0; i < items.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onChanged(i),
                  child: _BottomNavItem(item: items[i], selected: selectedIndex == i),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavEntry {
  final String label;
  final String emoji;
  final Color color;
  const _NavEntry(this.label, this.emoji, this.color);
}

class _BottomNavItem extends StatelessWidget {
  final _NavEntry item;
  final bool selected;
  const _BottomNavItem({required this.item, required this.selected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(color: selected ? item.color.withOpacity(.12) : Colors.transparent, borderRadius: BorderRadius.circular(24)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(item.emoji, style: TextStyle(fontSize: selected ? 24 : 22)),
          const SizedBox(height: 2),
          Text(item.label, style: TextStyle(color: selected ? item.color : KidColors.muted, fontSize: 11, fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
        ],
      ),
    );
  }
}
