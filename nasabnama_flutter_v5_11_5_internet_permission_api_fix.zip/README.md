# NasabNama v5.11.5 Internet Permission API Fix

Base:
- nasabnama_flutter_v5_11_4_auto_login_auto_sync.zip

Changes:
- Bumps app version to 5.11.5+73
- Keeps API fixed in source:
  https://podtman.anony.ir/nasab
- Keeps automatic login and automatic sync logic
- Improves connection error message
- Updates GitHub Actions workflow to force Android permissions after flutter create:
  android.permission.INTERNET
  android.permission.ACCESS_NETWORK_STATE
- This is required because the workflow recreates android/ every build
- Keeps backend v5.11.4 auto_login compatibility
- Keeps Jalali dates, Bazaar payment, tree layout, export, icon, keystore and package name

Workflow changed:
- Full workflow code must be used from this ZIP
