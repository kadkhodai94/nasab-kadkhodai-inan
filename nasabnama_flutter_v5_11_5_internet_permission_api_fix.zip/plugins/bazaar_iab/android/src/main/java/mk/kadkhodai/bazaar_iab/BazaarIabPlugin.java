
package mk.kadkhodai.bazaar_iab;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.android.vending.billing.IInAppBillingService;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.embedding.engine.plugins.activity.ActivityAware;
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.PluginRegistry;

public class BazaarIabPlugin implements FlutterPlugin, MethodChannel.MethodCallHandler, ActivityAware, PluginRegistry.ActivityResultListener {
    private static final String CHANNEL_NAME = "mk.kadkhodai.bazaar_iab";
    private static final int REQ_CODE_PURCHASE = 7317;
    private static final String MARKET_PACKAGE = "com.farsitel.bazaar";
    private static final String MARKET_BIND_ACTION = "ir.cafebazaar.pardakht.InAppBillingService.BIND";
    private static final String ITEM_TYPE_SUBS = "subs";

    private MethodChannel channel;
    private Context context;
    private Activity activity;
    private ActivityPluginBinding activityBinding;
    private IInAppBillingService service;
    private boolean binding = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private MethodChannel.Result pendingPurchaseResult;
    private String pendingProductId = "";

    @Override
    public void onAttachedToEngine(FlutterPlugin.FlutterPluginBinding binding) {
        context = binding.getApplicationContext();
        channel = new MethodChannel(binding.getBinaryMessenger(), CHANNEL_NAME);
        channel.setMethodCallHandler(this);
    }

    @Override
    public void onDetachedFromEngine(FlutterPlugin.FlutterPluginBinding binding) {
        if (channel != null) channel.setMethodCallHandler(null);
        unbindService();
        context = null;
    }

    @Override
    public void onAttachedToActivity(ActivityPluginBinding binding) {
        activityBinding = binding;
        activity = binding.getActivity();
        binding.addActivityResultListener(this);
    }

    @Override
    public void onDetachedFromActivityForConfigChanges() {
        detachActivity();
    }

    @Override
    public void onReattachedToActivityForConfigChanges(ActivityPluginBinding binding) {
        onAttachedToActivity(binding);
    }

    @Override
    public void onDetachedFromActivity() {
        detachActivity();
    }

    private void detachActivity() {
        if (activityBinding != null) activityBinding.removeActivityResultListener(this);
        activityBinding = null;
        activity = null;
    }

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
            binding = false;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IInAppBillingService.Stub.asInterface(binder);
            binding = false;
        }
    };

    private boolean bindServiceIfNeeded() {
        if (service != null) return true;
        if (context == null) return false;
        if (binding) return true;
        try {
            Intent serviceIntent = new Intent(MARKET_BIND_ACTION);
            serviceIntent.setPackage(MARKET_PACKAGE);
            binding = context.bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
            return binding || service != null;
        } catch (Exception e) {
            binding = false;
            return false;
        }
    }

    private void runWhenServiceReady(final MethodChannel.Result result, final Runnable action) {
        if (service != null) {
            action.run();
            return;
        }
        if (!bindServiceIfNeeded()) {
            result.error("bazaar_unavailable", "سرویس پرداخت کافه‌بازار در دسترس نیست.", null);
            return;
        }
        waitForService(result, action, 0);
    }

    private void waitForService(final MethodChannel.Result result, final Runnable action, final int attempt) {
        if (service != null) {
            action.run();
            return;
        }
        if (attempt >= 20) {
            result.error("bazaar_unavailable", "اتصال به سرویس پرداخت بازار برقرار نشد.", null);
            return;
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                waitForService(result, action, attempt + 1);
            }
        }, 150);
    }

    private void unbindService() {
        if (context != null && (service != null || binding)) {
            try {
                context.unbindService(serviceConnection);
            } catch (Exception ignored) {
            }
        }
        service = null;
        binding = false;
    }

    @Override
    public void onMethodCall(MethodCall call, final MethodChannel.Result result) {
        if ("isAvailable".equals(call.method)) {
            result.success(bindServiceIfNeeded() || service != null);
            return;
        }

        if ("purchaseSubscription".equals(call.method)) {
            final String productId = call.argument("productId");
            final String payload = call.argument("payload");
            if (productId == null || productId.trim().isEmpty()) {
                result.error("invalid_product", "شناسه محصول معتبر نیست.", null);
                return;
            }
            runWhenServiceReady(result, new Runnable() {
                @Override
                public void run() {
                    purchaseSubscriptionNow(productId, payload == null ? "" : payload, result);
                }
            });
            return;
        }

        if ("restoreSubscriptions".equals(call.method)) {
            runWhenServiceReady(result, new Runnable() {
                @Override
                public void run() {
                    restoreSubscriptionsNow(result);
                }
            });
            return;
        }

        result.notImplemented();
    }

    private void purchaseSubscriptionNow(String productId, String payload, MethodChannel.Result result) {
        if (activity == null || context == null) {
            result.error("no_activity", "Activity در دسترس نیست.", null);
            return;
        }
        if (pendingPurchaseResult != null) {
            result.error("purchase_pending", "یک خرید دیگر در حال انجام است.", null);
            return;
        }
        try {
            int supported = service.isBillingSupported(3, context.getPackageName(), ITEM_TYPE_SUBS);
            if (supported != 0) {
                result.error("not_supported", "اشتراک توسط بازار روی این دستگاه پشتیبانی نشد.", supported);
                return;
            }

            Bundle buyIntentBundle = service.getBuyIntent(3, context.getPackageName(), productId, ITEM_TYPE_SUBS, payload);
            int response = extractResponseCode(buyIntentBundle);
            if (response != 0) {
                result.error("buy_intent_failed", "بازار اجازه شروع خرید را نداد.", response);
                return;
            }

            PendingIntent pendingIntent = buyIntentBundle.getParcelable("BUY_INTENT");
            if (pendingIntent == null) {
                result.error("missing_buy_intent", "پنجره پرداخت بازار ساخته نشد.", null);
                return;
            }

            pendingPurchaseResult = result;
            pendingProductId = productId;
            activity.startIntentSenderForResult(
                    pendingIntent.getIntentSender(),
                    REQ_CODE_PURCHASE,
                    new Intent(),
                    0,
                    0,
                    0
            );
        } catch (IntentSender.SendIntentException e) {
            pendingPurchaseResult = null;
            result.error("send_intent_failed", e.getMessage(), null);
        } catch (Exception e) {
            pendingPurchaseResult = null;
            result.error("purchase_failed", e.getMessage(), null);
        }
    }

    private void restoreSubscriptionsNow(MethodChannel.Result result) {
        if (context == null) {
            result.error("no_context", "Context در دسترس نیست.", null);
            return;
        }
        try {
            Bundle owned = service.getPurchases(3, context.getPackageName(), ITEM_TYPE_SUBS, null);
            int response = extractResponseCode(owned);
            if (response != 0) {
                result.error("restore_failed", "بازیابی اشتراک از بازار ناموفق بود.", response);
                return;
            }

            ArrayList<String> dataList = owned.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
            ArrayList<String> sigList = owned.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
            ArrayList<Map<String, Object>> output = new ArrayList<>();

            if (dataList != null) {
                for (int i = 0; i < dataList.size(); i++) {
                    String data = dataList.get(i);
                    String signature = sigList != null && i < sigList.size() ? sigList.get(i) : "";
                    output.add(mapFromPurchaseData(data, signature, ""));
                }
            }

            result.success(output);
        } catch (Exception e) {
            result.error("restore_exception", e.getMessage(), null);
        }
    }

    private int extractResponseCode(Bundle bundle) {
        Object response = bundle.get("RESPONSE_CODE");
        if (response == null) return 0;
        if (response instanceof Integer) return (Integer) response;
        if (response instanceof Long) return ((Long) response).intValue();
        return 0;
    }

    @Override
    public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_CODE_PURCHASE || pendingPurchaseResult == null) return false;

        MethodChannel.Result result = pendingPurchaseResult;
        pendingPurchaseResult = null;

        try {
            if (data == null) {
                result.success(null);
                pendingProductId = "";
                return true;
            }

            int responseCode = data.getIntExtra("RESPONSE_CODE", 0);
            String purchaseData = data.getStringExtra("INAPP_PURCHASE_DATA");
            String signature = data.getStringExtra("INAPP_DATA_SIGNATURE");

            if (responseCode != 0 || purchaseData == null) {
                result.success(null);
                pendingProductId = "";
                return true;
            }

            result.success(mapFromPurchaseData(purchaseData, signature == null ? "" : signature, pendingProductId));
            pendingProductId = "";
            return true;
        } catch (Exception e) {
            result.error("purchase_result_error", e.getMessage(), null);
            pendingProductId = "";
            return true;
        }
    }

    private Map<String, Object> mapFromPurchaseData(String purchaseData, String signature, String fallbackProductId) {
        HashMap<String, Object> map = new HashMap<>();
        String productId = fallbackProductId == null ? "" : fallbackProductId;
        String orderId = "";
        String token = "";

        try {
            JSONObject json = new JSONObject(purchaseData);
            if (json.has("productId")) productId = json.optString("productId", productId);
            if (json.has("orderId")) orderId = json.optString("orderId", "");
            if (json.has("purchaseToken")) token = json.optString("purchaseToken", "");
            if (json.has("token") && token.isEmpty()) token = json.optString("token", "");
        } catch (Exception ignored) {
        }

        map.put("productId", productId);
        map.put("orderId", orderId);
        map.put("purchaseToken", token);
        map.put("purchaseData", purchaseData);
        map.put("signature", signature == null ? "" : signature);
        return map;
    }
}
