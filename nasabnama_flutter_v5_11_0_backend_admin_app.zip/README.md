# NasabNama v5.11.0 Backend + In-App Admin Panel

Base:
- nasabnama_flutter_v5_10_13_jalali_home_text_fix.zip

App changes:
- Adds Online Sync page inside app
- Adds backend register/login support
- Adds upload current tree backup to server
- Adds download latest/current tree backup from server
- Adds online invite redeem
- Adds in-app admin login page
- Adds in-app admin dashboard page
- Admin panel shows users, trees, invites and backup stats from server
- Keeps local/offline data flow
- Keeps local auth/access system
- Keeps one-time local invite system
- Keeps no-auto-detect/manual links logic
- Keeps Jalali date display
- Keeps home text fixes
- Keeps generation 7 children fix
- Keeps horizontal ancestors row
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Backend:
- PHP/MySQL API for cPanel
- Install SQL included separately
- API path suggestion: public_html/nasab/api
- Admin login through API and in-app panel

Version: 5.11.0+70
