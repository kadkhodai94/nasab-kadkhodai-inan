# NasabNama v5.10.9 Safe Full Family Entry

Base:
- v5.10.8 One-time Invite + Home Cleanup

Fix:
- Safe mode for "Add full family"

Changes:
- Removes autoPlace from addFullFamily
- Removes automatic dedupeSmart from addFullFamily
- Children are connected only to the selected/created father and mother
- Children are no longer matched/merged by loose grandfather/father guessing
- Similar existing family-head candidates must be selected manually in preview
- One candidate is not auto-selected anymore
- Preview text explains that no guessed connection is applied
- If multiple possible parent/grandparent matches exist, save is stopped with a warning
- Family entry now logs safe direct connection
- Does not delete the feature
- Keeps main tree UI unchanged
- Keeps one-time invite system
- Keeps local auth/access system
- Keeps Bazaar payment and public key
- Keeps PNG/PDF export
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.9+65
