# Shejrino v5.11.8 Workflow ZIP Fix

Base:
- shejrino_flutter_v5_11_7_connection_cleanup_add_flow.zip

Changes:
- Version bumped to 5.11.8+76
- Workflow fully renamed to Shejrino
- Finds shejrino_flutter_*.zip and shejrino_*.zip
- Keeps nasabnama/nasab patterns only as compatibility fallback
- Artifact names are shejrino-v...-apk and shejrino-v...-aab
- Output APK/AAB files are copied to dist/shejrino-v...apk/aab
- Android label remains شجرینو
- Internet permissions remain forced
- Package name remains mk.kadkhodai.nasab
- Keystore and launcher icon logic preserved
