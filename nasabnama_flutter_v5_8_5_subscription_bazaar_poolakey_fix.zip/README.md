# NasabNama v5.8.5 Bazaar Poolakey

Fix:
- Removed cafebazaar_flutter dependency
- Replaced with flutter_poolakey 2.2.0+1.0.0
- This avoids the cafebazaar_flutter namespace error on newer Android Gradle Plugin
- Bazaar subscription remains active through Poolakey
- Added JitPack repository step for Poolakey
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.5+46
