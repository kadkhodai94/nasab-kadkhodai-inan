# NasabNama v5.11.3 Auto API + Clean Release

Base:
- nasabnama_flutter_v5_11_0_backend_admin_app.zip

Changes:
- API URL is hardcoded in source:
  https://podtman.anony.ir/nasab
- Removed editable API address field from Online Sync page
- Removed editable API address field from Admin Login page
- Admin panel connects automatically to the production API
- Online sync connects automatically to the production API
- Removed old/test quick actions from visible UI
- Removed old online-prep/test entry from Backup page
- Removed reference sample HTML folder from package
- Replaced personal/sample hint text with generic text
- Kept backend sync/admin pages
- Kept Jalali date display
- Kept home text fixes
- Kept generation 7 children fix
- Kept horizontal ancestors row
- Kept no-auto-detect/manual links logic
- Kept Bazaar payment and public key
- Kept PNG/PDF export
- Kept package/applicationId mk.kadkhodai.nasab
- Kept keystore
- Kept uploaded launcher icon
- Workflow unchanged

Version: 5.11.3+71
