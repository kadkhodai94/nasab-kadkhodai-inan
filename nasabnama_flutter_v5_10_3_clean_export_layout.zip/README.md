# NasabNama v5.10.3 Clean Export Layout

Base:
- v5.10.2 Tree PNG/PDF export

Changes:
- Replaces specific sample hint names with generic sample names:
  - Ali, Hasan, Reza, Maryam, Amir, Sam, Narges, Sara
- Centers upper generation/parent layout better
- Keeps the existing tree UI style unchanged
- Changes export buttons into one compact export button
- Export options open in a bottom sheet
- Keeps PNG export
- Keeps PDF export
- Keeps Bazaar payment and public key
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.3+59
