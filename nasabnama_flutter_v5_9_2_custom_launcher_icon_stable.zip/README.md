# NasabNama v5.9.2 Custom Launcher Icon Stable

Base:
- v5.9.1 stable workflow-compatible version

Changes:
- Adds custom launcher icon again
- Keeps stable package/MainActivity fix
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps payment/subscription removed
- Workflow now applies icons safely only if android_launcher_icons exists
- Icon step does not fail build if a file is missing

Version: 5.9.2+53
