# NasabNama v5.10.5 Tree Initial Zoom Fit

Base:
- v5.10.4 Compile Fix Export

Changes:
- Adjusts the initial tree zoom/scale so children fit better inside the main frame
- Adds automatic initial scale based on board width and screen width
- Keeps manual zoom/pan with fingers
- Keeps centered upper-generation layout
- Keeps generic sample names
- Keeps compact export button
- Keeps PNG/PDF export
- Keeps Bazaar payment and public key
- Keeps package/applicationId mk.kadkhodai.nasab
- Keeps keystore
- Keeps uploaded launcher icon
- Workflow unchanged

Version: 5.10.5+61
