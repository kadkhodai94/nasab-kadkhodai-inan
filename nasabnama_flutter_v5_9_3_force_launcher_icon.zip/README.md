# NasabNama v5.9.3 Force Launcher Icon

Fix:
- Default Flutter launcher icon is removed before build
- Custom icon is copied after clean Android generation
- Workflow fails if android_launcher_icons is missing
- Action log prints final launcher icon files and sha256
- Payment/subscription remains removed
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore remains

Version: 5.9.3+54
