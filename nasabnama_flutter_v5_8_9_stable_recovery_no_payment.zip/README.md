# NasabNama v5.8.9 Stable Recovery

Purpose:
- Rollback to stable v5.7.2 codebase
- No Bazaar payment plugin
- No Poolakey
- No native payment dependency
- Adds crash-safe SharedPreferences load
- If previous stored data is corrupted, the app resets local data instead of crashing at launch
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.9+50
