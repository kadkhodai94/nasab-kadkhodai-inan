# NasabNama v5.8.4 Bazaar Namespace Fix

Fix:
- Adds GitHub Actions patch for cafebazaar_flutter Android namespace
- Fixes Gradle error:
  Namespace not specified in cafebazaar_flutter android/build.gradle
- Bazaar subscription remains active
- Package/applicationId remains mk.kadkhodai.nasab
- Keystore and launcher icon kept

Version: 5.8.4+45
