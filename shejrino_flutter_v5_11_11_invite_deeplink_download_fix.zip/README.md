# Shejrino v5.11.11 Invite Deep Link + Download Fix

Base:
- shejrino_flutter_v5_11_10_emptystate_compile_fix.zip

Changes:
- Version bumped to 5.11.11+79
- Invite links now use:
  https://podtman.anony.ir/nasab/invite.php?code=...
- Invite page opens app through:
  shejrino://invite?code=...
  and Android Chrome intent:// fallback.
- If app is not installed, invite page sends user to:
  https://podtman.anony.ir/nasab/download/shejrino.apk
- App listens for incoming invite links using app_links.
- If app is opened by invite link, code is saved as pendingInviteCode and redeemed after user login.
- Android deep link intent filters are injected in workflow.
- Backend update includes invite.php and download folder README.
- Backend update intentionally excludes config.php.

Workflow changed in this version.
Version: 5.11.11+79
