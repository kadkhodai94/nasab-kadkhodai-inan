# Shejrino / شجرینو v5.11.7 Connection Cleanup + Add Flow

Base:
- shejrino_flutter_v5_11_6_online_invite_name.zip

Changes:
- App version bumped to 5.11.7+75
- Adds in-app API ping test before admin login
- Shows HTTP status and ping error in admin login page
- Adds ping check inside auto online session
- Keeps API fixed:
  https://podtman.anony.ir/nasab
- Removes Add tab from bottom navigation
- Removes public/general Add flow from main pages
- Removes Home quick buttons for add person/family
- Add person is available only inside Tree page
- Removes black/transparent add page issue by wrapping AddPersonPage in Scaffold
- Removes visible texts:
  ثبت دستی
  بدون تشخیص خودکار
  بدون اتصال حدسی
  افزودن خانواده کامل
- Keeps Shejrino app name
- Keeps online invite, auto sync, internet permissions, Bazaar payment, Jalali dates, export and keystore
- Workflow unchanged from v5.11.6

Version: 5.11.7+75
